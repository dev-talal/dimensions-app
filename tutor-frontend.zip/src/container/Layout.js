import React from "react";
import Footer from "../components/web/body/footer/footer";
import Header from "../components/web/body/header/header";

export default function Layout({ children }) {
  return (
    <React.Fragment>
      <Header />
      {children}
      <Footer />
    </React.Fragment>
  );
}
