import axios from "axios";
import AxiosBase from "../config/AxiosBase";
import { headers } from "../helpers";

// kids api's
export const getAllKids = () => {
  headers();
  return AxiosBase.get("/parent/get-all-kids");
};
export const addKidApi = ({ formData }) => {
  headers();
  return AxiosBase.put("/parent/add-kid", formData);
};
export const deleteKidApi = (id) => {
  headers();
  return AxiosBase.put(`/parent/remove-kid/${id}`);
};
export const updateKidApi = ({ id, formData }) => {
  headers();
  return AxiosBase.put(`/parent/update-kid/${id}`, formData);
};

// payment method
export const getAllPaymentMethod = () => {
  headers();
  return AxiosBase.get("/auth/get-all-payment-method");
};
export const addPaymentMethod = (data) => {
  headers();
  return AxiosBase.put("/auth/add-payment-method", data);
};
export const deletePaymentMethod = (id) => {
  headers();
  return AxiosBase.put(`/auth/remove-payment-method/${id}`);
};
export const updatePaymentMethod = ({ id, data }) => {
  headers();
  return AxiosBase.put(`/auth/update-payment-method/${id}`, data);
};

// tutor methods
export const getAllTutor = ({ queryKey }) => {
  const params = queryKey[1];
  headers();
  return AxiosBase.get("/tutor/all-tutors", { params });
};
// tutor methods
export const getProfileById = ({ queryKey }) => {
  const id = queryKey[1];
  headers();
  return AxiosBase.get(`/tutor/single-tutor/${id}`);
};

// workshop

export const getAllWorkshop = () => {
  headers();
  return AxiosBase.get("/workshop/all");
};

export const getSingleWorkshop = ({ queryKey }) => {
  const id = queryKey[1];
  headers();
  return AxiosBase.get(`/workshop/${id}`);
};

export const getAllClasses = () => {
  headers();
  return AxiosBase.get("/class/user-classes");
};

export const getSingleClass = (id) => {
  headers();
  return AxiosBase.get(`/class/single-class/${id}`);
};

export const getSingleAnnouncment = (id) => {
  headers();
  return AxiosBase.get(`/class/single-announcement-by-class-id/${id}`);
};

export const postComment = (id, data) => {
  headers();
  return AxiosBase.put(`/class/new-comment/${id}`, data);
};

export const addAnouncement = (data) => {
  headers();
  return AxiosBase.post(`/class/new-announcement`, data);
};

export const getAllPurchases = () => {
  headers();
  return AxiosBase.get(`/class/purchases-earnings`);
};

export const getDashboardCount = () => {
  headers();
  return AxiosBase.get(`/auth/dashboard-counts`);
};

export const updateClassMeetingApi = (id, data) => {
  headers();
  return AxiosBase.put(`/class/update-class/${id}`, data);
};

export const postClassReview = (data) => {
  headers();
  return AxiosBase.put(`/class/place-review`, data);
};

// Chat
export const getChatToken = () => {
  headers();
  return AxiosBase.get(`/twilio/create-chat-token`);
};

export const getConversations = () => {
  headers();
  return AxiosBase.get(`/twilio/get-user-chat-rooms`);
};

export const updateChatRoomApi = (data) => {
  headers();
  return AxiosBase.put(`/twilio/update-chat-room/${data.id}`, data?.data);
};

export const getAllNotifications = () => {
  headers();
  return AxiosBase.get(`/auth/get-user-notifications`);
};

export const resendVerification = (data) => {
  headers();
  return AxiosBase.post(`/auth/resend-verify-email-token`, data);
};

export const verifyEmail = (token) => {
  headers();
  return AxiosBase.get(`/auth/verify-email/${token}`);
};

export const socialAuthentication = (payload) => {
  headers();
  return AxiosBase.post(`auth/social-login`,payload);
}

export const getBirthdayDetails = async ({ id, access_token }) => {
  const response = await axios.get(
    `https://people.googleapis.com/v1/people/${id}?personFields=genders&key=${process.env.REACT_APP_GOOGLE_PEOPLE_API_KEY}&access_token=${access_token}`
  );
  return response.data.genders[0].value;
};
