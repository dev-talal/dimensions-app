// constant
// setting header title
export const SET_HEADER_TITLE = "SET_HEADER_TITLE";
export const RESET_HEADER_TITLE = "RESET_HEADER_TITLE";
export const SET_STUDENT_HOME = "SET_STUDENT_HOME";