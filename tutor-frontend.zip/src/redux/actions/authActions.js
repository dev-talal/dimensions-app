import AxiosBase from "../../config/AxiosBase";
import Swal from "sweetalert2";
import {
  LOAD_USER_FAIL,
  LOAD_USER_REQUEST,
  LOAD_USER_SUCCESS,
  LOGIN_FAIL,
  LOGIN_REQUEST,
  LOGIN_SUCCESS,
  LOGOUT_USER_FAIL,
  LOGOUT_USER_SUCCESS,
  REGISTER_USER_FAIL,
  REGISTER_USER_REQUEST,
  REGISTER_USER_SUCCESS,
} from "../constants/userConstant";
import { headers } from "../../helpers";
import history from "../../helpers/history";
import { send } from "../../helpers/Push";

// SignIn action
export const SignUp = (formData) => async (dispatch) => {
  try {
    dispatch({ type: REGISTER_USER_REQUEST });

    await AxiosBase.post(`/auth/sign-up`, {
      ...formData,
    });

    dispatch({
      type: REGISTER_USER_SUCCESS,
      payload: formData,
    });
    history.push("/login");
  } catch (error) {
    Swal.fire({
      text:error.response?.data.message,
      icon:"error"
    })
    dispatch({
      type: REGISTER_USER_FAIL,
      payload: error.response?.data,
    });
  }
};

// Login action
export const LogIn = (formData, path) => async (dispatch) => {
  try {
    dispatch({ type: LOGIN_REQUEST });

    const response = await AxiosBase.post(path, {
      fcm_token:"",
      ...formData,
    });
    // Set token to localStorage
    const token = response.data.token;
    const user = response.data;

    localStorage.setItem("authToken", token);

    // Set token to Auth header
    headers();

    dispatch({
      type: LOGIN_SUCCESS,
      payload: user,
      token: token,
    });
    // Swal.fire({
    //   position: "center",
    //   icon: "success",
    //   title: "Authentication Successfull !",
    //   showConfirmButton: false,
    //   timer: 2000,
    // });
    send("LOGIN", "User Logged in Successfully");
    if (!user?.is_profile_completed) {
      history.push(
        user?.user_type === "parent"
          ? "/profile-setup/add-kids"
          : user?.user_type === "tutor"
          ? "/profile-setup/tutor"
          : "/"
      );
    } else {
      history.push(user?.user_type === "tutor" ? "/dashboard" : "/");
      // history.push("/dashboard");
    }
  } catch (error) {
    dispatch({
      type: LOGIN_FAIL,
      payload: error.response?.data,
    });
    Swal.fire({
      position: "center",
      icon: "error",
      title: "Authentication Failed !",
      text: error?.response?.data?.message,
      showConfirmButton: false,
      timer: 2000,
    });
  }
};

// Load user
export const loadUser = () => async (dispatch) => {
  const query = new URLSearchParams(window.location.search);
  let token = null;
  if(query.get('t')){
    localStorage.setItem("authToken", query.get('t'));
    token = query.get('t');
  }else{
    token = localStorage.authToken;
  }
  try {
    dispatch({ type: LOAD_USER_REQUEST });

    const response = await AxiosBase.get(`/auth/me`, {
      headers: {
        "x-access-token": token || "",
      },
    });

    dispatch({
      type: LOAD_USER_SUCCESS,
      payload: response.data,
    });
    if(query.get('t')){
      dispatch({
        type: LOGIN_SUCCESS,
        payload: response.data,
        token: token,
      });
      history.push("/dashboard");
    }
  } catch (error) {
    dispatch({
      type: LOAD_USER_FAIL,
      // payload: error.response.data.message,
    });
  }


};

// Logout user
export const logout = () => async (dispatch) => {
  const token = localStorage.authToken;

  try {
    if (token) {
      localStorage.removeItem("authToken");
    }
    dispatch({
      type: LOGOUT_USER_SUCCESS,
    });
  } catch (error) {
    dispatch({
      type: LOGOUT_USER_FAIL,
    });
    Swal.fire({
      position: "center",
      icon: "error",
      title: "Logout Failed",
      showConfirmButton: false,
      timer: 2000,
    });
  }
};
