import { SET_HEADER_TITLE , SET_STUDENT_HOME } from "../constants/dashboardConstant";

export const setHeaderTitle = (title) => {
  return {
    type: SET_HEADER_TITLE,
    payload: title,
  };
};

export const setStudentHome = (type) => {
  return {
    type: SET_STUDENT_HOME,
    payload: type,
  };
};
