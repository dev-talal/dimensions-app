import { combineReducers } from "redux";
import { authReducer } from "./authReducers";
import { StudentHomeReducer } from "./dashboardReducer";
export default combineReducers({
  auth: authReducer,
  student:StudentHomeReducer

});
