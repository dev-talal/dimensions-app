import {
  RESET_HEADER_TITLE,
  SET_HEADER_TITLE,
  SET_STUDENT_HOME
} from "../constants/dashboardConstant";

// Auth Reducer
export const dashboardReducers = (state = { title: "Dashboard" }, action) => {
  switch (action.type) {
    case SET_HEADER_TITLE:
      return {
        ...state,
        title: action.payload,
      };
    case RESET_HEADER_TITLE:
      return {
        ...state,
        title: "Dashboard",
      };

    default:
      return state;
  }
};

// Student Home Reducer

export const StudentHomeReducer = (state = { value: false }, action) => {
  switch (action.type) {
    case SET_STUDENT_HOME:
      return {
        ...state,
        value: action.payload,
      };
    default:
    return state;
  }
};
