import React from "react";
import { Route } from "react-router-dom";
import Layout from "../container/Layout";

const PublicRoutes = ({ component: Component, ...rest }) => {
  return (
    <Route
      {...rest}
      render={(props) => (
        <Layout>
          <Component {...props} heading={rest.heading} />
        </Layout>
      )}
    />
  );
};

export default PublicRoutes;
