import React from "react";
import { useSelector } from "react-redux";
import { Redirect, Route } from "react-router";
import Layout from "../container/Layout";

export default function PrivateRoute({ component: Component, ...rest }) {
  const { token } = useSelector((state) => state.auth);
  return (
    <Route
      {...rest}
      render={(props) =>
        token ? (
          <Layout>
            <Component {...props} />
          </Layout>
        ) : (
          <Redirect
            to={{
              pathname: "/",
              state: { from: props.location },
            }}
          />
        )
      }
    />
  );
}
