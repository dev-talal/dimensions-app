import React from "react";
import { useSelector } from "react-redux";
import { Redirect, Route } from "react-router";

export default function ProfileSetupRoute({ component: Component, ...rest }) {
  const { user, token } = useSelector((state) => state.auth);
  return (
    <Route
      {...rest}
      render={(props) =>
        token ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{
              pathname: "/",
              state: { from: props.location },
            }}
          />
        )
      }
    />
  );
}
