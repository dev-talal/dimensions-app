import { useDispatch } from "react-redux";
import { loadUser, logout } from "./redux/actions/authActions";
import jwtDecode from "jwt-decode";
import Routes from "./routes";
import { headers } from "./helpers/index";
import history from "./helpers/history";
import { send } from "./helpers/Push";
import { useLocation } from "react-router-dom";
import { useEffect } from "react";

function App() {
  // auth structure
  const location = useLocation();
  const token = localStorage.authToken;
  const dispatch = useDispatch();
  if (token) {
    const decoded = jwtDecode(token);
    const currentTime = Date.now() / 1000;
    if (decoded.exp < currentTime) {
      localStorage.removeItem("authToken");
      // logout
      dispatch(logout());
      history.push("/login");
    }
    headers();
    dispatch(loadUser());
  } else {
    dispatch(loadUser());
  }
  useEffect(() => {
    window.scroll({ top: 0, behavior: 'smooth' })
  },[location.pathname])
  // main return
  return (
    <div>
      <Routes />
    </div>
  );
}

export default App;
