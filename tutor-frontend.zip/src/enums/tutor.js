export const ETeach_Type = {
  STUDENT_HOME: "student_home",
  TUTOR_HOME: "tutor_home",
  ONLINE: "online",
};
