import { useState, useEffect } from "react";

export default function useReloadPrompt(bool, message) {
  const [showPrompt, setShowPrompt] = useState(bool);

  // show prompt on window unload
  window.onload = function () {
    initBeforeUnLoad(showPrompt);
  };
  const initBeforeUnLoad = (showPrompt) => {
    window.onbeforeunload = (event) => {
      // Show prompt based on state
      if (showPrompt) {
        const e = event || window.event;
        e.preventDefault();
        if (e) {
          e.returnValue = message;
        }
        return message;
      }
    };
  };
  // Re-Initialize the onbeforeunload event listener
  useEffect(() => {
    initBeforeUnLoad(showPrompt);
  }, [showPrompt]);
  return [showPrompt, setShowPrompt];
}
