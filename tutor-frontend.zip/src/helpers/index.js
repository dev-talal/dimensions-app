import API from "../config/AxiosBase";

export const headers = () => {
  const token = localStorage.authToken;
  if (token) {
    API.defaults.headers.common["x-access-token"] = token;

    return API;
  } else {
    return API.defaults.headers;
  }
};

export const formatDate = date => {
  let d = new Date(date),
    month = "" + (d.getMonth() + 1),
    day = "" + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = "0" + month;
  if (day.length < 2) day = "0" + day;

  return [year, month, day].join("-");
};

// const rebuildData = (values, gallery) => {
//   const formData = {};
//   if (key == "files" && gallery.length > 0) {
//     formData["files"] = [];
//     gallery.filter(x => x.file !== "").map((item, key) => {
//       formData["files"][key] = item.file;
//     });
//   } else {
//     formData[key] = values[key];
//   }
//   return formData;
// };

export const buildFormData = (formData, data, parentKey) => {
  if (
    data &&
    typeof data === "object" &&
    !(data instanceof Date) &&
    !(data instanceof File)
  ) {
    Object.keys(data).forEach(key => {
      buildFormData(
        formData,
        data[key],
        parentKey ? `${parentKey}[${key}]` : key
      );
    });
  } else {
    const value = data == null ? "" : data;
    formData.append(parentKey, value);
  }
};

function jsonToFormData(data) {
  const formData = new FormData();

  buildFormData(formData, data);

  return formData;
}

const profileImageURL = process.env.REACT_APP_IMAGE_BASE;
export const getImageUrl = (url,social) => {
  if (url && !social) {
    return profileImageURL + url;
  } else if(url && social){
    return url;
  } else{return null};
};
