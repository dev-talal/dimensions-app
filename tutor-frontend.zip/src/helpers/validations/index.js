import * as Yup from "yup";

// kids  validation schemea

export const KidsFormValidationSchema = Yup.object().shape({
  first_name: Yup.string()
    .min(2, "Too Short! ")
    .max(50, "Too Long!")
    .required("Please enter first name"),
  last_name: Yup.string()
    .min(2, "Too Short! ")
    .max(50, "Too Long!")
    .required("Please enter last name"),
  class_name: Yup.string()
    .min(2, "Too Short! ")
    .max(50, "Too Long!")
    .required("Please enter valid class name"),
  age: Yup.number().required("Please enter a age"),
  gender: Yup.string().required("Please select a valid gender"),
  grade: Yup.string().required("Please select a  grade"),
  educational: Yup.string().required("Please select a educational system"),
});

//  Signup validation schemea
export const SignUpValidationSchema = Yup.object().shape({
  lastName: Yup.string()
    .min(2, "Too Short! ")
    .max(50, "Too Long!")
    .required("Please enter last name"),
  middleName: Yup.string().min(2, "Too Short! ").max(50, "Too Long!"),
  firstName: Yup.string()
    .min(2, "Too Short! ")
    .max(50, "Too Long!")
    .required("Please enter first name"),
    gender: Yup.string()
    .required("Please select gender"),

  email: Yup.string()
    .email("Please enter a valid email")
    .min(2, "Too Short! ")
    .max(50, "Too Long!")
    .required("Please enter valid email"),
  password: Yup.string()
    .required("Please enter a passowrd")
    .min(8, "Password must be upto 8 Charachters"),
  termsAndCondition: Yup.boolean().oneOf(
    [true],
    "Please agree with terms and condition & policy"
  ),
  // individualCheck: Yup.boolean().oneOf(
  //   [true],
  //   "Please agree your are 18 year old or more"
  // ),
})

//  Signup validation schemea
// export const IndividualSignUpValidationSchema = Yup.object().shape({
//   lastName: Yup.string()
//     .min(2, "Too Short! ")
//     .max(50, "Too Long!")
//     .required("Please enter last name"),
//   middleName: Yup.string().min(2, "Too Short! ").max(50, "Too Long!"),
//   firstName: Yup.string()
//     .min(2, "Too Short! ")
//     .max(50, "Too Long!")
//     .required("Please enter first name"),

//   email: Yup.string()
//     .email("Please enter a valid email")
//     .min(2, "Too Short! ")
//     .max(50, "Too Long!")
//     .required("Please enter valid email"),
//   password: Yup.string()
//     .required("Please enter a passowrd")
//     .min(8, "Password must be upto 8 Charachters"),
//   termsAndCondition: Yup.boolean().oneOf(
//     [true],
//     "Please agree with terms and condition & policy"
//   ),
//   individualCheck: Yup.boolean().oneOf(
//     [true],
//     "Please agree your are 18 year old or more"
//   ),
// });
