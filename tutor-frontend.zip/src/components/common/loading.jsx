import React from "react";

export default function Loading({ height = "60vh" }) {
  return (
    <div  className="centerFlex" style={{ height: height, width: "100%" }}>
      <div  className="sk-chase">
        <div  className="sk-chase-dot" />
        <div  className="sk-chase-dot" />
        <div  className="sk-chase-dot" />
        <div  className="sk-chase-dot" />
        <div  className="sk-chase-dot" />
        <div  className="sk-chase-dot" />
      </div>
    </div>
  );
}
