import { Range, getTrackBackground } from "react-range";
import React, { useEffect, useState } from "react";

export default function RangeSlider({ range: initRange, onDone }) {
  const [range, setRange] = useState(initRange);
  const MIN = 0;
  const MAX = 500;

  useEffect(() => {
    initRange && setRange(initRange);
    return () => {};
  }, [initRange]);

  // main return
  return (
    <div  className="rangeSlider">
      <div  className="range">{range[0]}</div> <span  className="mr-4"> - </span>{" "}
      <div  className="range">{range[1]}</div>
      <Range
        step={1}
        min={0}
        max={500}
        values={range}
        onFinalChange={onDone}
        onChange={(values) => setRange(values)}
        renderTrack={({ props, children }) => (
          <div
            onMouseDown={props.onMouseDown}
            onTouchStart={props.onTouchStart}
            style={{
              ...props.style,
              height: "36px",
              display: "flex",
              width: "100%",
              maxWidth: "400px",
              minWidth: "200px",
            }}
          >
            <div
              ref={props.ref}
              style={{
                height: "2px",
                width: "100%",
                background: getTrackBackground({
                  values: range,
                  colors: ["#C8C8C8", "#7ABBB5", "#C8C8C8"],
                  min: MIN,
                  max: MAX,
                  rtl: false,
                }),
                alignSelf: "center",
              }}
            >
              {children}
            </div>
          </div>
        )}
        renderThumb={({ props }) => (
          <div
            {...props}
            style={{
              ...props.style,
              height: "35px",
              width: "35px",
              borderRadius: "50%",
              border: "2px solid #7ABBB5",
              background: "#fff",
              cursor: "pointer",
            }}
          />
        )}
      />
    </div>
  );
}
