import React from "react";
import {
  classLocationOptions,
  sortByOptions,
} from "../../views/web/search/constant";
import { SelectInput } from "../basic/RenderInputs";
import RangeSlider from "../common/rangeSlider";

export default function FilterSec({
  filterState,
  setStateByName,
  showMoreFilters,
  setShowMoreFilters,
}) {
  return (
    <div  className="col-md-7">
      <div  className="searchSec">
        <h1>Find an online tutor</h1>
        <div  className=" row ">
          <div  className="col-md-6">
            <div  className="inputDiv">
              <label>I want to learn</label>
              <input
                type="text"
                 className="textInput"
                placeholder="Find a skill"
                value={filterState.query}
                onChange={(e) => setStateByName("query", e.target.value)}
              />
            </div>
          </div>
          <div  className="col-md-6">
            <div  className="inputDiv">
              <label>Class location</label>
              <SelectInput
                field={{ value: filterState.classLocation }}
                form={{ touched: {}, errors: {} }}
                name="class_location"
                type="select"
                options={classLocationOptions}
                onChange={(e) =>
                  setStateByName("classLocation", e.target.value)
                }
                noFormik
              />
            </div>
          </div>
        </div>
        <div  className="mt-3">
          <label>Price range</label>

          <RangeSlider
            range={filterState.priceRange}
            onDone={(v) => setStateByName("priceRange", v)}
          />
        </div>
        <div  className="flexBetweenCenter filters">
          <div
            onClick={() => {
              setShowMoreFilters((prev) => !prev);
            }}
             className="moreFilters pointer"
          >
            <img
              src="/assets/image/filtersIcon.svg"
              alt="filter"
               className="mr-2"
            />
            <span>
              {showMoreFilters ? "Hide filters" : "More filters"}{" "}
              <> &#129170; </>
            </span>
          </div>
          <SelectInput
            topClass="inputWrapper"
            field={{ value: filterState.sortBy }}
            form={{ touched: {}, errors: {} }}
            type="select"
            options={sortByOptions}
            onChange={(e) => setStateByName("sortBy", e.target.value)}
            noFormik
          />
        </div>
      </div>
    </div>
  );
}
