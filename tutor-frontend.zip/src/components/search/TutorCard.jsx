import React from "react";
import { Link } from "react-router-dom";
import StarRatings from "react-star-ratings";
import { ETeach_Type } from "../../enums/tutor";
import { getImageUrl } from "../../helpers";

export default function TutorCard({ data }) {
  const pricingArr =
    data?.schedule?.class_time.length > 0 ? data?.schedule?.class_time : null;
  console.log({ pricingArr, name: data?.user_id?.first_name });
  // main return
  return (
    <div  className="tutorCard d-flex">
      <div>
        <Link to={`/profile/${data?.user_id._id}`}>
          <img
            src={
              data?.user_id?.profile_pic
              ? getImageUrl(data?.user_id?.profile_pic)
              : "/assets/image/defaultProfile.svg"
            }
            alt="profile"
            className="profile"
          />
        </Link>
        <div  className="headTwo">
          <p>77 lessons</p>
          <div  className="flexCenter location">
            {data?.teach_type.includes(ETeach_Type.ONLINE) && (
              <img src="/assets/image/tcard1.svg" alt="svg" />
            )}
            {data?.teach_type.includes(ETeach_Type.TUTOR_HOME) && (
              <img src="/assets/image/tcard2.svg" alt="svg" />
            )}
            {data?.teach_type.includes(ETeach_Type.STUDENT_HOME) && (
              <img src="/assets/image/tcard3.svg" alt="svg" />
            )}
          </div>
        </div>
      </div>
      <div style={{ flex: 1 }}>
        <div  className="flexCenter headFlex">
          <div  className="flexBetweenCenter  content">
            <div  className="details">
              <div  className="flexCenter mb-4">
                <Link to={`/profile/${data?.user_id._id}`}>
                  <h1>
                    {data?.user_id?.first_name} {data?.user_id?.last_name}
                  </h1>
                </Link>
                {data?.userId?.featured && <div  className="tag">Featured</div>}
              </div>
              <div
                className="flexBetweenCenter mt-2"
                style={{ width: "330px" }}
              >
                <div>
                  <p>Teaches</p>
                  <h2>
                    {data?.you_teach.map((item, index) =>
                      index === 0 ? `${item}` : `, ${item}`
                    )}
                  </h2>
                </div>
                <div  className="ml-2" style={{ minWidth: '140px' }}>
                  <p>Language(s)</p>
                  <h2>
                    {data?.teach_language.map((item, index) =>
                      index === 0 ? `${item}` : `, ${item}`
                    )}
                  </h2>
                </div>
              </div>
              <div  className="flexBetweenCenter mt-2 d-flex d-md-none">
                <div>
                  <p>Levels</p>
                  <h2>
                    {data?.level_you_teach.map((item, index) =>
                      index === 0 ? `${item}` : `, ${item}`
                    )}
                  </h2>
                </div>
                <div>
                  <p>Age teachable</p>
                  <h2>
                    {data?.student_age_you_teach?.map((item, index) =>
                      index === 0
                        ? `${item.from_age} - ${item.to_age}`
                        : `, ${item.from_age} - ${item.to_age}`
                    )}
                  </h2>
                </div>
              </div>
            </div>
            <div  className="priceSec">
              {pricingArr ? (
                <h1>
                  ${pricingArr[0].price}/{pricingArr[0].time} min
                </h1>
              ) : (
                <h1>NA</h1>
              )}

              <div  className="starRating">
                <StarRatings
                  rating={data.rating}
                  starRatedColor="#EFC282"
                  numberOfStars={5}
                  starDimension="32px"
                  starSpacing="1px"
                  name="rating"
                />
              </div>
              <p>{data.reviews.length} reviews</p>
            </div>
          </div>
        </div>
        <div  className="flexCenter headFlex">
          <div  className="flexBetweenCenter  w-100">
            <div
              className="flexBetweenCenter d-none d-md-flex"
              style={{ width: "330px", flexWrap: "nowrap", marginLeft: '30px' }}
            >
              <div style={{ maxWidth: "200px", marginRight: "20px" }}>
                <p>Levels</p>
                <h2>
                  {data?.level_you_teach.map((item, index) =>
                    index === 0 ? `${item}` : `, ${item}`
                  )}
                </h2>
              </div>
              <div style={{ minWidth: '140px' }}>
                <p>Age teachable</p>
                <h2>
                  {data?.student_age_you_teach?.map((item, index) =>
                    index === 0
                    ? `${item.from_age} - ${item.to_age}`
                    : `, ${item.from_age} - ${item.to_age}`
                  )}
                </h2>
              </div>
            </div>
            <button  className="primaryButton green">Schedule lesson</button>
          </div>
        </div>
      </div>
    </div>
  );
}
