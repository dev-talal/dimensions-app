import React, { useEffect, useState } from 'react';

const CitiesList = ({ country }) => {
  const [cities, setCities] = useState([]);
  
  useEffect(() => {
    const fetchCities = async () => {
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?address=${'Pakistan'}&components=country:${'PK'}&key=AIzaSyC5ftCIBYV8wYwS5IAC0qh2SrbQMrDxZgs`
      );  
      const data = await response.json();
      const cities = data.results.filter((result) =>
        result.types.includes('locality')
      );
      setCities(cities);
    };
    if (country) {
      fetchCities();
    }
  }, [country]);

  if (!country) {
    return null;
  }

  return (
    <ul>
      {cities.map((city) => (
        <li key={city.place_id}>{city.formatted_address}</li>
      ))}
    </ul>
  );
};

export default CitiesList;