import React from "react";
import {
  genderOptions,
  teachLanguageOptions,
} from "../../views/web/search/constant";
import { SelectInput } from "../basic/RenderInputs";
import { ReactSearchAutocomplete } from 'react-search-autocomplete';
export default function MoreFilters({
  showMoreFilters,
  filterState,
  setStateByName,
  reset,
}) {
  const itemsAge = [
    {
      id: 0,
      name: '18'
    },
    {
      id: 1,
      name: '20'
    },
    {
      id: 2,
      name: '22'
    },
    {
      id: 3,
      name: '24'
    },
    {
      id: 4,
      name: '26'
    }
  ]
  const itemsCategory = [
    {
      id: 0,
      name: 'Biology'
    },
    {
      id: 1,
      name: 'Computer Sciene'
    },
    {
      id: 1,
      name: 'Physics'
    }
  ]
  const itemsSubCategory = [
    {
      id: 0,
      name: 'Python'
    },
    {
      id: 1,
      name: 'Java'
    },
    {
      id: 1,
      name: 'C++'
    }
  ]
  const styling = {
    backgroundColor: '#fff',
    boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.07)',
    borderRadius: '10px',
    height: '45px',
    zIndex: '99',
    fontSize: '0.9rem',
    fontFamily: 'poppins',
    color: '#0a0d31'
  }
  return (
    <section  className="moreFiltersSec" hidden={!showMoreFilters}>
      <div  className="container-fluid">
        <div  className="row mb-2 mt-2">
          <div  className="col-md-8">
            <label>Tutor language</label>
            <SelectInput
              field={{ value: filterState.teach_language }}
              form={{ touched: {}, errors: {} }}
              type="select"
              options={teachLanguageOptions}
              onChange={(e) => setStateByName("teach_language", e.target.value)}
              noFormik
            />
          </div>
          <div  className="col-md-4">
            <label>Field / Parent category</label>
            <ReactSearchAutocomplete
              placeholder="i.e Computer Science"
              items={itemsCategory}
              onSelect = {(item)=> setStateByName("main_field", item.name) }
              styling={styling}
              showItemsOnFocus
              onClear={ () => setStateByName("main_field", '')  }
            />
            {/* <input
              type="text"
               className="textInput"
              value={filterState.main_field}
              placeholder="i.e Computer Science"
              onChange={(e) => setStateByName("main_field", e.target.value)}
            /> */}
          </div>
        </div>
        <div  className="row mb-3">
          <div  className="col-md-4">
            <label>Sub-category</label>
            {/* <input
              type="text"
               className="textInput"
              placeholder="i.e Python"
              value={filterState.sub_field}
              onChange={(e) => setStateByName("sub_field", e.target.value)}
            /> */}
            <ReactSearchAutocomplete
              placeholder="i.e Python"
              items={itemsSubCategory}
              onSelect = {(item)=> setStateByName("sub_field", item.name) }
              styling={styling}
              showItemsOnFocus
              onClear={ () => setStateByName("sub_feld", '')  }
            />
          </div>
          <div  className="col-md-4">
            <label>Age of student</label>
            <ReactSearchAutocomplete
              items={itemsAge}
              onSelect = {(item)=> setStateByName("age", item.name) }
              onClear={ () => setStateByName("age", '')  }
              styling={styling}
              showItemsOnFocus
            />
          </div>
          <div  className="col-md-4">
            <label>level</label>
            <input
              type="text"
               className="textInput"
              placeholder="Any"
              value={filterState.level}
              onChange={(e) => setStateByName("level", e.target.value)}
            />
          </div>
        </div>
        <div  className="row">
          <div  className="col-md-4">
            <label>Tutor gender</label>
            <SelectInput
              field={{ value: filterState.gender }}
              form={{ touched: {}, errors: {} }}
              type="select"
              options={genderOptions}
              onChange={(e) => setStateByName("gender", e.target.value)}
              noFormik
            />
          </div>
          <div  className="col-md-4">
            <label>Location</label>
            <input
              type="text"
               className="textInput"
              placeholder="All"
              value={filterState.location}
              onChange={(e) => setStateByName("location", e.target.value)}
            />
          </div>
          <div  className="col-md-4">
            <div  className="resetFilters poppinsSb" onClick={reset}>
              <img src="/assets/image/resend.svg" alt="svg"  className="mr-2" />
              <span>Reset all</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
