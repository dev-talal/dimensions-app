import { FormGroup, Label, Input } from "reactstrap";
import InputMask from "react-input-mask";
import { ErrorMessage } from "formik";
import "./inputs.css";
// simple text input
export const TextInput = ({ field, form: { touched, errors }, ...props }) => {
  return (
    <FormGroup className={`customInputDiv ${props?.topClass}`}>
      {props.label && <Label className="label">{props.label}</Label>}
      <Input
        invalid={touched[field.name] && errors[field.name]}
        {...field}
        {...props}
        className={`textInput ${props?.inputClassName}`}
      ></Input>
      <ErrorMessage name={field.name} className="errorText">
        {(msg) => <div className="errorText">{msg} </div>}
      </ErrorMessage>
    </FormGroup>
  );
};

// selectinput
export const SelectInput = ({ field, form: { touched, errors }, ...props }) => {
  return (
    <FormGroup className={`customInputDiv ${props?.topClass}`}>
      {props.label && <Label className="label">{props.label}</Label>}
      <Input
        invalid={touched[field.name] && errors[field.name]}
        {...field}
        {...props}
        className={`textInput select ${props?.inputClassName} ${
          field.value ? "" : "placeholder"
        }`}
      >
        {props?.placeholder && (
          <option value="" disabled hidden selected className="placeholder">
            {props?.placeholder}
          </option>
        )}
        {props?.options?.map((item, index) => (
          <option value={item.value} key={index}>
            {item.text}
          </option>
        ))}
      </Input>
      {props.noFormik || (
        <ErrorMessage name={field.name} className="errorText">
          {(msg) => <div className="errorText">{msg} </div>}
        </ErrorMessage>
      )}
    </FormGroup>
  );
};

// // switchInput
// export const SwitchInput = ({ field, form, ...props }) => {
//   return (
//     <div  className={` ${props?.topClass}`}>
//       <CustomInput
//         {...field}
//         {...props}
//         id="exampleCustomSwitch4"
//          className={` ${props?.inputClassName}`}
//       ></CustomInput>
//       <ErrorMessage name={field.name}  className="errorText">
//         {(msg) => <div  className="errorText">{msg} </div>}
//       </ErrorMessage>
//     </div>
//   );
// };

export const FileInput = ({
  field: { onChange, value, ...field },
  form: { touched, errors, setFieldValue },
  ...props
}) => {
  return (
    <FormGroup className={`customInputDiv ${props?.topClass}`}>
      {props.label && <Label className="label">{props.label}</Label>}

      <Input
        invalid={touched[field.name] && errors[field.name]}
        onChange={(e) => {
          if (!e.target.files) return;

          setFieldValue(field.name, e.target.files[0]);
        }}
        {...field}
        {...props}
        className={`textInput ${props?.inputClassName} pt-1`}
      ></Input>
      <ErrorMessage name={field.name} className="errorText">
        {(msg) => <div className="errorText">{msg} </div>}
      </ErrorMessage>
    </FormGroup>
  );
};

// simple text input
export const ChechBoxInput = ({
  field,
  form: { touched, errors },
  ...props
}) => {
  return (
    <FormGroup className={`${props?.topClass}`} check>
      <Input
        invalid={touched[field.name] && errors[field.name]}
        {...field}
        {...props}
        className={`${props?.inputClassName}`}
        type="checkbox"
      />
      {props.label && (
        <Label
          check
          dangerouslySetInnerHTML={{ __html: props.label }}
          for={field.name}
        ></Label>
      )}
      <ErrorMessage name={field.name} className="errorText">
        {(msg) => <div className="errorText">{msg} </div>}
      </ErrorMessage>
    </FormGroup>
  );
};

// simple masked input
export const TextMaskInput = ({
  field,
  form: { touched, errors },
  ...props
}) => {
  return (
    <FormGroup className={`customInputDiv ${props?.topClass}`}>
      {props.label && <Label className="label">{props.label}</Label>}
      <InputMask
        invalid={touched[field.name] && errors[field.name]}
        {...field}
        {...props}
        className={`textInput ${props?.inputClassName}`}
      ></InputMask>
      <ErrorMessage name={field.name} className="errorText">
        {(msg) => <div className="errorText">{msg} </div>}
      </ErrorMessage>
    </FormGroup>
  );
};
