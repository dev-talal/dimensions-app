import { Field, Form, Formik } from "formik";
import React from "react";
import { Row , Col } from "react-bootstrap";
import { ChechBoxInput, TextInput } from "../basic/RenderInputs";
import SettingAccordion from "./settingAccordion";

export default function AboutSec({
  user,
  data,
  updateProfile,
  loading,
  isIndividual,
}) {
  const formInitialValues = {
    first_name: user.first_name,
    last_name: user.last_name,
    hide_parent: data?.hide_parent,
  };

  const handleSubmit = (formValues) => {
    updateProfile(formValues);
  };

  // main return
  return (
    <SettingAccordion label="About">
      <div>
        <Formik
          initialValues={formInitialValues}
          enableReinitialize
          onSubmit={handleSubmit}
        >
          <Form  className="mt-2 pb-4">
            <Row>
              <Col lg={6}>
                <Field
                  name="first_name"
                  component={TextInput}
                  placeholder="First Name"
                  label="First name"
                />
              </Col>
              <Col lg={6}>
                <Field
                  name="last_name"
                  component={TextInput}
                  placeholder="Last Name"
                  label="Last name"
                />
              </Col>
              <Col lg={12}>
                {isIndividual || (
                  <Field
                    id="hide_parent"
                    name="hide_name"
                    component={ChechBoxInput}
                    label={`Hide my name and surname and show me as A PARENT`}
                  />
                )}
              </Col>
              <Col lg={12}>
                <button
                  disabled={loading}
                  type="submit"
                  className="primaryButton green mb-2"
                >
                  {loading ? " updating..." : "Save Profile"}
                </button>
              </Col>
            </Row>
          </Form>
        </Formik>
      </div>
    </SettingAccordion>
  );
}
