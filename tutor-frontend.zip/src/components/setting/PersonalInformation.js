import { Field, Form, Formik } from "formik";
import React from "react";
import { Row , Col } from "react-bootstrap";
import { TextInput } from "../basic/RenderInputs";
import SettingAccordion from "./settingAccordion";

export default function PersonalInformation({
  data,
  updateProfile,
  loading,
  isTutor,
}) {
  const formInitialValues = {
    email: data?.email,
    phone_number: data?.phone_number,
    location: data?.location,
  };

  const handleSubmit = (formValues) => {
    updateProfile(formValues);
  };

  // main return
  return (
    <SettingAccordion
      label={isTutor ? "Contact information" : "Personal information"}
    >
      <div className=" pb-4">
        <p  className="textGrey mb-2">
          This won’t be a part of your public profile.
        </p>
        <Formik
          initialValues={formInitialValues}
          enableReinitialize
          onSubmit={handleSubmit}
        >
          <Form  className="mt-2">
            <Row>
              <Col lg={6}>
                <Field
                  name="email"
                  component={TextInput}
                  placeholder="Email"
                  label="Email"
                  disabled
                />
              </Col>
              <Col lg={6}>
                <Field
                  name="phone_number"
                  component={TextInput}
                  placeholder="Phone Number"
                  label="Phone  Number"
                />
              </Col>
              <Col lg={6}>
                <Field
                  name="location"
                  component={TextInput}
                  placeholder="Location"
                  label="Location"
                />
              </Col>
            </Row>
            <button
              disabled={loading}
              type="submit"
               className="primaryButton green mb-2"
            >
              {loading ? " updating..." : "Save Profile"}
            </button>
          </Form>
        </Formik>
      </div>
    </SettingAccordion>
  );
}
