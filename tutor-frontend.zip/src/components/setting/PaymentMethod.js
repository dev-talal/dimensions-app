import { Field, Form, Formik } from "formik";
import React, { useState } from "react";
import { Row , Col } from "react-bootstrap";
import { useQuery } from "react-query";
import {
  addPaymentMethod,
  deletePaymentMethod,
  getAllPaymentMethod,
  updatePaymentMethod,
} from "../../api";
import useFilterItem from "../../helpers/hooks/mutations/useFilterItem";
import useNewItemMutation from "../../helpers/hooks/mutations/useNewItemMutation";
import useUpdateQueryItem from "../../helpers/hooks/mutations/useUpdateQueryItem";
import { TextInput, TextMaskInput } from "../basic/RenderInputs";
import SettingAccordion from "./settingAccordion";

export default function PaymentMethod() {
  // fetching all kids
  const { data, isLoading } = useQuery("paymentMethod", getAllPaymentMethod);
  const paymentMethods = data?.data?.payment_detail || [];

  const [editData, setEditData] = useState(null);

  // payment mutation
  const addPaymentMethodFun = useNewItemMutation(
    "paymentMethod",
    addPaymentMethod,
    false,
    "payment_detail"
  );
  const deletePaymentMethodFun = useFilterItem(
    "paymentMethod",
    deletePaymentMethod,
    "payment_detail"
  );
  const updatePaymentMethodFun = useUpdateQueryItem(
    "paymentMethod",
    updatePaymentMethod,
    false,
    "payment_detail"
  );

  // init form
  const formInitialValues = {
    name_on_card: editData ? editData.name_on_card : "",
    card_number: editData ? editData.card_number : "",
    exp_date: editData ? editData.exp_date : "",
    cvv: editData ? editData.cvv : "",
  };

  // handle submit
  const handleSubmit = (formValues, formikFun) => {
    const updateData = { id: editData?._id, data: formValues };
    const data = { ...formValues };
    console.log({ formValues });
    editData
      ? updatePaymentMethodFun.mutate(updateData)
      : addPaymentMethodFun.mutate(data);

    setEditData(null);
    formikFun.resetForm();
  };

  // main return
  return (
    <SettingAccordion label="Payment Method">
      <div  className="paymentMethod">
        {isLoading ||
          (paymentMethods?.length > 0 && <h1> Saved PAYMENT METHOD </h1>)}
        <div  className=" mb-2">
          {isLoading ||
            (paymentMethods?.length > 0 &&
              paymentMethods?.map((item) => {
                return (
                  <div key={item._id}  className="flexBetweenCenter payment">
                    <div  className="flexCenter">
                      <img
                        src="/assets/image/visaIcon.svg"
                        alt="visaIcon"
                         className="mr-2"
                      />
                      <span>
                        ****{" "}
                        {item?.card_number?.substr(
                          item.card_number?.length - 4
                        )}
                      </span>
                    </div>
                    <div  className="flexCenter">
                      <div
                        onClick={() => deletePaymentMethodFun.mutate(item._id)}
                         className="poppinsBd pointer  mr-2"
                      >
                        Delete
                      </div>
                      <div
                        onClick={() => setEditData(item)}
                         className="poppinsBd pointer textPrimary"
                      >
                        Edit
                      </div>
                    </div>
                  </div>
                );
              }))}
        </div>
        <h1> ADD PAYMENT METHOD </h1>

        <Formik
          initialValues={formInitialValues}
          enableReinitialize
          onSubmit={handleSubmit}
        >
          <Form  className="mt-2">
            <Row>
              <Col lg={6}>
                <Field
                  name="name_on_card"
                  component={TextInput}
                  placeholder="Name on card"
                  label="Name on card"
                />
              </Col>
              <Col lg={6}>
                <Field
                  name="card_number"
                  component={TextMaskInput}
                  placeholder="Card number"
                  label="Card number"
                  mask="9999 9999 9999 9999"
                  maskChar=" "
                />
              </Col>
              <Col lg={6}>
                <Field
                  name="exp_date"
                  component={TextMaskInput}
                  placeholder="Expiration date"
                  label="Expiration date"
                  mask="99/99"
                  maskChar=" "
                />
              </Col>
              <Col lg={6}>
                <Field
                  name="cvv"
                  component={TextMaskInput}
                  placeholder="CVV"
                  label="CVV"
                  mask="9999"
                  maskChar=" "
                />
              </Col>
            </Row>
            <button type="submit"  className="primaryButton green mb-2">
              Save Profile
            </button>
          </Form>
        </Formik>
      </div>
    </SettingAccordion>
  );
}
