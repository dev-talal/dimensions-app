import React, { useState } from "react";

export default function SettingAccordion({ children, label }) {
  const [show, setshow] = useState(false);
  return (
    <>
      <div
        onClick={() => setshow((prev) => !prev)}
         className="settingAccordion"
      >
        {label}{" "}
        {show ? (
          <img src="/assets/image/arrowDownPrimary.svg" alt="svg" />
        ) : (
          <> &#129170; </>
        )}
      </div>
      {show && children && <div>{children}</div>}
    </>
  );
}
