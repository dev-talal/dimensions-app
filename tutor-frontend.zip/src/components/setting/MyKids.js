import React from "react";
import history from "../../helpers/history";
import SettingAccordion from "./settingAccordion";

export default function MyKids({ data }) {
  const allKids = data?.kids;
  // main return
  return (
    <div>
      <SettingAccordion label="My Kids">
        <div  className="setupKids d-block pb-4">
          {" "}
          <div  className="flexCenter tagWrapper">
            {allKids?.length > 0 ? (
              allKids?.map((item) => {
                return (
                  <div key={item?._id}  className="tag">
                    <span>{`${item.first_name} ${item.last_name}`}</span>
                    <img
                      src="/assets/image/editKidIcon.svg"
                      alt="icon"
                       className="pointer mx-2"
                      onClick={() => history.push("/profile-setup/add-kids")}
                    />
                    <img
                      src="/assets/image/deleteKidIcon.svg"
                      alt="icon"
                       className="pointer"
                      onClick={() => history.push("/profile-setup/add-kids")}
                    />
                  </div>
                );
              })
            ) : (
              <div  className="tag">No student added yet</div>
            )}
          </div>
          <button
            type="submit"
             className="primaryButton green mt-0 mb-2"
            onClick={() => history.push("/profile-setup/add-kids")}
          >
            + Add new kids
          </button>
        </div>
      </SettingAccordion>
    </div>
  );
}
