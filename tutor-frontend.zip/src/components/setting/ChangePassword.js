import { Field, Form, Formik } from "formik";
import React from "react";
import { TextInput } from "../basic/RenderInputs";
import SettingAccordion from "./settingAccordion";
import * as Yup from "yup";
import { Col, Row } from "react-bootstrap";

export default function ChangePassword({ updateProfile, loading }) {
  const formInitialValues = {
    old_password: "",
    new_password: "",
    confirm_password: "",
  };
  //   validation schemea
  const validationSchema = Yup.object().shape({
    new_password: Yup.string()
      .required("Please enter a passowrd")
      .min(8, "Password must be upto 8 Charachters"),
    confirm_password: Yup.string().oneOf(
      [Yup.ref("new_password"), null],
      "Passwords must match"
    ),
  });

  const handleSubmit = (formValues) => {
    updateProfile(formValues);
  };

  // main return
  return (
    <SettingAccordion label="Change password">
      <div className="pb-4">
        <Formik
          initialValues={formInitialValues}
          enableReinitialize
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          <Form  className="mt-2">
            <Row>
              <Col lg={6}>
                <Field
                  name="old_password"
                  component={TextInput}
                  placeholder="Old Password"
                  label="Old Password"
                  type="password"
                />
              </Col>
              <Col lg={6}>
                <Field
                  name="new_password"
                  component={TextInput}
                  placeholder="New Password"
                  label="New Password"
                  type="password"
                />
              </Col>
              <Col lg={6}>
                <Field
                  name="confirm_password"
                  component={TextInput}
                  placeholder="Confirm Password"
                  label="Confirm Password"
                  type="password"
                />
              </Col>
            </Row>
            <button
              disabled={loading}
              type="submit"
               className="primaryButton green mb-2"
            >
              {loading ? " updating..." : "Save Profile"}
            </button>
          </Form>
        </Formik>
      </div>
    </SettingAccordion>
  );
}
