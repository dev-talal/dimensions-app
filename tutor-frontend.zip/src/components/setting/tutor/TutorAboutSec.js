import { Field, Form, Formik } from "formik";
import React, { useState } from "react";
import { Row, Col } from "react-bootstrap";
import {
  countryOptions,
  initEducationObj,
  initExperinceObj,
  yearOptions,
} from "../../../views/web/profileSetup/constant";
import {
  ChechBoxInput,
  SelectInput,
  TextInput,
} from "../../basic/RenderInputs";
import SettingAccordion from "../settingAccordion";
import * as Yup from "yup";
import { Pencil, Trash } from "react-bootstrap-icons";

export default function TutorAboutSec({ user, data, updateProfile, loading }) {
  const [first_name, setFirstname] = useState(user.first_name || "");
  const [last_name, setLastName] = useState(user.last_name || "");
  const [intro, setintro] = useState(data.intro || "");
  const [about_you, setAbout_you] = useState(data.about_you || "");
  const [education, setEducation] = useState(data.education || []);
  const [experience, setExperince] = useState(data.experience || []);
  const [initExpObj,setExpObj] = useState(initExperinceObj);
  const [isEditTime, setIsEditTime] = useState({is:false,type:"",index:""});
  const [initEObj,setEObj] = useState(initEducationObj);
  //   validation schemea
  const EducationValidationSchema = Yup.object().shape({
    name_of_institution: Yup.string().required(
      "Please Enter the name of institution"
    ),
    degree_title: Yup.string().required("Please Enter the degree title"),
    country: Yup.string().required("Please Enter the country"),
    city: Yup.string().required("Please Enter the city"),
  });
  const ExperinceValidationSchema = Yup.object().shape({
    teaching_place: Yup.string().required(
      "Please Enter the name of instituation"
    ),
    from_year: Yup.string().required("Please select starting date"),
    short_description: Yup.string().required(
      "Please enter a short description"
    ),
  });

  // on education add
  const onEducationAdd = (formValues, formikFun) => {
    const {is,index,type} = isEditTime;
    if(is && type=="education"){
      setEducation([
        ...education.slice(0, index),
        formValues,
        ...education.slice(index + 1, education.length)
      ]);
      setIsEditTime({is:false,type:"",index:""});
    }else{
      setEducation((prev) => [...prev, formValues]);
    }
    setEObj(initEducationObj);
    formikFun.resetForm();
  };
  const infoEdit = (obj,index,type) => {
    const updatedTodos =  obj[index];
    setIsEditTime({is:true,type:type,index:index});
    if(type=="experience"){
      setEObj(initEducationObj);
      setExpObj(updatedTodos);
    }else{
      setExpObj(initExperinceObj);
      setEObj(updatedTodos);
    }
    
  }
  // on experience add
  const onExperinceAdd = (formValues, formikFun) => {
    const {is,index,type} = isEditTime;
    if(is && type=="experience"){
      setExperince([
        ...experience.slice(0, index),
        formValues,
        ...experience.slice(index + 1, experience.length)
      ]);
      setIsEditTime({is:false,type:"",index:""});
    }else{
      setExperince((prev) => [...prev, formValues]);
    }
    setExpObj(initExperinceObj);
    formikFun.resetForm();
  };

  //   on Profile update
  const onProfileUpdate = () => {
    const data = {
      first_name,
      last_name,
      intro,
      about_you,
      education,
      experience,
    };
    updateProfile({ ...data });
  };
  const delItem = (data,dataUpdate,index) => {
    const result = data.filter((x,i)=>i!==index);
    setIsEditTime({is:false,type:"",index:""});
    dataUpdate(result);
  }
  // main return
  return (
    <SettingAccordion label="About">
      <div className="container-fluid profileAbout">
        <Row>
          <Col lg={6}>
            <input
              type="text"
              className="textInput mt-3"
              placeholder="First name"
              value={first_name}
              onChange={(e) => setFirstname(e.target.value)}
            />
          </Col>
          <Col lg={6}>
            <input
              type="text"
              className="textInput mt-3 "
              placeholder="Last name"
              value={last_name}
              onChange={(e) => setLastName(e.target.value)}
            />
          </Col>
          <Col lg={12}>
            <input
              type="text"
              className="textInput mt-3  "
              placeholder="Short introduction"
              value={intro}
              onChange={(e) => setintro(e.target.value)}
            />
          </Col>
          <Col lg={12}>
            <textarea
              rows="5"
              className="textInput mt-3 mb-3"
              placeholder="Tell something about you"
              value={about_you}
              onChange={(e) => setAbout_you(e.target.value)}
              style={{ height: 150 }}
            />
          </Col>
        </Row>
        <h1 className="title mb-0">Education</h1>
        <div className="flexCenter">
          {education.map((item, index) => {
            return (
              <div key={index} className="eduDetail pt-3">
                <div className="w-100 d-flex mb-2 justify-content-end">
                  <span type="button" className="mr-3 text-danger" onClick={()=>delItem(education,setEducation,index)}>
                    <Trash size={18} />
                  </span>
                  <span className="d-block">
                    <Pencil color="#007bff"  type="button" className="mr-2" onClick={() => infoEdit(education,index,"education")} size={17} />
                  </span>
                </div>
                <div className="eduBox">
                  <img src="/assets/image/eduCap.svg" alt="eduCap" />
                </div>
                <div>
                  <h3>
                    {item.name_of_institution}, {item.country}.
                  </h3>
                  <h4>{item.degree_title}</h4>
                  <div className="flexBetweenCenter">
                    <p>
                      &#x25CF; {item.city}, {item.country}.
                    </p>

                    <p>
                      &#x25CF;{" "}
                      {item.currently_enrolled
                        ? "Present"
                        : item.completion_year}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <Formik
          initialValues={initEObj}
          validationSchema={EducationValidationSchema}
          onSubmit={onEducationAdd}
          enableReinitialize
        >
          <Form className="mt-3">
            <Row>
              <Col lg={6}>
                <Field
                  component={TextInput}
                  name="name_of_institution"
                  placeholder="Name of Institution"
                />
              </Col>
              <Col lg={6}>
                <Field
                  component={TextInput}
                  name="degree_title"
                  placeholder="Degree title"
                />
              </Col>
              <Col lg={6}>
                <Field
                  component={SelectInput}
                  name="country"
                  placeholder="Country"
                  options={countryOptions}
                  type="select"
                />
              </Col>
              <Col lg={6}>
                <Field component={TextInput} name="city" placeholder="City" />
              </Col>
              <Col lg={12}>
                <Field
                  component={SelectInput}
                  name="completion_year"
                  placeholder="Completion year"
                  options={yearOptions}
                  type="select"
                />
              </Col>
              <Col lg={12}>
                <Field
                  id="currently_enrolled"
                  name="currently_enrolled"
                  component={ChechBoxInput}
                  label={`Currently enrolled`}
                />
              </Col>
              <Col lg={12}>
                <div className="flexCenter justify-content-start">
                  <button
                    type="submit"
                    className="primaryButton outline addBtn"
                  >
                    {isEditTime.type=="education"?"Update":"Add"}
                  </button>
                </div>
              </Col>
            </Row>
          </Form>
        </Formik>
        <h1 className="title mt-5 mb-0">Experience</h1>
        <div className="flexCenter">
          {experience.map((item, index) => {
            return (
              <div key={index} className="eduDetail pt-3">
                <div className="w-100 d-flex mb-2 justify-content-end">
                  <span type="button" className="mr-3 text-danger" onClick={()=>delItem(experience,setExperince,index)}>
                    <Trash size={18} />
                  </span>
                  <span className="d-block">
                    <Pencil color="#007bff"  type="button" className="mr-2" onClick={() => infoEdit(experience,index,"experience")} size={17} />
                  </span>
                </div>
                <div>
                  <h3>&#x25CF; {item.teaching_place}</h3>
                  <p>
                    {item.from_year}-
                    {item.currently_working_here ? "present" : item.to_year}
                  </p>
                  <h4>{item.short_description}</h4>
                </div>
              </div>
            );
          })}
        </div>
        <Formik
          initialValues={initExpObj}
          validationSchema={ExperinceValidationSchema}
          onSubmit={onExperinceAdd}
          enableReinitialize
        >
          <Form className="mt-3">
            <Field
              component={TextInput}
              name="teaching_place"
              placeholder="Work experience"
            />

            <div className="row">
              <div className="col-md-6">
                <Field
                  component={SelectInput}
                  name="from_year"
                  placeholder="From year"
                  options={yearOptions}
                  type="select"
                />
              </div>
              <div className="col-md-6">
                <Field
                  component={SelectInput}
                  name="to_year"
                  placeholder="To year"
                  options={yearOptions}
                  type="select"
                />
              </div>
            </div>
            <Field
              component={TextInput}
              name="short_description"
              placeholder="Short description"
            />
            <Field
              id="currently_working_here"
              name="currently_working_here"
              component={ChechBoxInput}
              label={`Currently working here`}
            />

            <div className="flexCenter justify-content-start align-items-center pb-5">
              <button type="submit" className="primaryButton outline addBtn mr-3">
                {isEditTime.type=="experience"?"Update":"Add"}
              </button>
              <button
                disabled={loading}
                onClick={onProfileUpdate}
                className="primaryButton green"
                type="button"
              >
                {loading ? " updating..." : "Save Profile"}
              </button>
            </div>
          </Form>
        </Formik>
      </div>
    </SettingAccordion>
  );
}
