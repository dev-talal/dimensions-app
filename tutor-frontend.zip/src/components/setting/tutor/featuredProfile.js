import React from "react";
import SettingAccordion from "../settingAccordion";

export default function FeaturedListing() {
  // main return
  return (
    <SettingAccordion label="Featured listing">
      <div  className="paymentMethod">
        <h1> FEATURED PROFILE </h1>
        <h3  className="poppinsBd">$9.9/month </h3>
        <p  className="textGrey mt-2 mb-3">
          Make your profile featured that could help boost the chances of
          students book a class with you.{" "}
        </p>
      </div>
    </SettingAccordion>
  );
}
