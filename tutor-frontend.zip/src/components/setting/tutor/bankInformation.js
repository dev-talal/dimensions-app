import { Field, Form, Formik } from "formik";
import React from "react";
import { ChechBoxInput, TextInput } from "../../basic/RenderInputs";
import SettingAccordion from "../settingAccordion";

export default function BankInfromation({ data, updateProfile, loading }) {
  const formInitialValues = {
    SWIFT_code: data.SWIFT_code || "",
    bank_name: data.bank_name || "",
    IBAN_number: data.IBAN_number || "",
    branch_name: data.branch_name || "",
    branch_address: data.branch_address || "",
    branch_account_type: data.branch_account_type || "",
    branch_on_account: data.branch_on_account || "",
  };

  const handleSubmit = (formValues) => {
    updateProfile({ bank_info: formValues });
  };

  // main return
  return (
    <SettingAccordion label="Bank Information">
      <div className="pb-4">
        <Formik
          initialValues={formInitialValues}
          enableReinitialize
          onSubmit={handleSubmit}
        >
          <Form  className="mt-2">
            <Field
              name="SWIFT_code"
              component={TextInput}
              placeholder="SWIFT code"
              label="SWIFT code"
            />
            <Field
              name="bank_name"
              component={TextInput}
              placeholder="Bank name"
              label="Bank name"
            />
            <div  className="title mb-1 mt-3" style={{ fontSize: "15px" }}>
              Account holder bank information{" "}
            </div>
            <Field
              name="IBAN_number"
              component={TextInput}
              placeholder="IBAN number"
              label="IBAN number"
            />
            <Field
              name="branch_name"
              component={TextInput}
              placeholder="Branch name"
              label="Branch name"
            />
            <Field
              name="branch_address"
              component={TextInput}
              placeholder="Branch address"
              label="Branch address"
            />
            <Field
              name="branch_account_type"
              component={TextInput}
              placeholder="Bank account type"
              label="Bank account type"
            />
            <Field
              name="branch_on_account"
              component={TextInput}
              placeholder="Name on account"
              label="Full name on account"
            />
            <button
              disabled={loading}
              type="submit"
               className="primaryButton green mb-2"
            >
              {loading ? " updating..." : "Save Profile"}
            </button>
          </Form>
        </Formik>
      </div>
    </SettingAccordion>
  );
}
