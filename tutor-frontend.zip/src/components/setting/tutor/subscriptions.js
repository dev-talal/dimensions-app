import React, { useState } from "react";
import SettingAccordion from "../settingAccordion";

export default function Subscriptions() {
  // main return
  return (
    <SettingAccordion label="Subscription">
      <div  className="paymentMethod">
        <h1> MONTHLY SUBSCRIPTIONS </h1>
        <h3  className="poppinsBd">$17.9/month </h3>
        <p  className="textGrey mt-2 mb-3">Renews on 26/06/2021. </p>
      </div>
    </SettingAccordion>
  );
}
