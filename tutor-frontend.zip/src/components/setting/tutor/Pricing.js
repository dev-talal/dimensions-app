import React, { useState } from "react";
import { ChechBoxInput, TextInput } from "../../basic/RenderInputs";
import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import SettingAccordion from "../settingAccordion";

const Pricing = ({ data, updateProfile, loading }) => {
  // validations
  const validationSchema = data.class_type.includes("group_class")
    ? Yup.object().shape({
        hourly_rate: Yup.number().required("Please Enter the hourly rate"),

        thirty_min_rate: Yup.number().required("Please Enter the 30 min rate"),
        weekly_pkg_rate: Yup.number().required("Please Enter weekly charges"),
        fortnightly_pkg_rate: Yup.number().required(
          "Please Enter the fortnightly rate"
        ),
        monthly_pkg_rate: Yup.number().required(
          "Please Enter the monthly package rate"
        ),
        three_std_grp_rate: Yup.number().required(
          "Please Enter the 3 student group rate per month"
        ),
        five_std_grp_rate: Yup.number().required(
          "Please Enter the 5 student group rate per month"
        ),
        seven_std_grp_rate: Yup.number().required(
          "Please Enter the 7 student group rate per month"
        ),
      })
    : Yup.object().shape({
        hourly_rate: Yup.number().required("Please Enter the hourly rate"),

        thirty_min_rate: Yup.number().required("Please Enter the 30 min rate"),
        weekly_pkg_rate: Yup.number().required("Please Enter weekly charges"),
        fortnightly_pkg_rate: Yup.number().required(
          "Please Enter the fortnightly rate"
        ),
        monthly_pkg_rate: Yup.number().required(
          "Please Enter the monthly package rate"
        ),
      });

  // handle submit
  const handleSubmit = (formValues) => {
    const data = { pricing: formValues };
    updateProfile(data);
  };
  // main return
  return (
    <SettingAccordion label="Highlights">
      <div  className="profilePricing">
        <Formik
          initialValues={data.pricing}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
          enableReinitialize
        >
          <Form  className="mt-3">
            <h1  className="title mt-4 mb-2">Hourly rate</h1>
            <Field
              component={TextInput}
              type="number"
              name="hourly_rate"
              placeholder="Write your hourly rate for teaching"
            />
            <h1  className="title mt-4 mb-2">30 minute rate</h1>
            <Field
              component={TextInput}
              type="number"
              name="thirty_min_rate"
              placeholder="Write your hourly rate for teaching"
            />
            <h1  className="title mt-4 mb-2">Weekly package rate</h1>
            <Field
              component={TextInput}
              type="number"
              name="weekly_pkg_rate"
              placeholder="Write your rate for a week"
            />
            <h1  className="title mt-4 mb-2">Fortnightly package rate</h1>
            <Field
              component={TextInput}
              type="number"
              name="fortnightly_pkg_rate"
              placeholder="Write your rate for a fortnight"
            />
            <h1  className="title mt-4 mb-2">Monthly package rate</h1>
            <Field
              component={TextInput}
              type="number"
              name="monthly_pkg_rate"
              placeholder="Write your rate for a month"
            />
            {data.class_type.includes("group_class") && (
              <>
                <h1  className="title mt-4 mb-2">3-student group rate</h1>
                <Field
                  component={TextInput}
                  type="number"
                  name="three_std_grp_rate"
                  placeholder="Write your rate for a group of up to 3 students"
                />
                <h1  className="title mt-4 mb-2">5-student group rate</h1>
                <Field
                  component={TextInput}
                  type="number"
                  name="five_std_grp_rate"
                  placeholder="Write your rate for a group of up to 5 students"
                />
                <h1  className="title mt-4 mb-2">7-student group rate</h1>
                <Field
                  component={TextInput}
                  type="number"
                  name="seven_std_grp_rate"
                  placeholder="Write your rate for a group of up to 7 students"
                />
              </>
            )}
            <Field
              id="offer_demo"
              name="offer_demo"
              component={ChechBoxInput}
              label={`I offer a demo lesson too for my students.`}
            />
            <div  className="centerFlex mt-5 mb-5">
              <div  className="flexCenter">
                <button
                  type="button"
                  //  onClick={() => setActiveTab("Schedule")}
                   className="prevBtn mx-auto mr-md-5"
                >
                  Previous
                </button>
                <button
                   className="primaryButton mt-0"
                  type="submit"
                  // disabled={loading}
                  style={{ maxWidth: "388px", width: "300px" }}
                >
                  {loading ? "Updating..." : "Done"}
                </button>
              </div>
            </div>
          </Form>
        </Formik>
      </div>
    </SettingAccordion>
  );
}
export default Pricing