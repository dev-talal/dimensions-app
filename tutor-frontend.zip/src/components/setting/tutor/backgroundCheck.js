import React from "react";
import SettingAccordion from "../settingAccordion";

export default function BackgroundCheck() {
  // main return
  return (
    <SettingAccordion label="Background check & ID verification">
      <div  className="bgCheck">
        <div  className="title">Background check and ID verification</div>
        <div  className="title poppins">
          Verification status: <span  className="textGrey">Verified</span>
        </div>
        <p  className="desc textGrey mb-3">
          Your identity has been verified by our admins. Thanks for helping make
          tutorservices a trusted environment!
        </p>
      </div>
    </SettingAccordion>
  );
}
