import React, { useState, useCallback } from "react";
import { Col, Row } from "react-bootstrap";
import { useDropzone } from "react-dropzone";
import Swal from "sweetalert2";
import AxiosBase from "../../../config/AxiosBase";
import { getImageUrl } from "../../../helpers";
import { galleryInit } from "../../../views/web/profileSetup/constant";
import SettingAccordion from "../settingAccordion";
import styled from 'styled-components';
export default function Gallery({ data }) {
  const initState =
    data.gallery.length > 0
      ? galleryInit.reduce((acc, curr, index) => {
          return data.gallery[index]
            ? [...acc, { ...curr, image: data.gallery[index] }]
            : [...acc, curr];
        }, [])
      : galleryInit;

  // state
  const [gallery, setGallery] = useState(initState);
  const [loading, setloading] = useState(false);
  //  on file drop
  const onDrop = useCallback((acceptedFiles) => {
    let counter = 0;
    setGallery((prev) =>
      prev.reduce((acc, curr) => {
        if (!curr.image && counter < acceptedFiles.length) {
          const res = [
            ...acc,
            {
              ...curr,
              image: acceptedFiles[counter],
              imageObj: URL.createObjectURL(acceptedFiles[counter]),
            },
          ];
          counter++;
          return res;
        }
        return [...acc, curr];
      }, [])
    );
  }, []);
  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    maxFiles: 10,
  });

  const removeFile = (id) => {
    setGallery((prev) =>
      prev.reduce((acc, curr) => {
        if (curr.id >= id) {
          return [
            ...acc,
            {
              ...curr,
              image: curr.id === gallery.length ? null : gallery[curr.id].image,
              imageObj:
                curr.id === gallery.length ? null : gallery[curr.id].imageObj,
            },
          ];
        }
        return [...acc, curr];
      }, [])
    );
  };
  // on Continue
  const onContinue = async () => {
    const galleryArr = gallery.reduce((acc, curr) => {
      return curr.image ? [...acc, curr.image] : acc;
    }, []);
    // console.log({ galleryArr });

    const formData = new FormData();

    if (galleryArr.length > 0) {
      console.log("work");
      for (let i = 0; i < galleryArr.length; i++) {
        formData.append(`gallery[${i}]`, galleryArr[i], galleryArr[i].filename);
        console.log(galleryArr[i], "gallry");
      }
    }
    setloading(true);
    try {
      await AxiosBase.put("/tutor/update-profile", formData);
      Swal.fire({
        position: "center",
        icon: "success",
        title: "Profile Update !",
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (error) {
      Swal.fire({
        position: "center",
        icon: "error",
        title: "Profile Update !",
        text: error?.response?.data?.message,
        showConfirmButton: false,
        timer: 2000,
      });
    }
    setloading(false);
  };
  // main return
  const GalleryComponent = ({ item, height }) => {
    return (
      <div>
        {item.image ? (
          <div
            onClick={(e) => e.stopPropagation()}
            className="galleryItem image position-relative w-100"
            style={{ height: height ,backgroundColor:"rgb(239 194 130 / 21%)"}}
          >
            <CloseButtonImg
              onClick={() => removeFile(item.id)}
              className="close position-absolute"
            >
              &#10006;
            </CloseButtonImg>
            <img
              src={item.imageObj ? item.imageObj : getImageUrl(item.image)}
              alt="icon" className="img-fluid"
            />
          </div>
        ) : (
          <div className="galleryItem w-100" style={{ height: height }}>
            <img src="/assets/image/plus.svg" alt="icon" />
          </div>
        )}
      </div>
    );
  };
  return (
    <SettingAccordion label="Gallery">
      <main
        className="container-fluid profileGallery pb-4 mx-0"
        style={{ maxWidth: "1000px" }}
      >
        <div className="row" {...getRootProps()}>
          <input {...getInputProps()} />
          {/* {gallery.map((item, index) => {
            return (
              
            );
          })} */}
          <Col lg={8}>
            <Row>
              <Col lg={6}>
                <GalleryComponent item={gallery[0]} height="359px" />
              </Col>
              <Col lg={6}>
                <Row>
                  <Col lg={12}>
                    <GalleryComponent item={gallery[1]} height="170px" />
                  </Col>
                  <Col lg={12}>
                    <GalleryComponent item={gallery[2]} height="170px" />
                  </Col>
                </Row>
              </Col>
            </Row>
            <div>
              <GalleryComponent item={gallery[3]} height="300px" />
            </div>
          </Col>
          <Col lg={4}>
            <GalleryComponent item={gallery[4]} height="300px" />
            <GalleryComponent item={gallery[5]} height="170px" />
            <GalleryComponent item={gallery[6]} height="170px" />
          </Col>
          <Row className="w-100 mx-0">
            <Col lg={6}>
              <Row>
                <Col lg={12}>
                  <GalleryComponent item={gallery[7]} height="170px" />
                </Col>
                <Col lg={12}>
                  <GalleryComponent item={gallery[8]} height="170px" />
                </Col>
              </Row>
            </Col>
            <Col lg={6}>
              <GalleryComponent item={gallery[9]} height="359px" />
            </Col>
          </Row>
        </div>
        <button
          onClick={onContinue}
          disabled={loading}
          className="primaryButton green mb-2"
        >
          {loading ? "Updating" : "Save Profile"}
        </button>
      </main>
    </SettingAccordion>
  );
}
const CloseButtonImg = styled.div`
  top: 0;
  left: 0;
  width: 40px;
  height: 40px;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
`;
