import React, { useState } from "react";
import history from "../../../helpers/history";

export default function BannerSec() {
  // state
  const [query, setQuery] = useState("");
  // tags array
  const tags = [
    "Programming & Coding",
    "Languages",
    "Test Prep",
    "Web development",
    "Business",
    "Crafts",
  ];

  // main return
  return (
    <div>
      <div className="flexBetweenCenter bannerSec">
        <div  className="contentSec">
          <h2>Find the perfect tutor</h2>
          <p>
            Online or in-person. 
            {/* Online or in-person. Choose from
            <span  className="textPrimary"> 16 thousand tutors.</span> */}
          </p>

          <div  className=" searchBar">
            <input
              type="text"
              placeholder="What you want to learn?"
               className="searchInput"
              onChange={(e) => setQuery(e.target.value)}
            />
            <div>
              <button
                onClick={() => history.push(`/search?query=${query}`)}
                 className="primaryButton mt-0"
                style={{
                  padding: "11px 36px",
                  flexShrink: 0,
                  whiteSpace: "nowrap",
                }}
              >
                Search
              </button>
            </div>
          </div>
          <div  className="d-flex">
            <p  className="textGrey mt-2">Popular searches</p>
            <div  className="flexCenter ml-2" style={{ maxWidth: "426px" }}>
              {tags.map((item, index) => {
                return (
                  <div  className="tag" key={index}>
                    {item}
                  </div>
                );
              })}
            </div>
          </div>

          <img
            src="/assets/image/bannerBooks.svg"
            alt="books"
             className="bookImg"
          ></img>
        </div>

        <div  className="imageSec">
          <img
            src="/assets/image/child-learning.svg"
            alt="child"
             className="w-100"
          />
        </div>
      </div>
    </div>
  );
}
