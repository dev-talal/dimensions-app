import React from "react";

export default function MyWorkshop() {
  return (
    <div  className="myWorkshop">
      <div  className="imgSec">
        <img src="/assets/image/workshopBg.svg" alt="workshop" />
      </div>
      <div  className="contentSec">
        <h1  className="secTitle mt-0 text-left">My Workshop</h1>
        <h3>August 18, 2021 at 3:00pm (PST).</h3>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Arcu purus
          nullam orci senectus porttitor consectetur. Sit sociis turpis proin
          interdum ac ipsum eu. Mattis suspendisse dictum lectus mattis ut nunc
          non. Egestas faucibus in semper duis consequat et tincidunt.
        </p>
        <button
           className="primaryButton"
          style={{ padding: "11px 40px", marginTop: "40px" }}
        >
          Save my seat
        </button>
      </div>
    </div>
  );
}
