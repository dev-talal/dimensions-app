import React from "react";

export default function GreateTutor() {
  return (
    <main  className="greatTutor">
      <div  className="mainFlex">
        <section>
          <h1  className="secTitle mt-0 text-left">
            You can become a great tutor too!
          </h1>
          <p>
            Are you an expert in any subject? If so, pass on your expertise through becoming a part of our tutor network. Make money by sharing your knowledge and work at your convenience.
          </p>
          <button
             className="primaryButton mb-4 mb-md-none"
            style={{ padding: "11px 38px" }}
          >
            Find out more
          </button>
        </section>
        <section>
          <img src="/assets/image/tutor-teaching-board.jpg" alt="greatTutor" />
        </section>
      </div>
    </main>
  );
}
