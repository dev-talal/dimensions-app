import React from "react";
import { Link } from "react-router-dom";

export default function LearningSec() {
  // main return
  return (
    <main  className="leanringSec" id="section_how_works">
      <h1  className="secTitle mx-auto" style={{ maxWidth: "464px" }}>
        Learning has never been easier
      </h1>
      <div  className="flexCenter step">
        <section>
          <h1  className="secTitle mt-0 text-left">1. Choose your tutor</h1>
          <p className="text-left">
            Browse profiles freely and find the right tutor that caters to your needs 
            (prices, qualifications, reviews, lessons at home or by webcam).
          </p>
        </section>
        <section>
          <img
            src="/assets/image/learningSec1.svg"
            alt="learning"
             className="stepImg w-100"
            style={{ maxWidth: "477px" }}
          />
        </section>
      </div>
      <div  className="flexCenter step">
        <section>
          <img
            src="/assets/image/learningSec2.svg"
            alt="learning"
             className="stepImg w-100 float-left"
            style={{ maxWidth: "477px" }}
          />
        </section>
        <section class="ml-auto text-left" style={{maxWidth:"477px"}}>
          <h1  className="secTitle mt-0 text-left">2. Book your lesson</h1>
          <p className="text-left">
            Schedule classes with your tutor at your convenient time and venue. You can message our tutors for any enquiries.
          </p>
        </section>
      </div>
      <div  className="flexCenter step">
        <section>
          <h1  className="secTitle mt-0 text-left">3. Organize your classes</h1>
          <p className="text-left" style={{paddingRight:"15px"}}>
            Keep track of your lessons and progress. Receive notifications and reminders and get ready to learn!
          </p>
        </section>
        <section class="float-left">
          <div className="text-right">
            <img
              src="/assets/image/learningSec3.svg"
              alt="learning"
              className="stepImg w-100"
              style={{ maxWidth: "477px",float:"none" }}
            />
          </div>
        </section>
        <div className="flexCenter w-100 step">
          <section>
            <img
              src="/assets/image/simple-circle.svg"
              alt="circle image"
              className="stepImg w-100"
              style={{ maxWidth: "442px",float:"none",marginLeft:"-160px" }}
            />
          </section>
          <section>
            <div style={{maxWidth:"477px"}} className="ml-auto mt-5 pt-5">
              <h1  className="secTitle mt-0 text-left">Benefits for Parent</h1>
              <p className="text-left">
                Parents can keep track of their children's progress and classes on the dashboard easily. Parents can easily go through payments and documents shared.You can browse through our tutor’s profiles, examining their background and qualifications, to find the perfect tutor for you, or your child, even before meeting them. 
              </p>
            </div>
          </section>
        </div>
        <div className="flexCenter w-100 step">
          <section>
            <h1  className="secTitle mt-0 text-left">It’s never too late to learn</h1>
            <p className="text-left">
              Beyond monitoring your children’s progress, why not master pottery, or finally learn how to create masterpieces in oil paint! whatever your interest is chances are we got you covered too! 
            </p>
            <Link to="/categories" class="banner__btn w-100 mt-4 text-center" type="button">Explore all categories</Link>
          </section>
          <section class="float-left">
            <div className="text-right">
              <img
                src="/assets/image/clay.png"
                alt="learning"
                className="stepImg w-100"
                style={{ maxWidth: "477px",float:"none" }}
              />
            </div>
          </section>
        </div>
      </div>

      <div  className="w-100">
        <div  className="centerFlex">
          <img
            src="/assets/image/tutor-teaching.jpg"
            alt="learning"
             className=" w-100 mx-auto"
            style={{ maxWidth: "836px",objectFit:"cover",maxHeight:"400px",borderRadius:"16px" }}
          />
        </div>
        <h1  className="secTitle mt-4">“The expert in anything was once a beginner” - Helen Hayes</h1>
        <p>
          "<span> Tutorservice </span> helped me to develop skills, invest in my
          <span> future </span>, and build <span>confidence </span> in myself."
          <br />
          <i  className="poppins">Sarah (1st-year Undergraduate student).</i>
        </p>
        <div  className="divider"> </div>
      </div>
    </main>
  );
}
