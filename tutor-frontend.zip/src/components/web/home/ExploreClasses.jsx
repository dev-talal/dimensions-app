import React from "react";
import { Link } from "react-router-dom";
export const ClassesList = ({data,width,height}) => {
  return data.map((item, index) => {
    return (
      <div key={index}  className="item" style={{width:width,height:height}}>
        <img src={item.img?item.img:`/assets/png/${item.name}.png`} alt={item.name}></img>
        <h4 className="text-capitalize"> {item.name} </h4>
      </div>
    );
  });
};
export default function ExploreClasses() {
  // classes data
  const classesData = [
    { name: "School curriculum", img: "/assets/image/classBook1.svg" },
    { name: "Languages", img: "/assets/image/classBook2.svg" },
    { name: "Music", img: "/assets/image/classBook3.svg" },
    { name: "Skills", img: "/assets/image/classBook4.svg" },
    { name: "Exam preparation", img: "/assets/image/classBook5.svg" },
  ];
  // main return
  return (
    <section  className="exploreClasses pt-5">
      <h2  className="secTitle">Explore Our Classes</h2>
      <p>Choose your tutor and achieve the results you desire.</p>
      <div  className="flexCenter mainFlex">
        <ClassesList data={classesData} />
      </div>
      <h3  className="textPrimary poppinsBd">
        <Link to="/categories">Explore Categories &#10132;</Link>
      </h3>
      <img
        src="/assets/image/exploreClassesBg.svg"
        alt="bg"
        className="heartBg"
      />
    </section>
  );
}
