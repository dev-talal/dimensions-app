import React, { useEffect, useState, useRef , useCallback } from "react";
import { Form, Spinner } from "react-bootstrap";
import Swal from "sweetalert2";
import styled from "styled-components";
import { addAnouncement, getSingleAnnouncment, postComment } from "../../../api";
import { getImageUrl } from "../../../helpers";
import { MessageFooter } from "../../../views/panel/messages/messages";
import { HeadingText, P } from "./MyClass";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { ButtonStyled } from "./ClassMeeting";
import {useDropzone} from 'react-dropzone'
import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import { CloudArrowUp, File, FileArrowDown } from "react-bootstrap-icons";
export const GetDateAndTime = ({ time }) => {
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const date = new Date(time);
  const d = new Date(date);
  let hours = d.getHours();
  let minutes = d.getMinutes();
  let ampm = hours >= 12 ? "pm" : "am";
  hours = hours % 12;
  hours = hours ? hours : 12;
  minutes = minutes < 10 ? "0" + minutes : minutes;
  let strTime = hours + ":" + minutes + " " + ampm;
  return (
    <time>
      {monthNames[d.getMonth()] + " " + d.getDay() + " at " + strTime}
    </time>
  );
};
const CommentBox = ({ classId }) => {
  const bottomRef = useRef();
  const [viewModal,setModal] = useState(false);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const { id } = useParams();
  const { user } = useSelector((state) => state.auth);
  const [postDataAnouncement, setPostDataAnouncement] = useState({
    message: "",
    files: [],
    loader: false,
  });
  const onDrop = useCallback((acceptedFiles) => {
    dataCollectionAnouncement("files",acceptedFiles)
  });
  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    maxFiles: 10,
  });
  
  const thumbs = postDataAnouncement.files.map(file => (
    <div key={file.name}>
      <ul>
        <li><small>{file.name}</small></li>
      </ul>
    </div>
  ));
  
  const [postData, setPostData] = useState({
    message: "",
    files: [],
    loader: false,
  });
  useEffect(async () => {
    setLoading(true);
    try {
      const { data } = await getSingleAnnouncment(id);
      setData(data);
    } catch {}
    setLoading(false);
  }, [!data]);
  const AttachFileTile = ({ item }) => {
    return (
      <AttachmentLabel type="button">
        <a
          href={getImageUrl(item)}
          target="_blank"
          download={item.split("_")[1]}
        >
          {item.split("_")[1]}
        </a>
      </AttachmentLabel>
    );
  };
  const dataCollection = (val, type) => {
    setPostData({
      ...postData,
      [type]: type !== "files" ? val : postData.files.concat(val),
    });
  };
  const dataCollectionAnouncement = (type,val) => {
    setPostDataAnouncement({
      ...postDataAnouncement,
      [type]: type !== "files" ? val : postDataAnouncement.files.concat(val),
    });
  };
  const postCommentRequest = async () => {
    if (!postData.message && postData.files.length < 1) {
      Swal.fire({
        position: "center",
        icon: "error",
        text: "Please enter something to post your comment",
        showConfirmButton: false,
        timer: 2000,
      });
      return;
    }
    setPostData({ ...postData, loader: true });
    const formData = new FormData();
    formData.append("message", postData.message);
    if (postData.files.length > 0) {
      for (let i = 0; i < postData.files.length; i++) {
        formData.append(
          `files[${i}]`,
          postData.files[i],
          postData.files[i].name
        );
      }
    }
    try {
      const res = await postComment(data._id, formData);
      setPostData({ ...postData, message: "", files: [], loader: false });
      setData(res.data);
    } catch (error) {
      setPostData({ ...postData, loader: false });
    }
    bottomRef.current.scroll({
      top: bottomRef.current.scrollHeight,
      behavior: "smooth",
    });
  };
  const addAnouncementCall = async () => {
    setPostDataAnouncement({ ...postDataAnouncement, loader: true });
    const formData = new FormData();
    formData.append("class_id",id);
    formData.append("message", postDataAnouncement.message);
    if (postDataAnouncement.files.length > 0) {
      for (let i = 0; i < postDataAnouncement.files.length; i++) {
        formData.append(
          `files[${i}]`,
          postDataAnouncement.files[i],
          postDataAnouncement.files[i].name
        );
      }
    }
    try{
      const res = await addAnouncement(formData);
      setModal(false);
      setPostData({ ...postData, message: "", files: [], loader: false });
      setData(res.data);
    }
    catch{
      setPostDataAnouncement({ ...postDataAnouncement, loader: false });
    }
  }

  return (
    <div>
      {!loading ? (
        <>
          {data && data.message ? (
            <CommentBoxContainer>
              <MainComment>
                <div className="d-flex align-items-center">
                  <img
                    src="/assets/png/united-states-of-america.png"
                    width="32px"
                    height="32px"
                    className="mr-2"
                    alt="username"
                  />
                  <div className="align-self-center pl-1">
                    <HeadingText size="13" style={{ lineHeight: 1 }}>
                      {data?.user_id?.first_name +
                        " " +
                        data?.user_id?.last_name}
                    </HeadingText>
                    <P></P>
                  </div>
                </div>
                <HeadingText
                  className="mt-3"
                  size="13"
                  style={{ lineHeight: 1.4 }}
                  weight="poppinsMd"
                >
                  {data?.message}
                </HeadingText>
                <ul className="list-unstyled mb-0 d-flex flex-wrap">
                  {data &&
                    data?.files.map((item, key) => {
                      return (
                        <li className="mt-3 mr-2" key={key}>
                          <AttachFileTile item={item} />
                        </li>
                      );
                    })}
                </ul>
              </MainComment>
              <CommentBody className="styled__scroll" ref={bottomRef}>
                {/* <div className="pb-1">
                  <button className="border-0 bg-transparent p-0" type="button">
                    <P size={13} style={{ fontFamily: "poppinsMd" }}>
                      View all 3 comments
                    </P>
                  </button>
                </div> */}
                {data &&
                  data?.comments.map((item, key) => {
                    return (
                      <div className="comment-item mt-3" key={key}>
                        <HeadingText size="13" style={{ lineHeight: 1 }}>
                          {item.name}
                        </HeadingText>
                        <HeadingText
                          size="12"
                          weight="poppinsMd"
                          style={{ lineHeight: 1.5 }}
                          className="mt-2"
                        >
                          {item.message}
                        </HeadingText>
                        <ul className="list-unstyled mb-0 d-flex flex-wrap">
                          {item.files.length > 0 &&
                            item.files.map((file, i) => {
                              return (
                                <li className="mt-1 mr-1" key={i}>
                                  <AttachFileTile item={file} />
                                </li>
                              );
                            })}
                        </ul>
                        <P className="mt-1">
                          <GetDateAndTime time={item.time} />
                        </P>
                      </div>
                    );
                  })}
              </CommentBody>
              <MessageFooter className="pt-0">
                <div className="position-relative area-field-box">
                  <textarea
                    className="w-100"
                    disabled={postData.loader}
                    onChange={(e) => dataCollection(e.target.value, "message")}
                    onKeyDown={(e) =>
                      e.key === "Enter" ? postCommentRequest() : null
                    }
                    placeholder="Write a comment"
                    value={postData.message}
                  ></textarea>
                  <div className="align-items-center msg-actions-group d-flex">
                    <label className="mb-0 file-label mr-3">
                      <Form
                        as="input"
                        type="file"
                        disabled={postData.loader}
                        onChange={(e) =>
                          dataCollection(e.target.files[0], "files")
                        }
                        className="d-none"
                      />
                      Attach a File
                    </label>
                    <button
                      type="button"
                      disabled={postData.loader}
                      className="border-0"
                      onClick={postCommentRequest}
                    >
                      {postData.loader ? "Sending" : "Send"}
                    </button>
                  </div>
                </div>
              </MessageFooter>
            </CommentBoxContainer>
          ) : (
            <>
              {user?.user_type!=="tutor"?
              <HeadingText className="text-danger">
                No class announcement found
              </HeadingText>
              :
              <ButtonStyled onClick={()=>setModal(true)} className="bg-orange text-white">
                Create Announcement
              </ButtonStyled>
              }
            </>
          )}
        </>
      ) : (
        <div className="text-center my-4">
          <Spinner animation="border" variant="info" role="status">
            <span className="visually-hidden"></span>
          </Spinner>
        </div>
      )}
        <Modal
          isOpen={viewModal}
          onClosed={() => {
            setModal(false)
          }}
        >
          <ModalHeader>
            Add  timings
          </ModalHeader>
          <ModalBody>
            <label>Message</label>
            <textarea
              type="text"
              onChange={(e)=>dataCollectionAnouncement("message",e.target.value)}
              className="textInput pr-2 mb-2"
              rows="3"
              cols="3"
              style={{height:"auto",resize:"none"}}
            ></textarea>
            <label> Upload Files </label>
            <section className="container">
            <div>
              {thumbs}
            </div>
            <div {...getRootProps({className: 'dropzone p-4'})} style={{borderRadius:"10px",cursor:"pointer",border:"3px dashed #2a98e5"}}>
              <input {...getInputProps()} />
              <p className="text-center mb-2"><CloudArrowUp size={40} /></p>
              <small style={{fontSize:"12px"}} className="text-center mb-0 d-block">Drag 'n' drop some files here, or click to select files</small>
            </div>
          </section>
          </ModalBody>
          <ModalFooter>
            <Button disabled={postDataAnouncement.loader?true:false} color="primary primaryButton mt-0" onClick={()=>addAnouncementCall()}>
              {postDataAnouncement.loader!==true?
              "Post"
              :
              <>
                <Spinner
                  as="span"
                  animation="grow"
                  size="sm"
                  role="status"
                  aria-hidden="true"
                />
                Loading...
              </>}
            </Button>
            <Button color="primaryButton" outline onClick={()=>{setPostDataAnouncement({ ...postData, message: "", files: [], loader: false });setModal(false)}}>
              Cancel
            </Button>
          </ModalFooter>
        </Modal>
    </div>
  );
};
const CommentBoxContainer = styled.div`
  border: 1px solid #c8c8c8;
  border-radius: 8px;
`;
const MainComment = styled.div`
  padding: 20px;
  border-bottom: 1px solid #c8c8c8;
`;
const CommentBody = styled.div`
  padding: 20px;
`;
const AttachmentLabel = styled.label`
  background-color: #c8c8c8;
  padding: 6px 10px;
  border-radius: 6px;
  color: #0a0d31;
  margin-bottom: 0;
  font-size: 12px;
  font-family: poppinsSb;
`;
export default CommentBox;
