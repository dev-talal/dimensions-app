import React from 'react'
import { ChevronLeft } from 'react-bootstrap-icons';
import { Link } from 'react-router-dom';
import styled from 'styled-components'
import ClassMeeting from './ClassMeeting';
 const MyClass = () => {
  return (
    <div>
        <ClassMeeting />
        {/* <Link to="/dashboard/classes/my" className="text-decoration-none">
            <BackButtonStyled type="button" className="my-4 border-0 
                p-0 bg-transparent">
                <ChevronLeft className="mr-2" size={15} />
                <span>Learn how to read and write while having fun - kindergarten</span>
            </BackButtonStyled>
        </Link>
        <div>
            <HeadingText>
                Learn how to read and write while having fun - kindergarte
            </HeadingText>
            <P>30 min • 4-5 yeas old • 5 learners • Multi-day • 3 week, 2x/week • Total 6 meetings</P>
        </div>
        <div className="my-4">
            <HeadingText weight="poppinsMd">
               History
            </HeadingText>
        </div>
        <div className="d-flex mb-2 pb-1 justify-content-between align-items-center">
            <HeadingText weight="poppinsMd" size="14">
                Mon, Dec 8 at 18:00 UK time
            </HeadingText>
            <P size={12}>Meeting 4</P>
        </div>
        <div className="d-flex mb-2 pb-1 justify-content-between align-items-center">
            <HeadingText weight="poppinsMd" size="14">
                Mon, Dec 7 at 18:00 UK time
            </HeadingText>
            <P size={12}>Meeting 3</P>
        </div>
        <div className="d-flex mb-2 pb-1 justify-content-between align-items-center">
            <HeadingText weight="poppinsMd" size="14">
                Mon, Dec 6 at 18:00 UK time
            </HeadingText>
            <P size={12}>Meeting 2</P>
        </div>
        <div className="d-flex mb-2 pb-1 justify-content-between align-items-center">
            <HeadingText weight="poppinsMd" size="14">
                Mon, Dec 5 at 18:00 UK time
            </HeadingText>
            <P size={12}>Meeting 1</P>
        </div> */}
    </div>
  )
}
export const BackButtonStyled = styled.button`
    display:flex;
    align-items: center;
    font-size:16px;
    font-family: poppinsMd;
`;
export const HeadingText = styled.h3`
    font-size: ${({size})=>size?size:18}px;
    line-height: 30px;
    color: #404041;
    font-family: ${({weight})=>weight?"poppinsMd":"poppinsSb"};
`;
export const P = styled.p`
    font-size: ${({size})=>size?size:11}px;
    font-family: ${({weight})=>weight?"poppins":"poppinsMd"};
    line-height: 18px;
    color: #878787;
`;
export default MyClass