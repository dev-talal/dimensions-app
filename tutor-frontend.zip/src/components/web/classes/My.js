import React, { useEffect, useState } from "react";
import { Form } from "react-bootstrap";
import { Link } from "react-router-dom";
import styled from "styled-components";
import { getAllClasses } from "../../../api";
import Spinner from "react-bootstrap/Spinner";
import { ListHeader } from "../../../views/panel/notifcations/notifications";
import { GetDateAndTime } from "./CommentBox";
const My = () => {
  const [data, setData] = useState(null);
  const [loader, setLoader] = useState(false);
  useEffect(async () => {
    setLoader(true);
    try {
      const { data } = await getAllClasses();
      setData(data);
    } catch (err) {}
    setLoader(false);
  }, []);
  return (
    <div>
      {loader ? (
        <div className="text-center my-4">
          <Spinner animation="border" variant="info" role="status">
            <span className="visually-hidden"></span>
          </Spinner>
        </div>
      ) : (
        <>
          {data && data.length > 0 ? (
            <>
              {/* <Form.Select
                className="form-control mt-4"
                style={{ width: "150px" }}
              >
                <option>All</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
              </Form.Select> */}
              {data.map((item, key) => {
                return (
                  <div className="mt-4" key={key}>
                    {/* <HeadingText className='mb-0'>
                      Old Classes
                    </HeadingText> */}
                    <ListData>
                      <div className="d-flex align-items-center justify-content-between">
                        <div>
                          <h5>{item.name}</h5>
                          <p className="mb-0 mt-2">
                            <span>Created At :&nbsp;</span>
                            <GetDateAndTime time={item.createdAt} />
                            {/* <span>Students&nbsp;</span>John, Ayesha, Ahmad */}
                          </p>
                        </div>
                        <div>
                          <Link to={`/dashboard/classes/my/${item._id}`}>
                            View class
                          </Link>
                        </div>
                      </div>
                    </ListData>
                  </div>
                );
              })}
              {/* <ListHeader
                className="text-center border-0 p-0 mt-4"
                weight={400}
              >
                <Link to="#" className="text-blue">
                  Load More
                </Link>
              </ListHeader> */}
            </>
          ) : (
            <HeadingText className="text-danger text-center">
              No Class Found
            </HeadingText>
          )}
        </>
      )}
    </div>
  );
};
const HeadingText = styled.h3`
  font-size: 16px;
  color: #404041;
  font-family: poppinsMd;
  margin-bottom: 15px;
`;
const ListData = styled.div`
  border: 1px solid #c8c8c8;
  padding: 19px;
  border-radius: 6px;
  h5 {
    font-family: poppinsSb;
    font-size: 15px;
  }
  p {
    font-size: 15px;
    color: #0a0d31;
    span {
      color: #c8c8c8;
    }
  }
  a {
    color: #7abbb5;
    font-size: 15px;
  }
`;
export default My;
