import React, { useEffect, useState } from "react";
import { ChevronLeft } from "react-bootstrap-icons";
import { Link } from "react-router-dom";
import { BackButtonStyled, HeadingText, P } from "./MyClass";
import styled from "styled-components";
import CommentBox, { GetDateAndTime } from "./CommentBox";
import { useParams } from "react-router-dom";
import {
  getSingleClass,
  postClassReview,
  updateClassMeetingApi,
} from "../../../api";
import { useSelector } from "react-redux";
import StarRatings from "react-star-ratings";
import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import Spinner from "react-bootstrap/Spinner";
import Swal from "sweetalert2";
import { getImageUrl } from "../../../helpers";
const ClassMeeting = () => {
  const { id } = useParams();
  const [result, setResult] = useState(null);
  const { user } = useSelector((state) => state.auth);
  const [updateData, setUpdateData] = useState({ name: "", meet_link: "" });
  const [loader, setLoader] = useState(false);
  const [viewModal, setModal] = useState(false);
  const [rating, setRating] = useState(0);
  const [openRating, setModalRating] = useState(false);
  const [CommentText, setCommentText] = useState("");
  useEffect(async () => {
    try {
      const { data } = await getSingleClass(id);
      setResult(data);
      console.log(data);
    } catch {}
  }, []);
  const updateClassMeeting = async () => {
    setLoader(true);
    try {
      const { data } = await updateClassMeetingApi(id, updateData);
      setResult(data);
      Swal.fire({
        text: "Class Meeting Updated Successfully!",
        icon: "success",
      });
      setModal(false);
    } catch (error) {
      const { response } = error;
      Swal.fire({
        text: response.data.message,
        icon: "error",
      });
    }
    setUpdateData({ ...updateData, meet_link: "", name: "" });
    setLoader(false);
  };
  const postReview = async () => {
    if (!rating) {
      Swal.fire({
        text: "Please select stars to give rating",
        icon: "error",
      });
      return;
    }
    setLoader(true);
    const postData = { class_id: id, rating: rating, comment: CommentText };
    try {
      const result = await postClassReview(postData);
      Swal.fire({
        text: "Rating has been posted successfully",
        icon: "success",
      });
      setModalRating(false);
      setResult(result);
    } catch (error) {
      const { response } = error;
      Swal.fire({
        text: response.data.message,
        icon: "error",
      });
    }
    setLoader(false);
  };
  return (
    <>
      <div className="pt-3">
        <Link to="/dashboard/classes/my" className="text-decoration-none">
          <BackButtonStyled
            type="button"
            className="my-4 border-0 
            p-0 bg-transparent"
          >
            <ChevronLeft className="mr-2" size={15} />
            <span>{result?.name}</span>
          </BackButtonStyled>
        </Link>
        <div className="mt-4 mb-3">
          <HeadingText weight="poppinsMd">New Meeting</HeadingText>
        </div>
        <div className="mb-2 pb-1 align-items-ceter justify-content-between d-flex flex-wrap">
          <div>
            <HeadingText weight="poppinsMd" size="14">
              {result ? <GetDateAndTime time={result.createdAt} /> : null}
            </HeadingText>
            <P size={12}>Make sure to join the meeting on time!</P>
          </div>
          {result?.meet_link && result.name ? (
            <div class="d-flex align-items-center">
              <a href={result?.meet_link} class="d-block" target="_blank">
                <ButtonStyled className="bg-orange text-white">
                  Join The Meeting
                </ButtonStyled>
              </a>
              {user.user_type == "tutor" ? (
                <ButtonStyled
                  className="bg-blue text-white ml-3"
                  style={{ flexShrink: 0 }}
                  onClick={() => {
                    setUpdateData({
                      ...updateData,
                      meet_link: result?.meet_link,
                      name: result?.name,
                    });
                    setModal(true);
                  }}
                >
                  Update Meeting
                </ButtonStyled>
              ) : !result?.reviewed_by?.includes(user._id) ? (
                <ButtonStyled
                  className="bg-blue text-white ml-3"
                  style={{ flexShrink: 0, backgroundColor: "#4285f4" }}
                  onClick={() => {
                    setUpdateData({
                      ...updateData,
                      meet_link: result?.meet_link,
                      name: result?.name,
                    });
                    setModalRating(true);
                  }}
                >
                  Post a Review
                </ButtonStyled>
              ) : null}
            </div>
          ) : user.user_type == "tutor" ? (
            <ButtonStyled
              className="bg-orange text-white"
              onClick={() => {
                setUpdateData({ ...updateData, name: result?.name });
                setModal(true);
              }}
            >
              Create Meeting
            </ButtonStyled>
          ) : null}
        </div>
        <div className="mt-4">
          <HeadingText weight="poppinsMd">Request payment</HeadingText>
          <div className="mb-2 pb-1 align-items-ceter d-flex">
            <ButtonStyled
              className="bg-blue text-white mr-3 mt-4"
              style={{ flexShrink: 0 }}
            >
              Request the payment
            </ButtonStyled>
            <div className="align-self-center mt-4">
              <P className="mb-0" size={12}>
                You can see this option because student(s) did not pay for the
                class up front. Please request the payment only after the class
                is over to avoid distrust of the student.
              </P>
            </div>
          </div>
          <HeadingText weight="poppinsMd" className="mt-5">
            Class announcement{" "}
          </HeadingText>
          <div className="mt-4">
            <CommentBox classId={id} />
          </div>
        </div>
      </div>
      <Modal
        isOpen={viewModal}
        onClosed={() => {
          setModal(false);
        }}
      >
        <ModalHeader>Add timings</ModalHeader>
        <ModalBody>
          <label>Class Name</label>
          <input
            type="text"
            onChange={(e) =>
              setUpdateData({ ...updateData, name: e.target.value })
            }
            className="textInput pr-2 mb-2"
            value={updateData.name}
          />
          <label className="mt-2">Meeting Link</label>
          <input
            type="text"
            value={updateData.meet_link}
            onChange={(e) =>
              setUpdateData({ ...updateData, meet_link: e.target.value })
            }
            className="textInput pr-2 mb-2"
          />
        </ModalBody>
        <ModalFooter>
          <Button
            disabled={
              loader
                ? true
                : updateData.meet_link !== "" || updateData.name !== ""
                ? false
                : true
            }
            color="primary primaryButton mt-0"
            onClick={() => updateClassMeeting()}
          >
            {loader !== true ? (
              "Submit"
            ) : (
              <>
                <Spinner
                  as="span"
                  animation="grow"
                  size="sm"
                  role="status"
                  aria-hidden="true"
                />
                Loading...
              </>
            )}
          </Button>
          <Button
            color="primaryButton"
            outline
            onClick={() => {
              setUpdateData({ ...updateData, meet_link: "", name: "" });
              setLoader(false);
              setModal(false);
            }}
          >
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
      {result? (
        <>
          {!result.reviewed_by?.includes(user._id) ? (
            <Modal
              isOpen={openRating}
              onClosed={() => {
                setModalRating(false);
              }}
            >
              <ModalHeader>Rate and Review</ModalHeader>
              <ModalBody className="post-rating-section py-3">
                <div>
                  <div class="d-flex flex-wrap align-items-center">
                    <img
                      src={getImageUrl(user?.profile_pic)}
                      width="32px"
                      height="32px"
                      className="mr-2"
                      alt={`${user?.first_name} ${user?.last_name}`}
                    />
                    <h6 className="mb-0">
                      {user?.first_name} {user?.last_name}
                      <p>Your review will be posted publicly on the web.</p>
                    </h6>
                  </div>
                </div>
                <div className="my-4 pt-2">
                  <h6 className="mb-3">Select Rating</h6>
                  <StarRatings
                    rating={rating}
                    starRatedColor="#EFC282"
                    starHoverColor={"#EFC282"}
                    changeRating={(rating) => setRating(rating)}
                    numberOfStars={5}
                    isSelectable={true}
                    starDimension="32px"
                    starSpacing="1px"
                    name="rating"
                  />
                </div>
                <div>
                  <h6 className="mb-1">Enter Comment</h6>
                  <textarea
                    rows="5"
                    className="textInput mt-3"
                    value={CommentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Describe your experience"
                    style={{ height: 150, resize: "none" }}
                  />
                </div>
              </ModalBody>
              <ModalFooter>
                <Button
                  disabled={
                    loader
                      ? true
                      : updateData.meet_link !== "" || updateData.name !== ""
                      ? false
                      : true
                  }
                  color="primary primaryButton mt-0"
                  onClick={() => postReview()}
                >
                  {loader !== true ? (
                    "Submit"
                  ) : (
                    <>
                      <Spinner
                        as="span"
                        animation="grow"
                        size="sm"
                        role="status"
                        aria-hidden="true"
                      />
                      Loading...
                    </>
                  )}
                </Button>
                <Button
                  color="primaryButton"
                  outline
                  onClick={() => {
                    setModalRating(false);
                  }}
                >
                  Cancel
                </Button>
              </ModalFooter>
            </Modal>
          ) : null}
        </>
      ) : null}

    </>
  );
};
export const ButtonStyled = styled.button`
  border: 0;
  padding: 7px 20px;
  border-radius: 6px;
  font-size: 14px;
  font-family: poppinsSb;
  min-height: 48px;
`;
export default ClassMeeting;
