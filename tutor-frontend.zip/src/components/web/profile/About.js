import { format as formatDate } from "date-fns";
import React from "react";

export default function About({ data, setActiveTab }) {
  return (
    <div  className="component">
      <h1>About</h1>
      <p>{data.about_you}</p>
      <h1>Education</h1>
      <div  className="flexCenter">
        {data?.education.map((item, index) => {
          return (
            <div key={index}  className="eduDetail pt-3">
              <div  className="eduBox">
                <img src="/assets/image/eduCap.svg" alt="eduCap" />
              </div>
              <div>
                <h3>
                  {item.name_of_institution}, {item.country}.
                </h3>
                <h4>{item.degree_title}</h4>
                <div className="flexBetweenCenter">
                  <p className="mr-3">
                    &#x25CF; {item.city}, {item.country}.
                  </p>

                  <p>
                    &#x25CF;{" "}
                    {item.currently_enrolled ? "Present" : item.completion_year}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <h1>Experience</h1>
      <div  className="flexCenter">
        {data?.experience.map((item, index) => {
          return (
            <div key={index}  className="eduDetail pt-3">
              <div>
                <h3>&#x25CF; {item.teaching_place}</h3>
                <p>
                  {item.from_year}-
                  {item.currently_working_here
                    ? "Present"
                    : item.to_year
                    ? item.to_year
                    : "Present"}
                </p>
                <h4>{item.short_description}</h4>
              </div>
            </div>
          );
        })}
      </div>
      <div  className="flexCenter">
        <h1>Availability</h1>
        <span
          onClick={() => setActiveTab("Schedule")}
           className="poppinsMd textGreen mt-4 pt-2 ml-4 pointer"
        >
          Show schedule
        </span>
      </div>
      <div className="mt-3" style={{ maxWidth: "300px"}}>
        {data?.schedule?.availability_time?.map((item) => {
          return (
            <div key={item._id}  className="flexBetweenCenter" style={{marginBottom:"10px"}}>
              <div  className="capltalize"> {item.name} </div>

              {item.timings.length < 1 && (
                <span  className="textGrey" style={{width:"140px"}}>not available</span>
              )}
              <div style={{width:"140px"}}>
              {item.timings.length > 0 &&
                item.timings?.map((time, index) => {
                  return index === 0 ? (
                    <div key={time?._id}>
                      {formatDate(new Date(time?.start_time), "p")} -{"   "}
                      {formatDate(new Date(time?.end_time), "p")}
                    </div>
                  ) : (
                    <div key={time._id}>
                      {`&`} {formatDate(new Date(time.start_time), "p")} -
                      {"   "}
                      {formatDate(new Date(time.end_time), "p")}
                    </div>
                  );
                })}
                </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
