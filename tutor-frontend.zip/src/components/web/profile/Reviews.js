import React,{useState,useEffect} from "react";
import { StarFill } from "react-bootstrap-icons";
import StarRatings from "react-star-ratings/build/star-ratings";

export default function Reviews({data}) {
  const {reviews} = data;
  // useEffect(()=>{
  //   if(reviews.length>0){
  //     const rt = reviews.reduce( ( sum, { rating } ) => sum + rating , 0);
  //     const user_reviews_count = parseInt(reviews.length) * 5;
  //     setRating(parseInt(rt * 5) / user_reviews_count);
  //   }
  // },[])
  return (
    <div className="component">
      <h1 className="mb-2">Reviews</h1>
      {reviews.length>0?
      <div className="row mx-0">
        <div className="flexCenter flex-lg-nowrap">
          <div className="priceCard" style={{ minHeight: "130px" }}>
            <div className="text-center">
              <StarFill size={45} color="#EFC282" />
            </div>
            <div className="centerFlex mt-3">
              <p style={{ color: "#C8C8C8" }}>{data.rating.toString().slice(0,(data.rating.toString().indexOf("."))+2)}</p>
            </div>
          </div>
          <div className="priceCard" style={{ minHeight: "130px" }}>
            <h4 className="textCenter">
              <span>{reviews.length}</span>
            </h4>
            <div className="centerFlex">
              <p style={{ color: "#C8C8C8" }}>Reviews</p>
            </div>
          </div>
        </div>
      </div>
      :<h5 className="text-danger" style={{fontWeight:600,fontSize:"17px"}}>Reviews not found</h5>}
      <div className="reviews-section mt-3">
        {reviews.map(function (item, i) {
          return (
            <div className="d-flex align-items-start mb-3" key={i}> 
              <div class="d-flex">
                <img
                  src="/assets/image/defaultProfile.svg"
                  className="mr-3"
                  width="65px"
                  height="65px"
                  alt="profile"
                  style={{borderRadius: "10px"}}
                />
                <div className="heading-userrs pt-3">
                  <h5 style={{ fontSize: "13px", fontWeight: 700 }}>
                    {item.username?item.username:"No username"}                   
                  </h5>
                  <StarRatings
                    rating={item.rating}
                    starRatedColor="#EFC282"
                    numberOfStars={5}
                    starDimension="18px"
                    starSpacing="1px"
                    name="rating"
                  />
                  <p className="mt-2" style={{ fontSize: "13px" }}>
                    {item.comment}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
