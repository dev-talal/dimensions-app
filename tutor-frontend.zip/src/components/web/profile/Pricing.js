import React from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
export default function Pricing({ data, onPriceSelect }) {
  const { class_time } = data.schedule;
  const { pricing } = data;
  console.log(Object.entries(pricing)[0][0]);

  const pricingArr = Object.entries(pricing).reduce((acc, curr) => {
    return [...acc, { name: curr[0], price: curr[1] }];
  }, []);

  console.log({ pricingArr });

  const getPackageName = (name) => {
    switch (name) {
      case "four_class_rate":
        return "4 Classes";
      case "eight_class_rate":
        return "8 Classes";
      case "twelve_class_rate":
        return "12 Classes";
      default:
        return " 4 Classes";
    }
  };
  // main return
  return (
    <div  className="component">
      <h1 className="mb-3">Pricing</h1>
      <Row>
        {class_time?.length > 0 &&
          class_time.map((item) => {
            return (
              <Col md={6}>
                <div  className="priceCard w-100" style={{padding:"20px"}}>
                  <h4  className="textCenter">
                    <span>${item.price}</span>&nbsp;/{item.time} min
                  </h4>
                  <div  className="centerFlex">
                    <button
                      onClick={() =>
                        onPriceSelect("single_class", item.price, 1, item.time)
                      }
                        className="primaryButton green"
                    >
                      Select
                    </button>
                  </div>
                </div>
              </Col>
            );
          })}
      </Row>
      <h1 className="mb-3">Package rates</h1>
      <Row>
        {pricingArr.map((item, i) => {
          return (
            <Col xs={12} md={6} lg={4}>
              <div  className="priceCard package w-100">
                <div  className="flexBetweenCenter">
                  <h3 style={{ textTransform: "capitalize" }}>
                    {/* {item.name.replace(/[^a-zA-Z0-9 ]/g, " ")} */}
                    {getPackageName(item.name)}
                  </h3>
                  <h3  className="textPrimary">${item.price}</h3>
                </div>
                <h3  className="textGrey mt-1">Lorem ipsum dolor sit amet </h3>
                <div  className="centerFlex">
                  <button
                    onClick={() =>
                      onPriceSelect(item.name, item.price, (i + 1) * 4, null)
                    }
                      className="primaryButton green w-100"
                  >
                    Select
                  </button>
                </div>
              </div>
            </Col>
          );
        })}
      </Row>
    </div>
  );
}
