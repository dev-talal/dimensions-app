import React, { useEffect, useState } from "react";
import {
  addDays,
  addMinutes,
  addMonths,
  endOfMonth,
  endOfWeek,
  format as formatDate,
  getHours,
  getMinutes,
  isBefore,
  isSameDay,
  isSameMonth,
  setHours,
  setMinutes,
  startOfMonth,
  startOfWeek,
  subMonths,
} from "date-fns";
import { useSelector } from "react-redux";
export default function Schedule({
  data,
  setOpenModal,
  setSlotId,
  selectedPackage,
  setSlotTime
}) {
  // states
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [todayDate] = useState(new Date());
  const [slots, setSlots] = useState([]);
  const [selectedSlot, setSelectedSlot] = useState([]);
  const {user} = useSelector((state)=>state.auth)
  useEffect(() => {
    getSlotsByDay(selectedDate);
    return () => {};
  }, []);

  // on change date
  const onChangeDate = (date) => {
    setSelectedDate(date);
    getSlotsByDay(date);
  };
  // set slots by day
  const getSlotsByDay = (date) => {
    const dayName = formatDate(date, "cccc");
    const classTime = Number(selectedPackage.time);
    const bufferSetting = data?.schedule?.buffer_and_time_setting;
    const todayTimeRangeObj = data?.schedule?.availability_time.find(
      (el) => el.name === dayName.toLowerCase()
    );
    const todayTimeRange = todayTimeRangeObj.timings;
    if (todayTimeRange.length < 1) return setSlots([]);
    const slotsArr = todayTimeRange.reduce((acc, curr) => {
      const { start_time, end_time } = curr;
      let startTime = setHours(date, getHours(new Date(start_time)));
      let endTime = setHours(date, getHours(new Date(end_time)));
      startTime = setMinutes(startTime, getMinutes(new Date(start_time)));
      endTime = setMinutes(endTime, getMinutes(new Date(end_time)));
      const { after_class, before_class } = bufferSetting;
      let slotMakeTime = addMinutes(startTime, Number(before_class));
      let slotMakeTimeEnd = addMinutes(endTime, Number(after_class));
      let slots = [];
      // while (
      //   isBefore(
      //     addMinutes(slotMakeTime, Number(after_class) + classTime),
      //     endTime
      //   )
      // ) {
      //   slots.push(slotMakeTime);
      //   slotMakeTime = addMinutes(
      //     slotMakeTime,
      //     Number(after_class) + classTime
      //   );
      // }
      var d1 = new Date(start_time);
      var d2 = new Date(selectedDate);
     
      if ((d1.getMonth(), d2.getMonth())) {
        slots.push({start_time:slotMakeTime,end_time:slotMakeTimeEnd,id:curr._id});
        slotMakeTime = addMinutes(
          slotMakeTime,
          Number(after_class) + classTime
        );
      }

      return [...acc, ...slots];
    }, []);

    setSlots(slotsArr);
    setSelectedSlot(slotsArr[0]);
  };

  // render current month calender
  const renderDaysInMonth = () => {
    // handgle change in month or weeks
    const nextMonth = () => {
      setCurrentMonth(addMonths(currentMonth, 1));
    };

    const prevMonth = () => {
      setCurrentMonth(subMonths(currentMonth, 1));
    };
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);
    const monthName = formatDate(currentMonth, "LLLL yyyy");
    const dateFormat = "d";
    const rows = [];
    let days = [];
    let day = startDate;
    let formattedDate = "";

    while (day <= endDate) {
      for (let i = 0; i < 7; i++) {
        formattedDate = formatDate(day, dateFormat);
        const cloneDay = day;
        days.push(
          <div
            className={`calenderItem ${
              !isSameMonth(day, monthStart)
                ? "calenderItemDisable"
                : isSameDay(day, selectedDate)
                ? "calenderItemActive"
                : isSameDay(day, todayDate)
                ? "calenderItemToday"
                : ""
            }`}
            key={day}
            onClick={() => onChangeDate(cloneDay)}
          >
            {formattedDate}
          </div>
        );
        day = addDays(day, 1);
      }
      rows.push(
        <div className="calenderRow" key={day}>
          {days}
        </div>
      );
      days = [];
    }
    return (
      <div className="calenderContainer">
        <div className="flexBetweenCenter">
          <div className="textGrey">Please select available date</div>
          <div className="flexCenter controller">
            <button onClick={prevMonth}>
              <img src="/assets/image/arrowLeftBlack.svg" alt="arrow" />
            </button>
            <div className="mx-3">{monthName}</div>
            <button onClick={nextMonth}>
              <img src="/assets/image/arrowRightBlack.svg" alt="arrow" />
            </button>
          </div>
        </div>
        <div className="calenderRow">
          <div className="calenderCol">S</div>
          <div className="calenderCol">M</div>
          <div className="calenderCol">T</div>
          <div className="calenderCol">W</div>
          <div className="calenderCol">T</div>
          <div className="calenderCol">F</div>
          <div className="calenderCol">S</div>
        </div>
        {rows}
      </div>
    );
  };

  // main return
  return (
    <div className="component schedule">
      <h1>Schedule</h1>
      {renderDaysInMonth()}
      <div className="flexBetweenCenter" style={{ maxWidth: "600px" }}>
        <div className="flexCenter">
          <div className="circle primary"></div>
          <p>Booked an online class</p>
        </div>
        <div className="flexCenter ">
          <div className="circle"></div>
          <p>Booked a class at student’s home</p>
        </div>
      </div>
      <div className="flexCenter mt-2 mt-md-3">
        <div className="circle green"></div>
        <p>Booked a class at tutor’s home</p>
      </div>
      <div className="textGrey mt-5">Please select available time slot</div>
      <div className="flexCenter mt-3">
        {slots.length > 0 &&
          slots.map((item, index) => {
            return (
              <div
                onClick={() => setSelectedSlot(item)}
                className={item.start_time === selectedSlot.start_time ? "slot active" : "slot"}
              >
                {formatDate(item.start_time, "p")}
              </div>
            );
          })}
        {slots.length < 1 && <div className="slot">No Slots Available</div>}
      </div>
      {/* {selectedSlot && selectedSlot.length > 0 ? ( */}
      {selectedSlot && slots.length > 0?
      user._id?
      <button
        onClick={() => {setOpenModal(true);setSlotId(selectedSlot.id);setSlotTime(selectedSlot)}}
         className="primaryButton green mt-5"
        style={{ width: "200px" }}
      >
        Next
      </button>
      :<h5 class="text-danger mt-4" style={{fontSize:"17px",fontWeight:700}}>Please login first to do booking.</h5>
      :null}
      {/* ) : null} */}
    </div>
  );
}