import React from "react";
import { getImageUrl } from "../../../helpers";

export default function Gallery({ data }) {
  return (
    <div  className="component">
      <h1 className="mb-2">Gallery</h1>
      <div  className="row">
        {data?.gallery.map((item, index) => {
          return (
            <div key={index}  className="col-md-4">
              <img
                 className="galleryImage"
                src={getImageUrl(item)}
                alt="image"
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}
