import React from "react";
import { Link } from "react-router-dom";
import "./footer.css";
export default function Footer() {
  return (
    <>
      <footer  className="footer">
        <div  className="footerFlex">
          <div  className="footerItem mt-3">
            <div  className="footerTitle">About</div>
            <Link to="/our-story"  className="footerLink">
              Who are we?
            </Link>
            <br />
            <Link to="/?section=how-it-works"  className="footerLink">
              How it works?
            </Link>
            <br />
            <Link to="/terms-of-services"  className="footerLink">
              Terms & Conditions
            </Link>
            <br />
            <Link to="/privacy-policy"  className="footerLink">
              Privacy Policy
            </Link>
          </div>
          <div  className="footerItem mt-3">
            <div  className="footerTitle">Tutor & Students </div>
            <Link to="/become-tutor"  className="footerLink">
              Become a tutor
            </Link>
            <br />
            <Link to="/search"  className="footerLink">
              Find a tutor
            </Link>
            <br />
            <Link to="/workshop/all"  className="footerLink">
              Workshops
            </Link>
            <br />
          </div>
          <div  className="footerItem mt-3">
            <div  className="footerTitle">Tutor service global </div>
            <Link to="/categories"  className="footerLink">
              All subjects
            </Link>
            <br />
            <Link to="/countries"  className="footerLink">
              Countries
            </Link>
          </div>
          <div  className="footerItem mt-3">
            <div  className="footerTitle">Help</div>
            <Link to="/faqs"  className="footerLink">
              FAQs
            </Link>
            <br />
            <Link to="/contact"  className="footerLink">
              Contact us
            </Link>
          </div>
          <div  className="footerItem mt-3">
            <div  className="footerTitle">Follow Us</div>
            <div  className="socialDiv">
              <img src="/assets/image/fbIcon.svg" alt="icon" />
              <br />
            </div>
            <div  className="socialDiv">
              <img src="/assets/image/instaIcon.svg" alt="icon" />
            </div>
          </div>
        </div>
      </footer>
      <div  className="flexBetweenCenter copyRightDiv">
        <div  className="flexCenter">
          <a>
            <img
              src="/assets/image/appleIcon.svg"
              width="22px"
               className="white-filter align-self-center"
            />
          </a>
          <a>
            <img
              src="/assets/image/androidIcon.svg"
              width="22px"
               className="white-filter align-self-center"
            />
          </a>
        </div>

        <p>Copyright © 2021 tutorservice, Explore. Learn</p>
        <ul  className="list-unstyled mb-0 mt-2 mt-md-0 app-down-sec list-inline">
          <li  className="list-inline-item me-3 bg-theme">
            <select>
              <option>USD</option>
              <option>PKR</option>
              <option>Pound</option>
            </select>
          </li>
          <li  className="list-inline-item bg-theme">
            <select>
              <option>English</option>
              <option>Urdu</option>
              <option>Franch</option>
            </select>
          </li>
        </ul>
      </div>
    </>
  );
}
