import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { getImageUrl } from "../../../../helpers";
import history from "../../../../helpers/history";
import { logout } from "../../../../redux/actions/authActions";

export default function HeaderProfile() {
  const [active, setActive] = useState(false);

  const { user } = useSelector((state) => state.auth);
  let userStatus = user?.userType;
  // dispatcher for actions
  const dispatch = useDispatch();

  // signOut fun
  const signOut = () => {
    dispatch(logout());
  };
  const user_register_type = user?.register_type=="google" || user?.register_type=="facebook"?'social':'simple';
  // main return
  return (
    <div  className="headerProfile">
      {}
      <img
        src={
          (user?.profile_pic && getImageUrl(user?.profile_pic,user_register_type)) ||
          "/assets/image/defaultKidProfile.svg"
        }
         className="img pointer"
        alt="headerProfile"
      />
      <div
         className={active === true ? "dropDown dropDownActive" : "dropDown "}
        style={{ maxHeight: "auto !important" }}
      >
        <Link to="/dashboard">
          <div  className="item">Dashboard</div>
        </Link>

        <Link to="/dashboard/classes/my">
          <div  className="item">Classes</div>
        </Link>

        {userStatus === "parent" && (
          <Link to="/saved-class">
            <div  className="item">
              <img
                src="/assets/image/saveIcon.svg"
                alt="save"
                style={{ width: "9px" }}
                 className="icon"
              ></img>
              <span  className="ml-2">Saved</span>
            </div>
          </Link>
        )}

        <div
          onClick={() => history.push("/dashboard/profile-and-setting")}
           className="item"
        >
          Profile And Setting
        </div>

        <div  className="divider"></div>
        <div onClick={signOut}  className="item basicTitleSemiBold">
          Sign out
        </div>
      </div>
    </div>
  );
}
