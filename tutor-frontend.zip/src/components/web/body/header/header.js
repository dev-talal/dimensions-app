import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import history from "../../../../helpers/history";
import "./header.css";
import HeaderProfile from "./headerProfile";
import { useLocation } from "react-router";
import { Dropdown } from "react-bootstrap";
import { ChevronDown } from "react-bootstrap-icons";
export default function Header() {
  const { isAuth } = useSelector((state) => state.auth);

  const [searchPage, setSearchPage] = useState(false);

  const dispatch = useDispatch();
  const path = useLocation().pathname;

  useEffect(() => {
    if (path.indexOf("/search") > -1 || path.indexOf("/workshop") > -1 || path.indexOf("/terms-of-conditions") > -1
    || path.indexOf("/privacy-policy") > -1 || path.indexOf("/countries") > -1 || 
    path.indexOf("/categories") > -1) {
      setSearchPage(true);
    }
    return () => {
      setSearchPage(false);
    };
  }, [path]);
  console.log({ searchPage });

  // main retun
  return (
    <>
      {/* <div className="text-right" style={{padding:"20px 5vw 0px"}}><div id="google_translate_element"></div></div> */}
      <nav
        className={`navbar navbar-expand-lg navbar-light ${
          searchPage || "bg-transparent"
        }  `}
        style={searchPage ? { backgroundColor: "#F1F8F8" } : {}}
      >
      <Link  className="navbar-brand" to="/">
        <img src="/assets/png/logo.png" width="35px" className="mr-3" />Eddaris
      </Link>

        <>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div  className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul  className="navbar-nav ml-auto align-items-center">
              <li  className="nav-item">
                <Link  className="nav-link" to="/workshop/all">
                  Workshops
                </Link>
              </li>
              <li  className="nav-item">
                <Link to="/search"  className="nav-link">
                  Find a Tutor
                </Link>
              </li>
              <li  className="nav-item">
                <Link  className="nav-link" href="#">
                  Tutoring Jobs
                </Link>
              </li>
              <li  className="nav-item">
                <Dropdown>
                  <Dropdown.Toggle variant="none" bsPrefix="custom p-0 shadow-none">
                    <img src='/assets/image/uk.webp' className='rounded-circle mr-2' width='25px' height='25px' />
                    English <ChevronDown className='ml-1' />
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item className='px-2 py-2' href='#'>
                      <img src='/assets/image/uk.webp' className='rounded-circle mr-2' width='25px' height='25px' />
                      <span style={{fontSize: '14px'}}>English</span>
                    </Dropdown.Item>
                    <Dropdown.Item className='px-2 py-2' href='#'>
                      <img src='/assets/image/arabic.png' className='rounded-circle mr-2' width='25px' height='25px' />
                      <span style={{fontSize: '14px'}}>Arabic</span>
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </li>
            </ul>
            {!isAuth?
            <button
              onClick={() => history.push("/login")}
               className="primaryButton mt-0"
              style={{ padding: "11px 36px" }}
            >
              Log in
            </button>
            : null}
            {isAuth ? (
              <>
                <div  className="navbar-nav" style={{flexDirection: "row"}}>
                  <img
                    src="/assets/image/notification.svg"
                    alt="svg"
                    className="notiIcon"
                  />
                  <HeaderProfile />
                </div>
              </>
            ) : '' }
          </div>
        </>
     
    </nav>
    </>
  );
}
