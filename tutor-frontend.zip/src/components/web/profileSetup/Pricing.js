import React, { Fragment, useState,useEffect } from "react";
import {
  ChechBoxInput,
  SelectInput,
  TextInput,
} from "../../basic/RenderInputs";
import * as Yup from "yup";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { languageOptions } from "../../../views/web/profileSetup/constant";
import { useSelector } from "react-redux";
export default function Pricing({
  formState,
  setFormState,
  setActiveTab,
  onDone,
  prev,
}) {
  const {value} = useSelector((state) => state.student);
  const [localPrices, setLocalPrices] = useState({});
  const [selectPkgPrice, setSelectPkgPrice] = useState("");
  const [localPkg, setLocalPkg] = useState({
    four_class_rate: "",
    eight_class_rate: "",
    twelve_class_rate: "",
  });
  const [loading, setloading] = useState(false);
  let dynamicValidations = {};
  formState.schedule.class_time.forEach((item) => {
    dynamicValidations[`${item}_min_rate`] = Yup.number().required(
      `Please Enter the ${item} minutes rate`
    );
    formState.pricing[`${item}_min_rate`] = "";
  });

  // validations
  const validationSchema = Yup.object().shape({
    ...dynamicValidations,
    // price_package: Yup.string().required("Please Select Price"),
    // four_class_rate: Yup.number().required(
    //   "Please Enter the 4 classes package rate"
    // ),
    // eight_class_rate: Yup.number().required(
    //   "Please Enter the 8 classes package rate"
    // ),
    // twelve_class_rate: Yup.number().required(
    //   "Please Enter the 12 classes package rate"
    // ),
  });

  // handle submit
  const handleSubmit = async (formValues) => {
    setloading(true);
    const {
      four_class_rate,
      eight_class_rate,
      twelve_class_rate,
      ...classTimePricing
    } = formValues;

    const classTimeState = formState.schedule.class_time.reduce((acc, curr) => {
      return classTimePricing[`${curr}_min_rate`]
        ? [...acc, { time: curr, price: classTimePricing[`${curr}_min_rate`] }]
        : acc;
    }, []);

    const data = {
      ...formState,
      pricing: {
        four_class_rate: localPkg.four_class_rate,
        eight_class_rate: localPkg.eight_class_rate,
        twelve_class_rate: localPkg.twelve_class_rate,
      },
      classTimeState,
    };
    // const data = {
    //   ...formState,
    //   pricing: { four_class_rate, eight_class_rate, twelve_class_rate },
    //   classTimeState,
    // };
    setFormState(data);
    await onDone(data);
    setloading(false);
  };

  let timeOptionsArray = formState.schedule.class_time.map((el) => ({
    value: el,
    text: el,
  }));

  const onChangePackgePrice = (e) => {
    let value = e.target.value;
    setSelectPkgPrice(String(value));
    let selectPriceValue = localPrices[value];
    setLocalPkg({
      four_class_rate: Number(selectPriceValue) * 4,
      eight_class_rate: Number(selectPriceValue) * 8,
      twelve_class_rate: Number(selectPriceValue) * 12,
    });
  };

  const handleChange = (e) => {
    setLocalPrices({
      ...localPrices,
      [e.target.name.split("_")[0]]: e.target.value || "0",
    });
  };

  // main return
  return (
    <div className="profilePricing">
       {prev ? null : (<h1 className="title mt-3">Pricing</h1>)}
      <Formik
        initialValues={formState.pricing}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
        enableReinitialize={true}
      >
        <Form className="mt-3">
          {formState.schedule.class_time.map((item, index) => {
            return (
              <Form onChange={handleChange}>
                <Fragment>
                  <h1 className="title mt-4 mb-2">{item} minutes rate</h1>
                  <Field
                    component={TextInput}
                    type="number"
                    name={`${item}_min_rate`}
                    placeholder={`Write your ${item} rate for teaching`}
                  />
                </Fragment>
              </Form>
            );
          })}
          {!prev?(
            <span style={{ display: "flex" }}>
              <h1 className="title mt-3">Packages</h1>
              <div style={{ width: "20%", margin: "12px 0px 0px 40px" }}>
                <Formik>
                  <Form>
                    <Field
                      component={SelectInput}
                      name="price_package"
                      onChange={onChangePackgePrice}
                      placeholder="Select Price"
                      options={timeOptionsArray}
                      type="select"
                    />
                    {timeOptionsArray.length ===
                      Object.keys(localPrices).length &&
                      selectPkgPrice === "" && (
                        <div className="errorText">Please Select Price</div>
                      )}
                  </Form>
                </Formik>
              </div>
            </span>
          ):null}
          <h1 className="title mt-4 mb-2">4 classes package rate</h1>
          <Field
            component={TextInput}
            type="number"
            name="four_class_rate"
            placeholder="Write your 4 classes package rate"
            value={localPkg.four_class_rate}
          />
          <h1 className="title mt-4 mb-2">8 classes package rate</h1>
          <Field
            component={TextInput}
            type="number"
            name="eight_class_rate"
            placeholder="Write your 8 classes package rate"
            value={localPkg.eight_class_rate}
          />
          <h1 className="title mt-4 mb-2">12 classes package rate</h1>
          <Field
            component={TextInput}
            type="number"
            name="twelve_class_rate"
            placeholder="Write your 12 classes package rate"
            value={localPkg.twelve_class_rate}
          />
          {value && formState?.teach_type?.includes('student_home') ?
          <>
            <h1 className="title mt-4 mb-2">Travel Cost</h1>
            <Field
              component={TextInput}
              type="number"
              name="travel_cost"
              placeholder="Write your Travel cost"
            />
          </>
          :null}
          <Field
            id="offer_demo"
            name="offer_demo"
            component={ChechBoxInput}
            label={`I offer a demo lesson too for my students.`}
          />
          <div className="centerFlex mt-5 mb-5">
            <div className="flexCenter">
              {prev ? null : (
                <button
                  type="button"
                  onClick={() => setActiveTab("Schedule")}
                  className="prevBtn mx-auto mr-md-5"
                >
                  Previous
                </button>
              )}
              <button
                className="primaryButton mt-0"
                type="submit"
                // disabled={loading}
                style={{ maxWidth: "388px", width: "300px" }}
              >
                {loading ? "Updating..." : "Done"}
              </button>
            </div>
          </div>
        </Form>
      </Formik>
    </div>
  );
}
