import React, { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { galleryInit } from "../../../views/web/profileSetup/constant";

export default function Gallery({ formState, setFormState, setActiveTab }) {
  // state
  const [gallery, setGallery] = useState(
    formState.gallery.length > 0 ? formState.gallery : galleryInit
  );
  //  on file drop
  const onDrop = useCallback((acceptedFiles) => {
    let counter = 0;
    setGallery((prev) =>
      prev.reduce((acc, curr) => {
        if (!curr.image && counter < acceptedFiles.length) {
          const res = [
            ...acc,
            {
              ...curr,
              image: acceptedFiles[counter],
              imageObj: URL.createObjectURL(acceptedFiles[counter]),
            },
          ];
          counter++;
          return res;
        }
        return [...acc, curr];
      }, [])
    );
  }, []);
  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    maxFiles: 9,
  });

  const removeFile = (id) => {
    setGallery((prev) =>
      prev.reduce((acc, curr) => {
        if (curr.id >= id) {
          return [
            ...acc,
            {
              ...curr,
              image: curr.id === gallery.length ? null : gallery[curr.id].image,
              imageObj:
                curr.id === gallery.length ? null : gallery[curr.id].imageObj,
            },
          ];
        }
        return [...acc, curr];
      }, [])
    );
  };
  // on Continue
  const onContinue = () => {
    setFormState({ ...formState, gallery });
    setActiveTab("Schedule");
  };
  // main return
  return (
    <main  className="container-fluid profileGallery">
      <div  className="row" {...getRootProps()}>
        <input {...getInputProps()} />
        {gallery.map((item, index) => {
          return (
            <div key={index}  className="col-md-4 col-xl-3">
              {item.image ? (
                <div
                  onClick={(e) => e.stopPropagation()}
                   className="galleryItem image"
                >
                  <div onClick={() => removeFile(item.id)} style={{ width: '35px', height: '35px', fontSize: '18px' }}  className="close text-center text-white">
                    {" "}
                    &#10006;{" "}
                  </div>
                  <img
                    style={{ objectFit: 'cover', objectPosition: 'top' }}
                    src={item.imageObj ? item.imageObj : item.image}
                    alt="upload Image"
                    className='w-100 h-100'
                  />
                </div>
              ) : (
                <div className="galleryItem">
                  <img src="/assets/image/plus.svg" alt="icon" />
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div  className="centerFlex mt-5 mb-5">
        <div  className="flexCenter">
          <button
            onClick={() => setActiveTab("Highlights")}
             className="prevBtn mx-auto mr-md-5"
          >
            Previous
          </button>
          <button
             className="primaryButton mt-0"
            style={{ maxWidth: "388px", width: "300px" }}
            onClick={onContinue}
          >
            Continue
          </button>
        </div>
      </div>
    </main>
  );
}
