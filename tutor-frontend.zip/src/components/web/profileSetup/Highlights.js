import React, { useEffect, useRef, useState } from "react";
import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import { SelectInput } from "../../basic/RenderInputs";
import { useDispatch, useSelector } from "react-redux";
import {
  ageOptions,
  classTypeOptions,
  languageOptions,
  levelTeachOptions,
  mainFieldOptions,
  whereTeachOptions,
} from "../../../views/web/profileSetup/constant";
import AxiosBase from "../../../config/AxiosBase";
import { Trash, X } from "react-bootstrap-icons";
import { setStudentHome } from "../../../redux/actions/dashboardActions";
export default function Highlights({ formState, setFormState, setActiveTab }) {
  const {value} = useSelector((state) => state.student);
  const dispatch = useDispatch();
  const {
    user: { _id: userId },
  } = useSelector((state) => state.auth);
  // states
  const [teach_language, setTeach_language] = useState(
    formState.teach_language || []
  );
  const [teach_type, setTeach_type] = useState(formState.teach_type || []);
  const [you_teach, setYou_teach] = useState(formState.you_teach || []);
  const [level_you_teach, setLevel_you_teach] = useState(
    formState.level_you_teach || []
  );
  const [student_age_you_teach, setStudent_age_you_teach] = useState(
    formState.student_age_you_teach || []
  );
  const [class_type, setClass_type] = useState(formState.class_type || []);
  const [main_field, setMain_field] = useState(formState.main_field || []);
  const [disbaleContinue, setDisbaleContinue] = useState(
    teach_language.length > 0 &&
      teach_type.length > 0 &&
      you_teach.length > 0 &&
      level_you_teach.length > 0 &&
      student_age_you_teach.length > 0 &&
      main_field.length > 0
      ? false
      : true
  );

  const idInputRef = useRef(null);
  // trigger file input
  const triggerInput = () => {
    idInputRef.current.click();
  };

  //   validation schemea
  const LanguageValidationSchema = Yup.object().shape({
    teach_language: Yup.string().required("Please Select the name of language"),
  });
  // on language add
  const onLanguageAdd = (formValues, formikFun) => {
    if (teach_language.includes(formValues.teach_language)) {
      formikFun.resetForm();
      return;
    }
    setTeach_language((prev) => [...prev, formValues.teach_language]);
    formikFun.resetForm();
  };
  //   validation schemea you teach
  const MainFieldValidationSchema = Yup.object().shape({
    main_field: Yup.string().required("Please Select the main field"),
  });

  // on Main Field Add
  const onMainFieldAdd = (formValues, formikFun) => {
    if (main_field.includes(formValues.main_field)) {
      formikFun.resetForm();
      return;
    }
    setMain_field((prev) => [...prev, formValues.main_field]);
    formikFun.resetForm();
  };
  //   validation schemea you teach
  const YouTeachValidationSchema = Yup.object().shape({
    you_teach: Yup.string().required("Please Select the name of subject"),
  });
  // on You teach add
  const onYouTeachAdd = (formValues, formikFun) => {
    if (you_teach.includes(formValues.you_teach)) {
      formikFun.resetForm();
      return;
    }
    setYou_teach((prev) => [...prev, formValues.you_teach]);
    formikFun.resetForm();
  };
  //   validation schemea of level you teach
  const TeachLevelValidationSchema = Yup.object().shape({
    level_you_teach: Yup.string().required(
      "Please Select the level of student you teach"
    ),
  });
  // on teaech level add
  const onTeachLevelAdd = (formValues, formikFun) => {
    if (level_you_teach.includes(formValues.level_you_teach)) {
      formikFun.resetForm();
      return;
    }
    setLevel_you_teach((prev) => [...prev, formValues.level_you_teach]);
    formikFun.resetForm();
  };
  //   validation schemea of student age add
  const StudentAgeValidationSchema = Yup.object().shape({
    from_age: Yup.string().required("Please Select the student age from range"),
    to_age: Yup.string()
      .required("Please Select the student age to range")
      .when("from_age", (from_age, schema) => {
        return schema.test({
          test: (to_age) => {
            if (!to_age) return true;
            return Number(to_age) > Number(from_age);
          },
          message: "To age cannot be less the from age",
        });
      }),
  });
  // on student age add
  const onStudentAgeAdd = (formValues, formikFun) => {
    setStudent_age_you_teach((prev) => [...prev, formValues]);
    formikFun.resetForm();
  };

  // handle where teach
  const handleWhereTeach = (value) => {
    if (teach_type.includes(value)) {
      setTeach_type((prev) => prev.filter((el) => el !== value));
      if(value=="student_home"){
        dispatch(setStudentHome(false));
      }
    } else {
      setTeach_type((prev) => [...prev, value]);
      if(value=="student_home"){
        dispatch(setStudentHome(value));
      }
    }
  };
  // handle class type
  const handleClassType = (value) => {
    if (class_type.includes(value)) {
      setClass_type((prev) => prev.filter((el) => el !== value));
    } else {
      setClass_type((prev) => [...prev, value]);
    }
  };
  // on Profile Change
  const removeData = (field_key) => {
    setFormState({ ...formState, [field_key]: "" });
  }
  const onIdInputChange = async (e) => {
    if (e.target.files.length > 0) {
      setFormState({ ...formState, iqma: e.target.files[0] });
      const formData = new FormData();
      formData.append("file", e.target.files[0]);
      await AxiosBase.put(
        `/tutor/upload-id-iqama-verification/${userId}`,
        formData
      );
    } else return;
  };

  // activating continue button
  useEffect(() => {
    if (
      teach_type.length > 0 &&
      teach_language.length > 0 &&
      you_teach.length > 0 &&
      level_you_teach.length > 0 &&
      student_age_you_teach.length > 0 &&
      class_type.length > 0 &&
      main_field.length > 0 &&
      formState.iqma
    ) {
      setDisbaleContinue(false);
    } else if (!disbaleContinue) {
      setDisbaleContinue(false);
    }
    return () => {};
  }, [
    teach_language,
    teach_type,
    you_teach,
    level_you_teach,
    student_age_you_teach,
    class_type,
    main_field,
    disbaleContinue,
    formState.iqma,
  ]);

  // on Continue
  const onContinue = () => {
    const data = {
      teach_language,
      teach_type,
      you_teach,
      level_you_teach,
      student_age_you_teach,
      class_type,
      main_field,
    };
    setFormState({ ...formState, ...data });
    setActiveTab("Gallery");
  };
  const delItem = (data, dataUpdate, index) => {
    const result = data.filter((x, i) => i !== index);
    dataUpdate(result);
  };
  // main return
  return (
    <main className="container-fluid profileHighlights">
      <section>
        <div className="title mt-3">Language you can teach in</div>
        {teach_language.map((item, index) => {
          return (
            <p key={index}>
              &#x25CF; {item}.
              <span
                type="button"
                className="ml-2 text-danger"
                onClick={() =>
                  delItem(teach_language, setTeach_language, index)
                }
              >
                <Trash />
              </span>
            </p>
          );
        })}
        <Formik
          initialValues={{ teach_language: "" }}
          validationSchema={LanguageValidationSchema}
          onSubmit={onLanguageAdd}
          enableReinitialize
        >
          <Form className="mt-3">
            <Field
              component={SelectInput}
              name="teach_language"
              placeholder="Select language"
              options={languageOptions}
              type="select"
            />

            <div className="flexCenter justify-content-end">
              <button type="submit" className="primaryButton outline addBtn">
                Add
              </button>
            </div>
          </Form>
        </Formik>
      </section>
      <section>
        <div className="title mt-3 mb-3">From where you can teach?</div>
        <div className="flexBetweenCenter">
          {whereTeachOptions.map((item) => {
            const isActive = teach_type.includes(item.value);
            return (
              <div
                key={item.value}
                onClick={
                  () => 
                  {
                    handleWhereTeach(item.value);
                  }
                }
                className="flexCenter teachItem"
              >
                <img src={item.img} alt="vsg"></img>
                <h3>{item.name}</h3>
                <img
                  src={
                    isActive
                      ? "/assets/image/checkedCircle.svg"
                      : "/assets/image/uncheckedCircle.svg"
                  }
                  alt="icon"
                ></img>
              </div>
            );
          })}
        </div>
      </section>
      <section>
        <div className="title mt-5 mb-3">ID/Iqama</div>
        <p className="textGrey poppinsMd">
          Please verify your ID / Iqama with us by submitting the relevant
          document.
        </p>
        <div className="flexCenter">
          <button
            onClick={triggerInput}
            className="flexCenter primaryButton green mt-2"
          >
            <input
              ref={idInputRef}
              onChange={onIdInputChange}
              type="file"
              className="d-none"
            />
            <img
              src="/assets/image/upload-cloud.svg"
              alt="svg"
              className="mr-2"
            />
            <span>Upload document</span>
          </button>
          <div className="ml-5 textGrey poppinsSb ">
            {formState.iqma ? 
              <>
                {formState.iqma.name}
                &nbsp;&nbsp;
                <button type="button" style={{lineHeight:1,width:"25px",height:"25px"}} 
                  className="cursor-pointer text-white p-0 border-0 rounded-circle bg-danger"
                  onClick={()=>removeData("iqma")}>
                  <X size={20} />
                </button>
              </>
            :"No file chosen"}
          </div>
        </div>
      </section>
      {/* <section>
        <div  className="title mt-4 mb-2">Main field / Category</div>
        <SelectInput
          field={{ value: main_field }}
          form={{ touched: {}, errors: {} }}
          name="main_field"
          placeholder="Select your main field e.g. Computer Science"
          type="select"
          options={mainFieldOptions}
          onChange={(e) => setMain_field(e.target.value)}
          noFormik
        />
      </section> */}
      <section>
        <div className="title mt-5 mb-1">Main field / Category</div>
        {main_field.map((item, index) => {
          return (
            <p key={index}>
              &#x25CF; {item}.
              <span
                type="button"
                className="ml-2 text-danger"
                onClick={() => delItem(main_field, setMain_field, index)}
              >
                <Trash />
              </span>
            </p>
          );
        })}
        <Formik
          initialValues={{ main_field: "" }}
          validationSchema={MainFieldValidationSchema}
          onSubmit={onMainFieldAdd}
          enableReinitialize
        >
          <Form className="mt-3">
            <Field
              component={SelectInput}
              name="main_field"
              placeholder="Select your main field e.g. Computer Science"
              options={mainFieldOptions}
              type="select"
            />

            <div className="flexCenter justify-content-end">
              <button type="submit" className="primaryButton outline addBtn">
                Add
              </button>
            </div>
          </Form>
        </Formik>
      </section>
      <section>
        <div className="title mt-3 mb-1">What do you teach?</div>
        {you_teach.map((item, index) => {
          return (
            <p key={index}>
              &#x25CF; {item}.
              <span
                type="button"
                className="ml-2 text-danger"
                onClick={() => delItem(you_teach, setYou_teach, index)}
              >
                <Trash />
              </span>
            </p>
          );
        })}
        <Formik
          initialValues={{ you_teach: "" }}
          validationSchema={YouTeachValidationSchema}
          onSubmit={onYouTeachAdd}
          enableReinitialize
        >
          <Form className="mt-3">
            <Field
              component={SelectInput}
              name="you_teach"
              placeholder="Select the subjects of yours field"
              options={languageOptions}
              type="select"
            />

            <div className="flexCenter justify-content-end">
              <button type="submit" className="primaryButton outline addBtn">
                Add
              </button>
            </div>
          </Form>
        </Formik>
      </section>
      <section>
        <div className="title mt-3 mb-1">Levels you teach</div>
        {level_you_teach.map((item, index) => {
          return (
            <p key={index}>
              &#x25CF; {item} .
              <span
                type="button"
                className="ml-2 text-danger"
                onClick={() =>
                  delItem(level_you_teach, setLevel_you_teach, index)
                }
              >
                <Trash />
              </span>
            </p>
          );
        })}
        <Formik
          initialValues={{ level_you_teach: "" }}
          validationSchema={TeachLevelValidationSchema}
          onSubmit={onTeachLevelAdd}
          enableReinitialize
        >
          <Form className="mt-3">
            <Field
              component={SelectInput}
              name="level_you_teach"
              placeholder="Select the student level you teach"
              options={levelTeachOptions}
              type="select"
            />

            <div className="flexCenter justify-content-end">
              <button type="submit" className="primaryButton outline addBtn">
                Add
              </button>
            </div>
          </Form>
        </Formik>
      </section>
      <section>
        <div className="title mt-3 mb-1">Age of student you teach</div>
        {student_age_you_teach.map((item, index) => {
          return (
            <p key={index}>
              &#x25CF; {item.from_age} - {item.to_age} year old.
              <span
                type="button"
                className="ml-2 text-danger"
                onClick={() =>
                  delItem(
                    student_age_you_teach,
                    setStudent_age_you_teach,
                    index
                  )
                }
              >
                <Trash />
              </span>
            </p>
          );
        })}
        <Formik
          initialValues={{ from_age: "", to_age: "" }}
          validationSchema={StudentAgeValidationSchema}
          onSubmit={onStudentAgeAdd}
          enableReinitialize
        >
          <Form className="mt-3">
            <div className="row">
              <div className="col-md-6">
                <Field
                  component={SelectInput}
                  name="from_age"
                  placeholder="From age"
                  options={ageOptions}
                  type="select"
                />
              </div>
              <div className="col-md-6">
                <Field
                  component={SelectInput}
                  name="to_age"
                  placeholder="To age"
                  options={ageOptions}
                  type="select"
                />
              </div>
            </div>

            <div className="flexCenter justify-content-end">
              <button type="submit" className="primaryButton outline addBtn">
                Add
              </button>
            </div>
          </Form>
        </Formik>
      </section>
      {/* <section>
        <div className="title mt-3 mb-3">Class type you offer</div>
        <div className="flexBetweenCenter" style={{ maxWidth: "550px" }}>
          {classTypeOptions.map((item) => {
            const isActive = class_type.includes(item.value);
            return (
              <div
                key={item.value}
                onClick={() => handleClassType(item.value)}
                className="flexCenter teachItem"
              >
                <h3>{item.name}</h3>
                <img
                  src={
                    isActive
                      ? "/assets/image/checkedCircle.svg"
                      : "/assets/image/uncheckedCircle.svg"
                  }
                  alt="icon"
                ></img>
              </div>
            );
          })}
        </div>
      </section> */}
      <div className="centerFlex mt-5 mb-5">
        <div className="flexCenter">
          <button
            onClick={() => setActiveTab("About")}
            className="prevBtn mx-auto mr-md-5"
          >
            Previous
          </button>
          <button
            className="primaryButton mt-0"
            // disabled={disbaleContinue}
            disabled={
              teach_language.length > 0 &&
              teach_type.length > 0 &&
              you_teach.length > 0 &&
              level_you_teach.length > 0 &&
              student_age_you_teach.length > 0 &&
              main_field.length > 0
                ? false
                : true
            }
            style={{ maxWidth: "388px", width: "300px" }}
            onClick={onContinue}
          >
            Continue
          </button>
        </div>
      </div>
    </main>
  );
}
