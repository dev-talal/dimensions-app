import React, { useEffect, useRef, useState } from "react";
import {
  countryOptions,
  initEducationObj,
  initExperinceObj,
  yearOptions,
} from "../../../views/web/profileSetup/constant";
import {
  ChechBoxInput,
  SelectInput,
  TextInput,
} from "../../basic/RenderInputs";
import * as Yup from "yup";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { ref } from "yup";
import AxiosBase from "../../../config/AxiosBase";
import { useSelector } from "react-redux";
import { Pencil, Trash, X } from "react-bootstrap-icons";
import { countriesList, citiesList } from "../../../enums/user.enum";
import Autocomplete from "react-autocomplete";
import CitiesList from "../../search/MapCities";

export default function About({ formState, setFormState, setActiveTab }) {
  const {
    user: { _id: userId },
  } = useSelector((state) => state.auth);

  // states
  const [intro, setintro] = useState(formState.intro || "");
  const [about_you, setAbout_you] = useState(formState.about_you || "");
  const [education, setEducation] = useState(formState.education || []);
  const [experience, setExperince] = useState(formState.experience || []);
  const [initExpObj,setExpObj] = useState(initExperinceObj);
  const [isEditTime, setIsEditTime] = useState({is:false,type:"",index:""});
  const [initEObj,setEObj] = useState(initEducationObj);
  const [experienceShow,setExperienceShow] = useState(true);
  const [disbaleContinue, setDisbaleContinue] = useState(
    formState.intro ? false : true
  );

  const idInputRef = useRef(null);
  // trigger file input
  const triggerInput = () => {
    idInputRef.current.click();
  };

  //   validation schemea
  const EducationValidationSchema = Yup.object().shape({
    name_of_institution: Yup.string().required(
      "Please Enter the name of institution"
    ),
    degree_title: Yup.string().required("Please Enter the degree title"),
    country: Yup.string().required("Please Enter the country"),
    city: Yup.string().required("Please Enter the city"),
  });
  const ExperinceValidationSchema = Yup.object().shape({
    teaching_place: Yup.string().required(
      "Please Enter the name of instituation"
    ),
    from_year: Yup.number().required("Please select starting date").nullable(),
    to_year: 
    Yup.number().when("currently_working_here", {
      is: false,
      then:Yup.number().required('Please select ending date').min(
        Yup.ref("from_year"),
        "Experience End Year must be greater then Start Year"
      ).nullable(),
      otherwise: Yup.number().nullable()
    }),
    short_description: Yup.string().required(
      "Please enter a short description"
    ),
    currently_working_here:Yup.bool().oneOf([true], "Check if currenty working").when("to_year", {
      is: value => !value,
      then: Yup.bool().oneOf([true], "Check if currently working"),
      otherwise: Yup.bool().oneOf([false])
    })
  },['currently_working_here','to_year']);

  // on education add
  const onEducationAdd = (formValues, formikFun) => {
    const {is,index,type} = isEditTime;
    if(is && type=="education"){
      setEducation([
        ...education.slice(0, index),
        formValues,
        ...education.slice(index + 1, education.length)
      ]);
      setIsEditTime({is:false,type:"",index:""});
    }else{
      setEducation((prev) => [...prev, formValues]);
    }
    setEObj(initEducationObj);
    formikFun.resetForm();
  };
  // on experience add
  const onExperinceAdd = (formValues, formikFun) => {
    const {is,index,type} = isEditTime;
    if(is && type=="experience"){
      setExperince([
        ...experience.slice(0, index),
        formValues,
        ...experience.slice(index + 1, experience.length)
      ]);
      setIsEditTime({is:false,type:"",index:""});
    }else{
      setExperince((prev) => [...prev, formValues]);
    }
    setExpObj(initExperinceObj);
    formikFun.resetForm();
  };
  const infoEdit = (obj,index,type) => {
    const updatedTodos =  obj[index];
    setIsEditTime({is:true,type:type,index:index});
    if(type=="experience"){
      setEObj(initEducationObj);
      setExpObj(updatedTodos);
    }else{
      setExpObj(initExperinceObj);
      setEObj(updatedTodos);
    }
    
  }
  // activating continue button
  useEffect(() => {
    if (intro && about_you && education.length > 0 && experience.length > 0) {
      setDisbaleContinue(false);
    } else if (intro && about_you && education.length > 0 && experienceShow==false) {
      if(!disbaleContinue){
       setDisbaleContinue(false);
      }
      else{
        setDisbaleContinue(false);
      }
    }else{
      setDisbaleContinue(true);
    }
    return () => {};
  }, [intro, about_you, education, experience, disbaleContinue,experienceShow]);
  useEffect(() => {
    if(experienceShow==false)
    setExperince([]);
  },[experienceShow])
  // on Files Change
  const onIdInputChange = async (e) => {
    if (e.target.files.length > 0) {
      const fileState = [...formState.certificates, ...e.target.files];
      setFormState({ ...formState, certificates: fileState });
      const formData = new FormData();
      for (let i = 0; i < fileState.length; i++) {
        formData.append(`files[${i}]`, fileState[i], fileState[i].name);
      }
      await AxiosBase.put(`/tutor/upload-certifications`, formData);
    } else return;
  };

  // on Continue
  const onContinue = () => {
    const data = { intro, about_you, education, experience };
    setFormState({ ...formState, ...data });
    setActiveTab("Highlights");
  };
  const delItem = (data,dataUpdate,index) => {
    const result = data.filter((x,i)=>i!==index);
    setIsEditTime({is:false,type:"",index:""});
    dataUpdate(result);
  }
  const removeData = (field_key,val,allData) => {
    setFormState({ ...formState, [field_key]: allData.filter((x)=>x.name!==val.name) });
  }
  const CountryList = ({
    field: { onChange, value, ...field },
    form: { touched, errors, setFieldValue, resetForm },
    ...props
  }) => {
    const [filteredItems, setFilteredItems] = useState(countriesList);
  
    const handleInputChange = (e) => {
      const inputValue = e.target.value;
      const filtered = countriesList.filter((item) =>
        item.name.toLowerCase().startsWith(inputValue.toLowerCase())
      );
      setFilteredItems(filtered);
      onChange(e); // update input field value
      setFieldValue(field.name, e.target.value); // update form field value
    };
  
    return (
      <>
        <Autocomplete
          getItemValue={(item) => item['name']}
          items={filteredItems}
          onSelect={(val) => { setFieldValue('country', val); setFieldValue('city','') }}
          onChange={handleInputChange}
          value={value} // bind to form field value
          wrapperProps={{
            className: 'd-block w-100',
          }}
          renderInput={(props) => (
            <input
              className="textInput form-control"
              {...props}
              value={value}
              placeholder='Country'
            />
          )}
          menuStyle={{
            position: 'absolute',
            left: '16px',
            top: '55px',
            zIndex: 999,
            maxHeight: '50vh',
            overflowY: 'auto',
            boxShadow: 'var(--shadow)',
            borderRadius: 10,
          }}
          renderItem={(item, isHighlighted) => (
            <div style={{ background: isHighlighted ? 'lightgray' : 'white', padding: 10 }}>
              {item.name}
            </div>
          )}
        />
        <ErrorMessage name={'country'} className="errorText">
          {(msg) => <div className="errorText">{msg} </div>}
        </ErrorMessage>
      </>
    );
  };

  const CityList = ({
    field: { onChange, value, ...field },
    form: { touched, errors, setFieldValue, values },
    ...props
  }) => {
    const findCity = citiesList[values.country]
    const [cFilteredItems, setCFilteredItems] = useState(findCity);
  
    const handleInputChange = (e) => {
      const inputValue = e.target.value;
      const filtered = findCity.filter((item) =>
        item.toLowerCase().startsWith(inputValue.toLowerCase())
      );
      setCFilteredItems(filtered);
      onChange(e);
      setFieldValue(field.name, e.target.value);
    };
  
    return (
      <>
        <Autocomplete
          getItemValue={(item) => item}
          items={findCity || []}
          onSelect={(val) => setFieldValue('city', val)}
          onChange={handleInputChange}
          value={value} // bind to form field value
          wrapperProps={{
            className: 'd-block w-100',
          }}
          renderInput={(props) => (
            <input
              className="textInput form-control"
              {...props}
              value={value}
              placeholder='City'
              disabled={ !values.country }
            />
          )}
          menuStyle={{
            position: 'absolute',
            left: '16px',
            top: '55px',
            zIndex: 999,
            maxHeight: '50vh',
            overflowY: 'auto',
            boxShadow: 'var(--shadow)',
            borderRadius: 10,
          }}
          renderItem={(item, isHighlighted) => (
            <div style={{ background: isHighlighted ? 'lightgray' : 'white', padding: 10 }}>
              {item}
            </div>
          )}
        />
        <ErrorMessage name={'city'} className="errorText">
          {(msg) => <div className="errorText">{msg} </div>}
        </ErrorMessage>
      </>
    );
  };
  
  // main return
  return (
    <div  className="container-fluid profileAbout">
      <input
        type="text"
         className="textInput mt-3"
        placeholder="Short introduction"
        value={intro}
        onChange={(e) => setintro(e.target.value)}
      />
      <textarea
        rows="5"
         className="textInput"
        placeholder="Write something about yourself"
        value={about_you}
        onChange={(e) => setAbout_you(e.target.value)}
        style={{ height: 150 }}
      />
      <h1  className="title">Education</h1>
      <div  className="flexCenter">
        {education.map((item, index) => {
          return (
            <div key={index}  className="eduDetail pt-3">
              <div className="w-100 d-flex mb-2 justify-content-end">
                <span type="button" className="mr-3 text-danger" onClick={()=>delItem(education,setEducation,index)}>
                  <Trash size={18} />
                </span>
                <span className="d-block">
                  <Pencil color="#007bff"  type="button" className="mr-2" onClick={() => infoEdit(education,index,"education")} size={17} />
                </span>
              </div>
              <div  className="eduBox">
                <img src="/assets/image/eduCap.svg" alt="eduCap" />
              </div>
              <div>
                <h3>
                  {item.name_of_institution}, {item.country}.
                </h3>
                <h4>{item.degree_title}</h4>
                <div  className="flexBetweenCenter">
                  <p>
                    &#x25CF; {item.city}, {item.country}.
                  </p>

                  <p>
                    &#x25CF;{" "}
                    {item.currently_enrolled ? "Present" : item.completion_year}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <Formik
        initialValues={initEObj}
        validationSchema={EducationValidationSchema}
        onSubmit={onEducationAdd}
        enableReinitialize
      >
        <Form  className="mt-3">
          <Field
            component={TextInput}
            name="name_of_institution"
            placeholder="Name of Institution"
          />
          <Field
            component={TextInput}
            name="degree_title"
            placeholder="Degree title"
          />
          <div  className="row">
            <div className="col-md-6">
             <Field component={CountryList} name="country" />
            </div>
            <div  className="col-md-6">
              {/* <Field component={TextInput} name="city" placeholder="City" /> */}
              <Field component={CityList} name="city" />
            </div>
          </div>
          <Field
            component={SelectInput}
            name="completion_year"
            placeholder="Completion year"
            options={yearOptions}
            type="select"
          />
          <Field
            id="currently_enrolled"
            name="currently_enrolled"
            component={ChechBoxInput}
            label={`Currently enrolled`}
          />

          <div  className="flexCenter justify-content-end">
            <button type="submit"  className="primaryButton outline addBtn">
              Add
            </button>
          </div>
        </Form>
      </Formik>
      <h1  className="title mt-5">Experience</h1>
      <div  className="flexCenter">
        {experience.map((item, index) => {
          return (
            <div key={index}  className="eduDetail pt-3">
              <div className="w-100 d-flex mb-2 justify-content-end">
                <span type="button" className="mr-3 text-danger" onClick={()=>delItem(experience,setExperince,index)}>
                  <Trash size={18} />
                </span>
                <span className="d-block">
                  <Pencil color="#007bff"  type="button" className="mr-2" onClick={() => infoEdit(experience,index,"experience")} size={17} />
                </span>
              </div>
              <div>
                <h3>&#x25CF; {item.teaching_place}</h3>
                <p>
                  {item.from_year}-
                  {item.currently_working_here ? "present" : item.to_year}
                </p>
                <h4>{item.short_description}</h4>
              </div>
            </div>
          );
        })}
      </div>
      <Formik
        initialValues={initExpObj}
        validationSchema={ExperinceValidationSchema}
        onSubmit={onExperinceAdd}
        enableReinitialize
      >
        <Form  className="mt-3">
          {experienceShow?
          <>
          <Field
            component={TextInput}
            name="teaching_place"
            placeholder="Work experience"
          />

          <div  className="row">
            <div  className="col-md-6">
              <Field
                component={SelectInput}
                name="from_year"
                placeholder="From year"
                options={yearOptions}
                type="select"
              />
            </div>
            <div  className="col-md-6">
              <Field
                component={SelectInput}
                name="to_year"
                placeholder="To year"
                options={yearOptions}
                type="select"
              />
            </div>
          </div>
          <Field
            component={TextInput}
            name="short_description"
            placeholder="Short description"
          />
          <Field
            id="currently_working_here"
            name="currently_working_here"
            component={ChechBoxInput}
            label={`Currently working here`}
          />
          </>
          :null}
          <div className="mt-3">
            <Field
              id="no_experience"
              name="no_experience"
              component={ChechBoxInput}
              onChange={(e)=>setExperienceShow(!experienceShow)}
              label={`No experience`}
            />
          </div>
          {experienceShow?
          <div  className="flexCenter justify-content-end">
            <button type="submit"  className="primaryButton outline addBtn">
              Add
            </button>
          </div>
          :null}
        </Form>
      </Formik>

      <section>
        <h1  className="title mt-3 mb-1">Educational Certificates (optional)</h1>
        {formState?.certificates?.map((item, index) => {
          return <p className="pb-2" key={index}>&#x25CF; 
          {item.name}&nbsp;&nbsp;
          <button type="button" style={{lineHeight:1,width:"25px",height:"25px"}} 
            className="cursor-pointer text-white p-0 border-0 rounded-circle bg-danger"
            onClick={()=>removeData("certificates",item,formState?.certificates)}>
            <X size={20} />
          </button>
          </p>;
        })}
        <div  className="flexCenter">
          <button
            onClick={triggerInput}
             className="flexCenter primaryButton green mt-2"
          >
            <img
              src="/assets/image/upload-cloud.svg"
              alt="svg"
               className="mr-2"
            />
            <span>Upload documents</span>
          </button>
          <input
            ref={idInputRef}
            onChange={onIdInputChange}
            type="file"
             className="d-none"
            multiple
          />
          <div  className="ml-3 textGrey poppinsSb ">
            {formState.certificates.length < 1 && "No files added"}
          </div>
        </div>
      </section>

      <div  className="centerFlex mt-5 mb-5">
        <button
           className="primaryButton "
          disabled={disbaleContinue}
          style={{ maxWidth: "388px", width: "300px" }}
          onClick={onContinue}
        >
          Continue
        </button>
      </div>
    </div>
  );
}
