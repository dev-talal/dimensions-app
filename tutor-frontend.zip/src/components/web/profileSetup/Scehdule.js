import { format as formatDateFN, roundToNearestMinutes } from "date-fns";
import React, { useState, useEffect } from "react";
import { Pencil, Trash } from "react-bootstrap-icons";
import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import { formatDate } from "../../../helpers";
import {
  bookClassOptions,
  bufferTimeOptions,
  classAvailbilityInit,
  classDurationOption,
  futureBookOptions,
  shortNoticeOptions,
} from "../../../views/web/profileSetup/constant";
import { useLocation } from "react-router-dom";
export default function Scehdule({ formState, setFormState, setActiveTab }) {
  const location  = useLocation();
  const is_update = location.pathname.indexOf("/dashboard/classes/schedule") > -1?true:false;
  const [class_time, setClass_duration] = useState(
    formState.schedule.class_time
  );
  // setting custom class options if any
  const classTimeOption = [
    ...classDurationOption,
    ...formState.schedule.class_time.reduce((acc, curr) => {
      if (!classDurationOption.filter((el) => el.value !== curr)) {
        return [
          ...acc,
          {
            value: curr,
            text: `${curr} min`,
          },
        ];
      } else return acc;
    }, []),
  ];

  const [class_duration_options, setClass_duration_options] =
    useState(classTimeOption);
  const [showCustom, setShowCustom] = useState(false);
  const [customDurationInput, setCustomDurationInput] = useState("");
  // availbility state
  const [availability_active, setAvailability_active] = useState(
    formState.schedule.availability_active
  );
  const [showEndDate, setShowEndDate] = useState(
    formState.schedule.availability_active.until ? true : false
  );
  const [availability_time, setAvailability_time] =
    useState(classAvailbilityInit);
  const [showAvailableTime, setShowAvailableTime] = useState(false);
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [book_class, setBook_class] = useState(formState.schedule.book_class);
  const [isEditTime, setIsEditTime] = useState({
    is: false,
    name: "",
    index: "",
  });
  const [buffer_and_time_setting, setBuffer_and_time_setting] = useState(
    formState.schedule.buffer_and_time_setting
  );
  const [disbaleContinue, setDisbaleContinue] = useState(
    formState.schedule.availability_time.filter((el) => el.timings.length > 0)
      .length > 0
      ? false
      : true
  );

  // on custom duration add
  const onCustomDuration = (e) => {
    e.preventDefault();
    setClass_duration_options((prev) => [
      ...prev,
      { text: `${customDurationInput} min`, value: customDurationInput },
    ]);
    setClass_duration((prev) => [...prev, customDurationInput]);
    setShowCustom(false);
    setCustomDurationInput("");
  };

  // toggle Modal
  const toggleModal = () => {
    setShowAvailableTime(false);
  };

  // get Date from Time
  const getDateFromTIme = (time) => {
    let newTimeDate = new Date();
    let timeString = time;
    let timeArr = timeString.toString().split(":");

    newTimeDate.setHours(timeArr[0], timeArr[1], " 00");
    return newTimeDate;
  };

  // on add timings
  const addTimmings = () => {
    if (!startTime || !endTime) return;
    const { is, index, name } = isEditTime;
    if (is) {
      const indexToUpdate = availability_time.findIndex(
        (todo) => todo.name === name
      );
      const updatedTodos = [...availability_time];
      const result = updatedTodos[indexToUpdate].timings.filter(
        (x, i) => i == index
      );
      result[0].start_time = roundToNearestMinutes(getDateFromTIme(startTime));
      result[0].end_time = roundToNearestMinutes(getDateFromTIme(endTime));
      setAvailability_time(updatedTodos);
      setIsEditTime({ is: false, name: "", index: "" });
    } else {
      setAvailability_time((prev) =>
        prev.filter((el) => {
          if (el.name === showAvailableTime) {
            el.timings = [
              ...el.timings,
              {
                start_time: roundToNearestMinutes(getDateFromTIme(startTime), {
                  nearestTo: 15,
                }),
                end_time: roundToNearestMinutes(getDateFromTIme(endTime), {
                  nearestTo: 15,
                }),
              },
            ];
          }

          return el;
        })
      );
    }
    setShowAvailableTime(false);
  };

  // on book class add
  const addBookClass = (value, isActive) => {
    if (isActive) {
      setBook_class((prev) => prev.filter((el) => el !== value));
    } else {
      setBook_class((prev) => [...prev, value]);
    }
  };

  // activiating disbale button
  useEffect(() => {
    if (
      availability_time.filter((el) => el.timings.length > 0).length > 0 &&
      class_time.length > 0
    ) {
      setDisbaleContinue(false);
    } else if (!disbaleContinue) {
      setDisbaleContinue(true);
    }
    return () => {};
  }, [availability_time, disbaleContinue, class_time]);

  // on Continue
  const onContinue = () => {
    const data = {
      class_time,
      availability_active: {
        ...availability_active,
        until: showEndDate ? availability_active.until : null,
      },
      availability_time,
      book_class,
      buffer_and_time_setting,
    };
    setFormState({ ...formState, schedule: data });
    setActiveTab("Pricing");
  };
  const delTimming = (name, index) => {
    const indexToUpdate = availability_time.findIndex(
      (todo) => todo.name === name
    );
    const updatedTodos = [...availability_time];
    updatedTodos[indexToUpdate].timings = updatedTodos[
      indexToUpdate
    ].timings.filter((x, i) => i !== index);
    setAvailability_time(updatedTodos);
  };
  const getOnlyTime = (date) => {
    var d = new Date(date);
    const min = d.getMinutes();
    const min_r = min < 10 ? "0" + min : min;
    return d.getHours() + ":" + min_r;
  };
  const editTime = (name, index) => {
    const indexToUpdate = availability_time.findIndex(
      (todo) => todo.name === name
    );
    const result = availability_time[indexToUpdate].timings.filter(
      (x, i) => i == index
    );
    setStartTime(getOnlyTime(result[0].start_time));
    setEndTime(getOnlyTime(result[0].end_time));
    setIsEditTime({ is: true, name: name, index: index });
    setShowAvailableTime(true);
  };
  // main return
  return (
    <div className="profileScehdule">
      <h1 className="title mt-3">Availability</h1>
      <p className="des">
        Please add schedule when you are available for tutoring{" "}
        <div className="toolTip">
          <img className="ml-2" src={"/assets/image/info.svg"} alt="icon" />
          <span className="tooltiptext">
            You can select more than one classtime.
          </span>
        </div>
      </p>
      <h1 className="subtitle mt-4">How long should each class be?</h1>
      <section className="flexCenter pt-2">
        {class_duration_options.map((item, index) => {
          const isActive = class_time.includes(item.value);
          return (
            <div
              key={index}
              className={isActive ? "item active" : "item"}
              onClick={() =>
                isActive
                  ? setClass_duration((prev) =>
                      prev.filter((el) => el != item.value)
                    )
                  : setClass_duration((prev) => [...prev, item.value])
              }
            >
              {item.text}
            </div>
          );
        })}
        {!showCustom ? (
          <div className="item green" onClick={() => setShowCustom(true)}>
            Custom
          </div>
        ) : (
          <form onSubmit={onCustomDuration} style={{flex:1}}>
            <input
              className="textInput"
              type="number"
              placeholder="enter meeting time in mins"
              value={customDurationInput}
              onChange={(e) => setCustomDurationInput(e.target.value)}
            />
          </form>
        )}
      </section>
      <section>
        <div style={{ display: "flex" }}>
          <h1 className="subtitle mt-4">When is this availability active?</h1>
          <div className="toolTip des">
            <img
              className="ml-3 mt-4"
              src={"/assets/image/info.svg"}
              alt="icon"
            />
            <span className="tooltiptext">
              The availability time you chose will be repeated automatically if
              an until date is not selected.
            </span>
          </div>
        </div>
        <div className="flexCenter pt-2">
          <span> from </span>{" "}
          <div className="dateInput">
            <input
              type="date"
              className="item ml-2  mb-md-0"
              style={{ maxWidth: "150px" }}
              value={formatDate(availability_active.from)}
              onChange={(e) =>
                setAvailability_active((prev) => {
                  return { ...prev, from: e.target.value };
                })
              }
            />
          </div>
          <span>Until</span>{" "}
          <div className="dateInput">
            {!showEndDate ? (
              <div className="item ml-2 mb-md-0" style={{ color: "#C8C8C8" }}>
                No end date
              </div>
            ) : (
              <input
                type="date"
                className="item ml-2  mb-md-0"
                style={{ maxWidth: "150px" }}
                value={formatDate(
                  availability_active.until
                    ? availability_active.until
                    : Date.now()
                )}
                onChange={(e) =>
                  setAvailability_active((prev) => {
                    return { ...prev, until: e.target.value };
                  })
                }
              />
            )}
          </div>
          <div
            onClick={() => setShowEndDate((prev) => !prev)}
            className="textPrimary poppinsSb pointer ml-2"
          >
            {showEndDate ? "no end date" : "change date"}
          </div>
        </div>
      </section>
      <section>
        <div style={{ display: "flex" }}>
          <h1 className="subtitle mt-4">
            At which time are you available for classes?
          </h1>
          <div className="toolTip des">
            <img
              className="ml-3 mt-4"
              src={"/assets/image/info.svg"}
              alt="icon"
            />
            <span className="tooltiptext">
              You can add more than one time slot in a day.
            </span>
          </div>
        </div>
        <div className="flexCenter pt-2">
          {classAvailbilityInit.map((item, index) => {
            return (
              <div key={index}>
                <h1 className="subtitle poppins text-center mb-2 text-capitalize">
                  {item.name}
                </h1>
                {item.timings.length > 0 ? (
                  <div className="item">
                    <div>
                      {item.timings.map((timing, index) => {
                        return (
                          <div className="d-flex align-items-center">
                            <div
                              className="mr-2"
                              onClick={() => setShowAvailableTime(item.name)}
                            >
                              {`${formatDateFN(
                                timing.start_time,
                                "p"
                              )} > ${formatDateFN(timing.end_time, "p")}`}
                            </div>
                            <Pencil
                              color="#007bff"
                              type="button"
                              className="mr-2"
                              onClick={() => editTime(item.name, index)}
                              size={17}
                            />
                            <Trash
                              color="#dc3545"
                              onClick={() => delTimming(item.name, index)}
                              size={17}
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div
                    onClick={() => setShowAvailableTime(item.name)}
                    className="item green"
                  >
                    + Add available time
                  </div>
                )}
              </div>
            );
          })}
        </div>
        <Modal
          isOpen={showAvailableTime === false ? false : true}
          toggle={toggleModal}
          onClosed={() => {
            setEndTime("");
            setStartTime("");
            setIsEditTime(false);
          }}
        >
          <ModalHeader toggle={toggleModal}>
            Add <b className="text-capitalize">{showAvailableTime}</b> timings
          </ModalHeader>
          <ModalBody>
            <label> Start Time </label>
            <input
              type="time"
              className="textInput pr-2 mb-2"
              onChange={(e) => setStartTime(e.target.value)}
              value={startTime}
            ></input>
            <label> End Time </label>
            <input
              type="time"
              className="textInput pr-2"
              onChange={(e) => setEndTime(e.target.value)}
              value={endTime}
            ></input>
          </ModalBody>
          <ModalFooter>
            <Button color="primary primaryButton mt-0" onClick={addTimmings}>
              Add Timming
            </Button>
            <Button color="primaryButton" outline onClick={toggleModal}>
              Cancel
            </Button>
          </ModalFooter>
        </Modal>
      </section>
      {/* <section>
        <h1 className="subtitle mt-4">
          Select all where the class can be booked
        </h1>
        <div className="flexCenter pt-2">
          {bookClassOptions.map((item, index) => {
            const isActive = book_class.includes(item.value);
            return (
              <div
                key={index}
                className={isActive ? "item active" : "item"}
                onClick={() => addBookClass(item.value, isActive)}
              >
                {item.name}
              </div>
            );
          })}
        </div>
      </section> */}
      <section>
        <h1 className="subtitle mt-4 mb-2">Buffer and time settings</h1>
        <div className="flexBetweenCenter mb-2" style={{ maxWidth: "920px" }}>
          <div className="flexCenter">
            <span>Buffer time before class</span>{" "}
            <select
              className="item mb-0 ml-2"
              style={{
                maxWidth: "200px",
                backgroundColor: "transparent",
              }}
              onChange={(e) =>
                setBuffer_and_time_setting((prev) => {
                  return { ...prev, before_class: e.target.value };
                })
              }
              value={buffer_and_time_setting.before_class}
            >
              {bufferTimeOptions.map((item, index) => {
                return (
                  <option key={index} value={item.value}>
                    {item.text}
                  </option>
                );
              })}
            </select>
          </div>
          <div className="flexCenter">
            <span>Buffer time after class</span>{" "}
            <select
              className="item mb-0 ml-2"
              style={{
                maxWidth: "200px",
                backgroundColor: "transparent",
              }}
              onChange={(e) =>
                setBuffer_and_time_setting((prev) => {
                  return { ...prev, after_class: e.target.value };
                })
              }
              value={buffer_and_time_setting.after_class}
            >
              {bufferTimeOptions.map((item, index) => {
                return (
                  <option key={index} value={item.value}>
                    {item.text}
                  </option>
                );
              })}
            </select>
          </div>
        </div>
        <div className="flexCenter mb-2">
          <span>The shortest notice to book a class</span>{" "}
          <select
            className="item mb-0 ml-2"
            style={{
              maxWidth: "200px",
              backgroundColor: "transparent",
            }}
            onChange={(e) =>
              setBuffer_and_time_setting((prev) => {
                return { ...prev, short_notice: e.target.value };
              })
            }
            value={buffer_and_time_setting.short_notice}
          >
            {shortNoticeOptions.map((item, index) => {
              return (
                <option key={index} value={item.value}>
                  {item.text}
                </option>
              );
            })}
          </select>
        </div>
        <div className="flexCenter mb-2">
          <span>How far in the future can someone book a class</span>{" "}
          <select
            className="item mb-0 ml-2"
            style={{
              maxWidth: "200px",
              backgroundColor: "transparent",
            }}
            onChange={(e) =>
              setBuffer_and_time_setting((prev) => {
                return { ...prev, future_book: e.target.value };
              })
            }
            value={buffer_and_time_setting.future_book}
          >
            {futureBookOptions.map((item, index) => {
              return (
                <option key={index} value={item.value}>
                  {item.text}
                </option>
              );
            })}
          </select>
        </div>
      </section>
      <div className="centerFlex mt-5 mb-5">
        <div className="flexCenter">
          {!is_update?
          <button
            onClick={() => setActiveTab("Gallery")}
            className="prevBtn mx-auto mr-md-5"
          >
            Previous
          </button>
          :null}
          <button
            className="primaryButton mt-0"
            disabled={disbaleContinue}
            style={{ maxWidth: "388px", width: "300px" }}
            onClick={onContinue}
          >
            {!is_update?"Continue":"Update"}
          </button>
        </div>
      </div>
    </div>
  );
}
