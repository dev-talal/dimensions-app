import React, { Component } from "react";
import queryString from "query-string";
import axios from "axios";
import { Spinner } from "react-bootstrap";
import { Link } from "react-router-dom";
import API from "../../../config/AxiosBase";
import { booking__payment } from "../../../views/web/search/constant";
import Swal from "sweetalert2";
import AxiosBase from "../../../config/AxiosBase";
const successPattern = /^(000\.000\.|000\.100\.1|000\.[36])/;
const manuallPattern = /^(000\.400\.0[^3]|000\.400\.100)/;
const ClassBook = async (postData) => {
  try {
    await AxiosBase.put(
      `/tutor/update-schedule/${postData.data_user_id}`,
      postData
    );
    localStorage.removeItem(booking__payment);
  } catch (error) {
    console.log(error);
  }
}
const ClassBookMobile = async (postData,t__) => {
    const ax = axios.create({
      baseURL: `${process.env.REACT_APP_BASE_URL}`,
      responseType: "json"
    });
    ax.defaults.headers.common["x-access-token"] = t__;
    try {
      await ax.put(
        `/tutor/update-schedule/${postData.data_user_id}`,
        postData
      );
    } catch (error) {
      const {response} = error
      Swal.fire({
        text:"Payment failed try again 1.",
        icon:"error"
      })
    }
}
class ResultPage extends Component {
  state = {
    responseData: null,
    mobileData:null,
    loading: true
  };
  async componentDidMount() {
    // const resourcePath = this.props.match.params.resourcePath
    const parsed = queryString.parse(this.props.location.search);
    const resourcePath = parsed.resourcePath;
    const mobileData = parsed.mobileData;
    if(mobileData){
      let t__ = mobileData;
      const ax = axios.create({
        baseURL: `${process.env.REACT_APP_BASE_URL}`,
        responseType: "json"
      });
      ax.defaults.headers.common["x-access-token"] = t__;
      try{
        const res = await ax.get(`/dummy`);
        this.setState({
          mobileData: JSON.parse(res.data.data),
          loading: true
        });
      }catch(error){
        Swal.fire({
          text:"Payment failed try again",
          icon:"error"
        })
      }
    }
    await axios
      .post(
        `${process.env.REACT_APP_BASE_URL}/payment/checkout-result`,
        { resourcePath }
      )
      .then(async res => {
        const match1 = successPattern.test(res.data.result.code);
        const match2 = manuallPattern.test(res.data.result.code);
        if (match1 || match2) {
          if(!mobileData){
            const dataClass = JSON.parse(localStorage.getItem(booking__payment));
            await ClassBook(dataClass);
          }else{
            await ClassBookMobile(this.state.mobileData,mobileData);
          }
        }
        this.setState({
          responseData: res.data,
          loading: false
        });
      });
    }
  checkResult = () => {
    const match1 = successPattern.test(this.state.responseData.result.code);
    const match2 = manuallPattern.test(this.state.responseData.result.code);
    if (match1 || match2) {
      return (
        <div className="component payment px-4 text-center mb-4 pb-5">
          <h3 className="text-center mb-0" style={{fontSize:"20px",fontWeight: 700}}>
            <img src="/assets/image/success.gif" className="mb-5 img-fluid" alt="Success Payment" /><br />
            {this.state.responseData.result.description}
          </h3>
          <div className="text-center mt-5">
            <Link to="/" className="signup primaryButton">
              Back to home
            </Link>
          </div>
        </div>
      );
    } 
    else {
      return (
        <div className="component payment px-4 text-center mb-4 pb-5">
          <h3 className="text-center mb-0" style={{fontSize:"20px",fontWeight: 700}}>
            <img src="/assets/image/failed-payment.png" className="mb-5 img-fluid" alt="Success Payment" /><br />
            {this.state.responseData.result.description}
          </h3>
          <div className="text-center mt-5">
            <Link to="/" className="signup primaryButton">
              Back to home
            </Link>
          </div>
        </div>
      );
    }
  };
  render() {
    if (!this.state.loading) {
      return (
        <div className="component px-4 text-center mb-4">
          {this.checkResult()}
        </div>
      );
    } else {
      return (
        <div className="component px-4 text-center my-5 pb-4">
          <Spinner
            as="span"
            animation="grow"
            size="md"
            role="status"
            aria-hidden="true"
          />
          <br />
          <br />
          <h5 style={{ fontWeight: "bold" }}>Payment Processing...</h5>
        </div>
      );
    }
  }
}

export default ResultPage;
