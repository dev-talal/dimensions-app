import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { EUserType } from "../../../enums/user.enum";
import ChooseLocation from "./chooseLocation";
import ChooseStudent from "./chooseStudent"; // payment imports
import PaymentConfirmation from "./paymentConfirmation";
import { useHistory } from "react-router-dom";
import { booking__payment } from "../../../views/web/search/constant";
export default function Booking({
  handleModal,
  data,
  selectedPackage,
  slotId,
  slotTime
}) {
  // state
  const [step, setStep] = useState(1);
  const [selectedLearners, setSelectedLearners] = useState([]);
  const [classLocation, setClassLocation] = useState(null);
  const { user } = useSelector((state) => state.auth);
  const history = useHistory();
  useEffect(() => {
    if (user?.user_type === EUserType.INDIVIDUAL) {
      setStep(2);
    }
    return () => {};
  }, []);

  //  hanldeBooking
  const postData = {
    data_user_id:data.user_id._id,
    soltId: slotId,
    start_time:slotTime.start_time,
    end_time:slotTime.end_time,
    class_name:`${data.user_id?.first_name} ${data.user_id?.last_name} class-${Math.floor(100000 + Math.random() * 900000)}`,
    kids:
    user?.user_type === "individual"
    ? [user?._id]
    : selectedLearners.reduce((acc, curr) => {
      return [...acc, curr._id];
    }, []),
    user_type: user?.user_type,
    class_location: classLocation,
    selected_pkg: selectedPackage.time,
    no_of_booking: 1,
    total_price: selectedPackage.time * (selectedLearners.length || 1),
  };
  useEffect(() => {
    localStorage.setItem(booking__payment,JSON.stringify(postData));
  },[postData])
  const renderCompoennt = () => {
    switch (step) {
      case 1:
        return (
          <ChooseStudent
            selectedLearners={selectedLearners}
            setSelectedLearners={setSelectedLearners}
            setStep={setStep}
          />
        );
      case 2:
        return (
          <ChooseLocation
            data={data}
            setClassLocation={setClassLocation}
            setStep={setStep}
          />
        );
      case 3:
        return (
          <PaymentConfirmation
            price={selectedPackage}
            totalPrice={selectedPackage.time * (selectedLearners.length || 1)}
            slotId={slotId}
          />
        );
      default:
        return <ChooseStudent />;
    }
  };
  // main return
  return (
    <>
      <div className="bookingModal">
        <div className="innerModal">
          <div className="close">
            <img
              onClick={() => handleModal(false)}
              src="/assets/image/closeModal.svg"
              alt="close"
              className="pointer"
            />
          </div>
          {renderCompoennt()}
        </div>
      </div>
    </>
  );
}
