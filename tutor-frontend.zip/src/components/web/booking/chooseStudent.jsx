import React from "react";
import { useSelector } from "react-redux";
import { getImageUrl } from "../../../helpers";
import history from "../../../helpers/history";

export default function ChooseStudent({
  selectedLearners,
  setSelectedLearners,
  setStep,
}) {
  const { user } = useSelector((state) => state.auth);
  const { profile } = user;
  const kids = profile?.kids;
  const parentAsLearner = {
    first_name: user?.first_name,
    last_name: user?.last_name,
    _id: user?._id,
    parentAsLearner: true,
  };
  const parentActive =
    selectedLearners.filter((el) => el._id === user?._id).length > 0;

  // handle learner
  const handleLearner = (item, active) => {
    if (active) {
      setSelectedLearners((prev) => prev.filter((el) => el._id !== item._id));
    } else {
      setSelectedLearners((prev) => [...prev, item]);
    }
  };

  // main return
  return (
    <div>
      <h1>Choose student</h1>
      <p>Choose your child(ren) who is / are going to attend this lesson</p>
      <section  className="kidFlex">
        <div>Kid(s) / Student(s)</div>
        <div  className="flexCenter pt-0 mt-2">
          {kids?.length < 1 && (
            <div className="mb-4">
              <p> you dont have any kids to enroll </p>
              <button
                 className="primaryButton mt-2"
                onClick={() => history.push("/profile-setup/add-kids")}
              >
                + Add Kids
              </button>
            </div>
          )}
          {kids?.length > 0 &&
            kids?.map((item) => {
              const active =
                selectedLearners.filter((el) => el._id === item._id).length > 0;
              return (
                <div
                  key={item._id}
                  onClick={() => handleLearner(item, active)}
                   className={`flexCenter kid mr-0 mr-md-5`}
                >
                  <img
                    src={
                      item.profile_picture
                        ? getImageUrl(item.profile_picture)
                        : "/assets/image/defaultKidProfile.svg"
                    }
                    alt="profile"
                     className="profile"
                  />
                  <div
                     className="flexBetweenCenter w-100"
                    style={{ maxWidth: "210px" }}
                  >
                    <div>
                      <h3>
                        {item.first_name} {item.last_name}
                      </h3>
                      <p>{item.class_name}</p>
                    </div>
                    <img
                      src={
                        active
                          ? "/assets/image/kidCheckActive.svg"
                          : "/assets/image/kidCheck.svg"
                      }
                      alt="check"
                    />
                  </div>
                </div>
              );
            })}
        </div>
        <div>Parent</div>
        <div
          onClick={() => handleLearner(parentAsLearner, parentActive)}
           className="flexCenter kid mt-2"
        >
          <img
            src={
              user?.profile_picture
                ? getImageUrl(user?.profile_picture)
                : "/assets/image/defaultKidProfile.svg"
            }
            alt="profile"
             className="profile"
          />
          <div
             className="flexBetweenCenter w-100"
            style={{ maxWidth: "210px" }}
          >
            <div>
              <h3  className="mb-2">
                {user?.first_name} {user?.last_name}
              </h3>
            </div>
            <img
              src={
                parentActive
                  ? "/assets/image/kidCheckActive.svg"
                  : "/assets/image/kidCheck.svg"
              }
              alt="check"
            />
          </div>
        </div>
      </section>
      <div  className="centerFlex mt-3 mb-3">
        <button
          disabled={selectedLearners.length < 1}
           className="primaryButton green"
          style={{ width: "240px" }}
          onClick={() => setStep((prev) => prev + 1)}
        >
          Done
        </button>
      </div>
    </div>
  );
}
