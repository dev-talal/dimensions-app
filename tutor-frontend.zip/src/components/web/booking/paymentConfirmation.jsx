import React, { useState, useEffect } from "react";
import { headers } from "../../../helpers";
import AxiosBase from "../../../config/AxiosBase";
import Swal from "sweetalert2";
import { useSelector } from "react-redux";
import axios from "axios";
import { Spinner } from "react-bootstrap";
export default function PaymentConfirmation({ price, totalPrice }) {
  const { user } = useSelector((state) => state.auth);
  const [loading, setLoading] = useState(false);
  const [checkoutData, setCheckoutData] = useState({
    checkoutId: null,
    loading: true,
  });
  const options = {
    style: {
      base: {
        fontSize: "16px",
      },
      invalid: {
        color: "#9e2146",
        borderColor: "#9e2146",
      },
    },
  };
  const renderPaymentform = (id) => {
    const script = document.createElement("script");
    script.src = `https://test.oppwa.com/v1/paymentWidgets.js?checkoutId=${id}`;
    script.async = true;
    document.body.appendChild(script);
    const form = document.createElement("form");
    form.action = "/payment/result";
    form.setAttribute("class", "paymentWidgets");
    form.setAttribute("data-brands", "VISA MASTER MADA");
    document.getElementById("payment__form__card").appendChild(form);
  };
  useEffect(async () => {
    await axios
      .post(`${process.env.REACT_APP_BASE_URL}/payment/checkout`, {
        amount: JSON.stringify(totalPrice),
        email: user.email,
        user_name: `${user.first_name} ${user.last_name}`,
        user_id: user?._id || "",
      })
      .then((res) => {
        renderPaymentform(res.data.id);
        setCheckoutData({
          ...checkoutData,
          checkoutId: res.data.id,
          loading: false,
        });
      });
  }, []);
  return (
    <div>
      <h1>Payment confirmation</h1>
      <p>Please confirm the payment to finish booking the class.</p>

      <div className="kidFlex">
        <section>
          <div className="flexBetweenCenter">
            <div className="poppinsMd">Selected package </div>
            <div className="poppinsMd">${price.time}/hour</div>
          </div>
          <div className="flexBetweenCenter">
            <div className="poppinsMd">Number of classes booked </div>
            <div className="poppinsMd">1</div>
          </div>
        </section>
        <section className="price">
          <h1>${totalPrice ? JSON.stringify(totalPrice) : 0}</h1>
          <div className="poppinsMd text-center">Subtotal</div>
        </section>
      </div>
      <div id="payment__form__card"></div>
      {checkoutData.loading ? (
        <div className="text-center">
          <>
            <Spinner
              as="span"
              animation="grow"
              size="sm"
              role="status"
              aria-hidden="true"
            />
            <br />
            <br />
            Loading Payment Method...
          </>
        </div>
      ) : null}
      {/* <form className="paymentForm" onSubmit={submitHandler}>
        <div className="inputDiv">
          <label>Card Number</label>
          <CardNumberElement
            type="text"
            id="card_num_field"
            className="textInput"
            options={options}
          />
        </div>
        <div className="inputDiv">
          <label>Expiry</label>
          <CardExpiryElement
            type="text"
            id="card_exp_field"
            className="textInput"
            options={options}
          />
        </div>
        <div className="inputDiv">
          <label>Security Code</label>
          <CardCvcElement
            type="text"
            id="card_cvc_field"
            className="textInput"
            options={options}
          />
        </div>

        <div>
          <div className="centerFlex mx-3">
            <button
              className="primaryButton green"
              disabled={loading}
              type="submit"
              style={{ width: "240px" }}
            >
              {loading ? "Please Wait..." : " Confirm & pay"}
            </button>
          </div>
        </div>
      </form> */}
    </div>
  );
}
