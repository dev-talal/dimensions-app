import React from "react";
import { ETeach_Type } from "../../../enums/tutor";

export default function chooseLocation({ data, setStep, setClassLocation }) {
  const handleLocation = (value) => {
    setStep((prev) => prev + 1);
    setClassLocation(value);
  };

  // locations
  const locations = [
    {
      name: "Online class",
      value: ETeach_Type.ONLINE,
      show: data?.schedule?.book_class.includes(ETeach_Type.ONLINE),
    },
    {
      name: "At tutor’s home",
      value: ETeach_Type.TUTOR_HOME,
      show: data?.schedule?.book_class.includes(ETeach_Type.TUTOR_HOME),
    },
    {
      name: "At your home",
      value: ETeach_Type.STUDENT_HOME,
      show: data?.schedule?.book_class.includes(ETeach_Type.STUDENT_HOME),
    },
  ];

  // main return
  return (
    <div>
      <h1>Choose class location</h1>
      <p>Choose a venue for the class from these available</p>

      <section  className=" my-4">
        <div>
          {locations.map((item, index) => {
            return item.show ? (
              <div
                key={index}
                onClick={() => handleLocation(item.value)}
                 className="location"
              >
                <div  className="bg">
                  <img
                    src="/assets/image/tcard1.svg"
                    alt="svg"
                     className="icon"
                  />
                </div>
                <span>{item.name}</span>
              </div>
            ) : null;
          })}
        </div>
      </section>
    </div>
  );
}
