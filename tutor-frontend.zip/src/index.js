import React from "react";
import ReactDOM from "react-dom";
import reduxStore from "./redux/store";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import "bootstrap/dist/css/bootstrap.min.css";
import App from "./App";
import { Router } from "react-router-dom";
import history from "./helpers/history";
import { QueryClient, QueryClientProvider } from "react-query";
import { ReactQueryDevtools } from "react-query/devtools";
import "./index.css";
// Create a  query client
const queryClient = new QueryClient();
queryClient.setDefaultOptions({
  refetchOnWindowFocus: false,
  refetchOnReconnect: false,
  retry: false,
  staleTime: 1000 * 6,
});
// Rendring React App
ReactDOM.render(
  <Provider store={reduxStore.store}>
    <PersistGate loading={null} persistor={reduxStore.persistor}>
      <QueryClientProvider client={queryClient}>
        <Router history={history}>
          <App />
        </Router>
        {/* <ReactQueryDevtools initialIsOpen={false} /> */}
      </QueryClientProvider>
    </PersistGate>
  </Provider>,
  document.getElementById("root")
);
