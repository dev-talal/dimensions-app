import React, { useRef, useState } from "react";
import { Col, Row } from "reactstrap";
import { Formik, Form, Field } from "formik";
import { SelectInput, TextInput } from "../../../components/basic/RenderInputs";
import history from "../../../helpers/history";
import "./addKids.css";
import { buildFormData, getImageUrl } from "../../../helpers";
import { useQuery } from "react-query";
import {
  addKidApi,
  deleteKidApi,
  getAllKids,
  updateKidApi,
} from "../../../api";
import useNewItemMutation from "../../../helpers/hooks/mutations/useNewItemMutation";
import { KidsFormValidationSchema } from "../../../helpers/validations";
import { logout } from "../../../redux/actions/authActions";
import { useDispatch } from "react-redux";
import useFilterItem from "../../../helpers/hooks/mutations/useFilterItem";
import useUpdateQueryItem from "../../../helpers/hooks/mutations/useUpdateQueryItem";

// add kids
export default function AddKids() {
  // state
  const [fileError, setFileError] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [editData, setEditData] = useState(null);
  // profileInputRef
  const profileInputRef = useRef(null);
  // dispatch
  const dispatch = useDispatch();
  // trigger file input
  const triggerInput = () => {
    profileInputRef.current.click();
  };
  // gender options
  const genderOptions = [
    { value: "male", text: "Male" },
    { value: "female", text: "Female" },
  ];
  const EducationalOptions = [
    {value:"American Diploma",text: "American Diploma"},
    {value:"IGSCE",text: "IGSCE"},
    {value:"IB",text: "IB"},
    {value:"Other",text: "Other"}
  ]
  const GradeOptions = [
    // {value:"1",text: "1"},
    // {value:"2",text: "2"},
    // {value:"3",text: "3"},
    // {value:"4",text: "4"},
    // {value:"5",text: "5"},
    // {value:"6",text: "6"},
    // {value:"7",text: "7"},
    // {value:"8",text: "8"},
    // {value:"9",text: "9"},
    // {value:"10",text: "10"},
    // {value:"11",text: "11"},
    // {value:"12",text: "12"}
    {value: "pre", text: "Pre"},
    {value: "montessori", text: "Montessori"},
    {value: "k.g", text: "K.G"},
  ]
  // setting form inital values
  const formInitialValues = editData
    ? {
        first_name: editData.first_name,
        last_name: editData.last_name,
        age: editData.age,
        class_name: editData.class_name,
        gender: editData.gender,
        grade: editData.grade,
        educational: editData.educational,
      }
    : {
        first_name: "",
        last_name: "",
        age: "",
        class_name: "",
        gender: "",
        educational: "",
        grade: ""
      };

  // fetching all kids
  const { data, isLoading } = useQuery("kids", getAllKids);
  const allKids = data?.data?.kids || [];

  // add kid mutation
  const addKidFun = useNewItemMutation("kids", addKidApi, true, "kids");
  const deleteKidFun = useFilterItem("kids", deleteKidApi, "kids");
  const upateKidFun = useUpdateQueryItem("kids", updateKidApi, true, "kids");

  // on Profile Change
  const onProfileChange = (e) => {
    if (e.target.files.length > 0) {
      setFileError((prev) => (prev ? null : prev));
      setFilePreview(URL.createObjectURL(e.target.files[0]));
    } else return;
  };
  const signUpIndividual = () => {
    dispatch(logout());
    history.push("/sign-up/parent?role=individual");
  };

  // on Submit
  const handleSubmit = (postData, formikHelpers) => {
    const isFileAvailable = profileInputRef.current.files.length > 0;
    console.log({ postData, isFileAvailable });
    if (!isFileAvailable && !editData) {
      setFileError("Please upload kid profile");
      return;
    }
    console.log("woking good", postData);

    const formData = new FormData();
    buildFormData(formData, postData);
    if (isFileAvailable) {
      formData.append("image", profileInputRef.current.files[0]);
    }
    editData !== null
      ? upateKidFun.mutate({ id: editData?._id, data: postData, formData })
      : addKidFun.mutate({ data: postData, formData });

    // reseting values
    formikHelpers.resetForm();
    isFileAvailable && setFilePreview(null);
    editData && setEditData(null);
    profileInputRef.current.value = "";
  };

  console.log({ fileError, profileInputRef, editData, filePreview });
  // main return
  return (
    <main  className="setupKids ">
      <section  className="sideSec d-none d-md-flex">
        <img
          src="/assets/image/setupKidsUp.svg"
          alt="books"
           className="upSide"
        ></img>
        <img
          src="/assets/image/setupKidsDown.svg"
          alt="books"
           className="downSide"
        ></img>
      </section>
      <section  className="contentSec">
        <h1>Add Kids</h1>
        <h3>
          Add your kids as students. You can also add them later in settings.
        </h3>
        <div  className="flexCenter tagWrapper">
          {isLoading || allKids.length > 0 ? (
            allKids.map((item) => {
              return (
                <div key={item?._id}  className="tag">
                  <span>{`${item.first_name} ${item.last_name}`}</span>
                  <img
                    src="/assets/image/editKidIcon.svg"
                    alt="icon"
                     className="pointer mx-2"
                    onClick={() => setEditData(item)}
                  />
                  <img
                    src="/assets/image/deleteKidIcon.svg"
                    alt="icon"
                     className="pointer"
                    onClick={() => deleteKidFun.mutate(item?._id)}
                  />
                </div>
              );
            })
          ) : (
            <div  className="tag">No student added yet</div>
          )}
        </div>
        <div  className="profile">
          <img
            src={
              filePreview
                ? filePreview
                : editData?.profile_picture
                ? getImageUrl(editData?.profile_picture)
                : "/assets/image/defaultKidProfile.svg"
            }
            alt="profile"
          ></img>
          <div>
            <span onClick={triggerInput}  className="pointer">
              Upload profile picture
            </span>
            {fileError && <div  className="errorText">{fileError} </div>}{" "}
          </div>
          <input
            ref={profileInputRef}
            onChange={onProfileChange}
            type="file"
             className="d-none"
          />
        </div>

        <Formik
          initialValues={formInitialValues}
          enableReinitialize
          validationSchema={KidsFormValidationSchema}
          onSubmit={handleSubmit}
        >
          <Form  className="mt-4">
            <div  className="container-fluid">
              <Row>
                <Col md="6">
                  <Field
                    name="first_name"
                    component={TextInput}
                    placeholder="Enter first name of student"
                    label="First name"
                  />
                </Col>

                <Col md="6">
                  <Field
                    name="last_name"
                    component={TextInput}
                    placeholder="Enter last name of student"
                    label="Last name"
                  />
                </Col>
              </Row>
              <Row>
                <Col md="6">
                  <Field
                    name="age"
                    type="number"
                    component={TextInput}
                    placeholder="Enter age of student"
                    label="Age"
                  />
                </Col>

                <Col md="6">
                  <Field
                    name="gender"
                    component={SelectInput}
                    placeholder="Select gender"
                    options={genderOptions}
                    label="Gender"
                    type="select"
                  />
                </Col>
              </Row>
              <Row>
                <Col md="12">
                  <Field
                    name="class_name"
                    component={TextInput}
                    placeholder="Enter class being attended by student (e.g. Montessori)"
                    label="Class"
                    topclass="ml-2"
                  />
                </Col>
                <Col md="6">
                  <Field
                    name="educational"
                    component={SelectInput}
                    placeholder="Select system"
                    options={EducationalOptions}
                    label="Educational System (Optional)"
                    type="select"
                  />
                </Col>
                <Col md="6">
                  <Field
                    name="grade"
                    component={SelectInput}
                    placeholder="Select Grade"
                    options={GradeOptions}
                    label="Grade (Optional)"
                    type="select"
                  />
                </Col>
              </Row>

              <div  className="flexBetweenCenter buttonSec mt-4">
                <div  className="mb-2">
                  Not a parent?{" "}
                  <span
                     className="poppinsSb textPrimary pointer"
                    onClick={signUpIndividual}
                  >
                    Sign up as an individual.
                  </span>
                </div>
                <div  className="subBtn">
                  <button
                    onClick={() => history.push("/dashboard")}
                    type="button"
                     className="outlineButton mr-2 mt-0 mb-2"
                  >
                    Continue
                  </button>
                  <button type="submit"  className="primaryButton mt-0 mb-2">
                    {editData ? "Update" : "Add"}
                  </button>
                </div>
              </div>
            </div>
          </Form>
        </Formik>
      </section>
    </main>
  );
}
