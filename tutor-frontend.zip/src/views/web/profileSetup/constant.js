export const initEducationObj = {
  name_of_institution: "",
  degree_title: "",
  country: "",
  city: "",
  completion_year: "",
  currently_enrolled: false,
};
export const initExperinceObj = {
  teaching_place: "",
  from_year: null,
  to_year: null,
  short_description: "",
  currently_working_here: false,
};
export const studentAgeObj = { from_age: "", to_age: "" };
export const initFormState = {
  intro: "",
  about_you: "",
  // first_name: "",
  // last_name: "",
  // email: "",
  // location: "",
  // phone_number: "",
  education: [],
  experience: [],
  teach_language: [],
  teach_type: "",
  main_field: "",
  you_teach: [],
  level_you_teach: [],
  student_age_you_teach: [],
  class_type: [],
  certificates: [],
  iqma: null,
  gallery: [],
  schedule: {
    class_time: [15],
    availability_active: {
      from: Date.now(),
      until: null,
    },
    availability_time: [],
    book_class: ["online"],
    buffer_and_time_setting: {
      before_class: 15,
      after_class: 15,
      short_notice: 60,
      future_book: 7,
    },
  },
  pricing: {
    four_class_rate: "",
    eight_class_rate: "",
    twelve_class_rate: "",
    offer_demo: false,
  },

  // bank_info: {
  //   SWIFT_code: "",
  //   bank_namer: "",
  //   IBAN_number: "",
  //   branch_name: "",
  //   branch_address: "",
  //   branch_account_type: "",
  // },
};

export const countryOptions = [{ text: "Turkey", value: "turkey" }];

export const yearOptions = [
  { value: 2022, text: "2022" },
  { value: 2021, text: "2021" },
  { value: 2020, text: "2020" },
  { value: 2019, text: "2019" },
  { value: 2018, text: "2018" },
  { value: 2017, text: "2017" },
  { value: 2016, text: "2016" },
  { value: 2015, text: "2015" },
  { value: 2014, text: "2014" },
  { value: 2013, text: "2013" },
  { value: 2012, text: "2012" },
  { value: 2011, text: "2011" },
  { value: 2010, text: "2010" },
  { value: 2009, text: "2009" },
  { value: 2008, text: "2008" },
  { value: 2007, text: "2007" },
  { value: 2006, text: "2006" },
  { value: 2005, text: "2005" },
  { value: 2004, text: "2004" },
  { value: 2003, text: "2003" },
  { value: 2002, text: "2002" },
  { value: 2001, text: "2001" },
  { value: 2000, text: "2000" },
  { value: 1999, text: "1999" },
  { value: 1998, text: "1998" },
  { value: 1997, text: "1997" },
  { value: 1996, text: "1996" },
  { value: 1995, text: "1995" },
  { value: 1994, text: "1994" },
  { value: 1993, text: "1993" },
  { value: 1992, text: "1992" },
  { value: 1991, text: "1991" },
  { value: 1990, text: "1990" },
  { value: 1989, text: "1989" },
  { value: 1988, text: "1988" },
  { value: 1987, text: "1987" },
  { value: 1986, text: "1986" },
  { value: 1985, text: "1985" },
  { value: 1984, text: "1984" },
  { value: 1983, text: "1983" },
  { value: 1982, text: "1982" },
  { value: 1981, text: "1981" },
  { value: 1980, text: "1980" },
  { value: 1979, text: "1979" },
  { value: 1978, text: "1978" },
  { value: 1977, text: "1977" },
  { value: 1976, text: "1976" },
  { value: 1975, text: "1975" },
  { value: 1974, text: "1974" },
  { value: 1973, text: "1973" },
  { value: 1972, text: "1972" },
  { value: 1971, text: "1971" },
  { value: 1970, text: "1970" },
  { value: 1969, text: "1969" },
  { value: 1968, text: "1968" },
  { value: 1967, text: "1967" },
  { value: 1966, text: "1966" },
  { value: 1965, text: "1965" },
  { value: 1964, text: "1964" },
  { value: 1963, text: "1963" },
  { value: 1962, text: "1962" },
  { value: 1961, text: "1961" },
  { value: 1960, text: "1960" },
  { value: 1959, text: "1959" },
  { value: 1958, text: "1958" },
  { value: 1957, text: "1957" },
  { value: 1956, text: "1956" },
  { value: 1955, text: "1955" },
  { value: 1954, text: "1954" },
  { value: 1953, text: "1953" },
  { value: 1952, text: "1952" },
  { value: 1951, text: "1951" },
  { value: 1950, text: "1950" },
  { value: 1949, text: "1949" },
  { value: 1948, text: "1948" },
  { value: 1947, text: "1947" },
  { value: 1946, text: "1946" },
  { value: 1945, text: "1945" },
  { value: 1944, text: "1944" },
  { value: 1943, text: "1943" },
  { value: 1942, text: "1942" },
  { value: 1941, text: "1941" },
  { value: 1940, text: "1940" },
];

export const languageOptions = [
  {
    value: "English",
    text: "English",
  },
  {
    value: "Turkish",
    text: "Turkish",
  },
  {
    value: "Urdu",
    text: "Urdu",
  },
];

export const whereTeachOptions = [
  {
    img: "/assets/image/online_teach.svg",
    name: "Online class",
    value: "online",
  },
  {
    img: "/assets/image/teacher_home_teach.svg",
    name: "At tutor’s home",
    value: "tutor_home",
  },
  {
    img: "/assets/image/student_home_teach.svg",
    name: "At student’s home",
    value: "student_home",
  },
];
export const classTypeOptions = [
  {
    name: "1 -1 class",
    value: "class",
  },
  // {
  //   name: "Group class",
  //   value: "group_class",
  // },
];

export const mainFieldOptions = [
  { value: "Computer Science", text: "Computer Science" },
  { value: "Biology", text: "Biology" },
  { value: "English", text: "English" },
];

export const levelTeachOptions = [
  { value: "Beginner", text: "Beginner" },
  { value: "Intermediate", text: "Intermediate" },
  { value: "Advanced", text: "Advanced" },
];

export const ageOptions = [
  { value: 4, text: "4 Years" },
  { value: 5, text: "5 Years" },
  { value: 6, text: "6 Years" },
  { value: 7, text: "7 Years" },
  { value: 8, text: "8 Years" },
  { value: 9, text: "9 Years" },
  { value: 10, text: "10 Years" },
  { value: 11, text: "11 Years" },
  { value: 12, text: "12 Years" },
  { value: 13, text: "13 Years" },
  { value: 14, text: "14 Years" },
  { value: 15, text: "15 Years" },
  { value: 16, text: "16 Years" },
  { value: 17, text: "17 Years" },
  { value: 18, text: "18 Years" },
  { value: 19, text: "19 Years" },
  { value: 20, text: "20+ Years" },
];

export const galleryInit = [
  { id: 1, image: null, imageObj: null },
  { id: 2, image: null, imageObj: null },
  { id: 3, image: null, imageObj: null },
  { id: 4, image: null, imageObj: null },
  { id: 5, image: null, imageObj: null },
  { id: 6, image: null, imageObj: null },
  { id: 7, image: null, imageObj: null },
  { id: 8, image: null, imageObj: null },
  { id: 9, image: null, imageObj: null },
  { id: 10, image: null, imageObj: null },
];

export const classDurationOption = [
  { value: 15, text: "15 min" },
  { value: 30, text: "30 min" },
  { value: 45, text: "45 min" },
  { value: 60, text: "60 min" },
  { value: 90, text: "1.5 hour" },
  { value: 120, text: "2 hour" },
];

export const classAvailbilityInit = [
  { name: "sunday", timings: [] },
  { name: "monday", timings: [] },
  { name: "tuesday", timings: [] },
  { name: "wednesday", timings: [] },
  { name: "thursday", timings: [] },
  { name: "friday", timings: [] },
  { name: "saturday", timings: [] },
];

export const bookClassOptions = [
  {
    name: "Online class",
    value: "online",
  },
  {
    name: "Tutor’s home",
    value: "tutor_home",
  },
  {
    name: "Student’s home",
    value: "student_home",
  },
];

export const bufferTimeOptions = [
  { value: 15, text: "15 min" },
  { value: 30, text: "30 min" },
  { value: 45, text: "45 min" },
  { value: 60, text: "1 hour" },
];
export const shortNoticeOptions = [
  { value: 30, text: "30 min" },
  { value: 60, text: "1 hour" },
  { value: 120, text: "2 hour" },
  { value: 180, text: "3 hour" },
  { value: 240, text: "4 hour" },
  { value: 300, text: "5 hour" },
];
export const futureBookOptions = [
  { value: 7, text: "1 week" },
  { value: 14, text: "2 weeks" },
  { value: 21, text: "3 weeks" },
  { value: 30, text: "1 month" },
  { value: 60, text: "2 month" },
  { value: 90, text: "3 month" },
];
