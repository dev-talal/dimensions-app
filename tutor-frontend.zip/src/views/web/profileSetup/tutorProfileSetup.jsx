import React, { useEffect, useState } from "react";
import "./tutorProfileSetup.css";
import About from "../../../components/web/profileSetup/About";
import Highlights from "../../../components/web/profileSetup/Highlights";
import Gallery from "../../../components/web/profileSetup/Gallery";
import Schedule from "../../../components/web/profileSetup/Scehdule";
import Pricing from "../../../components/web/profileSetup/Pricing";
import { initFormState } from "./constant";
import { buildFormData, headers } from "../../../helpers";
import AxiosBase from "../../../config/AxiosBase";
import Swal from "sweetalert2";
import history from "../../../helpers/history";
export default function TutorProfileSetup() {
  // state
  const navTabs = [
    { name: "About", Component: About },
    { name: "Highlights", Component: Highlights },
    { name: "Gallery", Component: Gallery },
    { name: "Schedule", Component: Schedule },
    { name: "Pricing", Component: Pricing },
  ];
  const [activeTab, setActiveTab] = useState("About");
  const [activeState, setActiveState] = useState(navTabs.findIndex((x) => x.name=='activeTab'));
  const [formState, setFormState] = useState(initFormState);

  // reseting scroll
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    const activeIndex = navTabs.findIndex((x) => x.name==activeTab)
    setActiveState(activeState < activeIndex? activeIndex : activeState);
    return () => {};
  }, [activeTab]);

  // on Done
  const onDone = async (data) => {
    const postData = {
      ...data,
      gallery: formState.gallery.reduce((acc, curr) => {
        return curr.image ? [...acc, curr.image] : acc;
      }, []),
      schedule: { ...data.schedule, class_time: data.classTimeState },
    };

    const formData = new FormData();
    buildFormData(formData, postData);
    for (let i = 0; i < postData.gallery; i++) {
      formData.append(
        `gallery[${i}]`,
        postData.gallery[i],
        postData.gallery[i].filename
      );
    }
    headers();

    await AxiosBase.put("/tutor/update-profile", formData);
    Swal.fire({
      position: "center",
      icon: "success",
      title: "Profile Updated",

      showConfirmButton: false,
      timer: 2000,
    });

    history.push("/dashboard");
  };

  // main return
  return (
    <main  className="tutorProfileSetup">
      <div  className="wrapper">
        <div  className="topBar"> tutorservice </div>
        <div  className="head">
          <h1>Update profile</h1>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Libero
            hendrerit diam pretium tristique pretium sit est eget. Nunc, lacus,
            sagittis, non sed libero. At scelerisque ac rhoncus.
          </p>
        </div>
        <nav>
          {navTabs.map((item, index) => {
            return (
              <div
                key={index}
                className={activeTab === item.name ? "tab active" : "tab"}
                onClick={() =>  index <= activeState? setActiveTab(item.name) : false }
              >
                {item.name}
              </div>
            );
          })}
        </nav>
        {navTabs.map(({ name, Component }) => {
          return activeTab === name ? (
            <Component
              formState={formState}
              setFormState={setFormState}
              setActiveTab={setActiveTab}
              onDone={onDone}
            />
          ) : null;
        })}
      </div>
    </main>
  );
}
