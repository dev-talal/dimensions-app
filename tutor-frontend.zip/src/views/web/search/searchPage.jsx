import React, { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { useLocation } from "react-router";
import { getAllTutor } from "../../../api";
import Loading from "../../../components/common/loading";
import FilterSec from "../../../components/search/FilterSec";
import MoreFilters from "../../../components/search/MoreFilters";
import TutorCard from "../../../components/search/TutorCard";
import { filterInit } from "./constant";
import "./searchPage.css";
export default function SearchPage() {
  // states
  const [filterState, setFilterState] = useState(filterInit);
  const [showMoreFilters, setShowMoreFilters] = useState(false);
  const setStateByName = (name, value) => {
    setFilterState((prev) => {
      return { ...prev, [name]: value };
    });
  };

  // query

  const paramsSearch = new URLSearchParams(useLocation().search);
  const paramQueryStr = paramsSearch.get("query");
  useEffect(() => {
    paramQueryStr && setStateByName("query", paramQueryStr);
    return () => {};
  }, [paramQueryStr]);


  const { data, isLoading } = useQuery(["allTutors", filterState], getAllTutor);

  const allTutors = data?.data;

  // main return
  return (
    <main  className="searchPage">
      <section  className=" banner">
        <div  className="basicRow">
          <div  className="container-fluid">
            <div  className="row">
              <FilterSec
                showMoreFilters={showMoreFilters}
                setShowMoreFilters={setShowMoreFilters}
                filterState={filterState}
                setStateByName={setStateByName}
              />
              <div  className="col-md-5">
                <div  className="imageSec d-none d-md-block">
                  <div  className="centerFlex">
                    <img src="/assets/image/searchBanner.svg" alt="image"></img>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <MoreFilters
            showMoreFilters={showMoreFilters}
            filterState={filterState}
            setStateByName={setStateByName}
            reset={() => setFilterState(filterInit)}
          />
        </div>
      </section>
      {isLoading && <Loading height="80vh" />}
      {isLoading || (
        <section  className="p-2">
          <p  className="totalTutors">{allTutors?.length} tutors available </p>
          {allTutors.map((item) => {
            return <TutorCard key={item._id} data={item} />;
          })}
        </section>
      )}
    </main>
  );
}
