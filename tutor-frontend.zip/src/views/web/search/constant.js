export const filterInit = {
  // query: "",
  // classLocation: "",
  priceRange: [5, 100],
  // teach_language: "any",
  // main_field: "",
  // sub_field: "",
  age: "",
  // gradeOfStudent: "",
  // level: "",
  // gender: "any",
  // location: "",
  // nearYou: "",
  // sortBy: "popularity",
};

export const classLocationOptions = [{ text: "Any", value: "any" }];
export const sortByOptions = [
  { text: "Sort by popularity", value: "popularity" },
];
export const teachLanguageOptions = [{ text: "Any", value: "any" }];
export const genderOptions = [
  { text: "Any", value: "any" },
  { text: "Male", value: "male" },
  { text: "Female", value: "female" },
];
export const booking__payment = "BOOKINGPAYMENTSTORAGE";