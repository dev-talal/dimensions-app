import React, { useState } from "react";
import { ClassesList } from "../../../components/web/home/ExploreClasses";
const Exploar = () => {
  const [tabsNav, setTabsnav] = useState("Languages");
  const tabsArray = [
    "School curriculum",
    "Languages",
    "Music",
    "Skills",
    "Exam preparation",
  ];
  const categoryData = [
    { name: "english" },
    { name: "german" },
    { name: "chinese" },
    { name: "spanish" },
    { name: "french" },
    { name: "urdu" },
    { name: "arabic" },
    { name: "japanese" },
    { name: "hindi" },
    { name: "turkish" },
    { name: "russian" },
    { name: "indonesian" },
  ];
  return (
    <div>
      <section className="searchPage mb-3">
        <div className="banner pt-4">
          <div className="basicRow pb-0 d-flex align-items-center">
            <div className="searchSec">
              <h1 className="mb-0 pb-4">Explore categories</h1>
              <ul className="w-100 mb-0 mt-4 navigation-list list-unstyled list-inline">
                {tabsArray.map((item, i) => {
                  return (
                    <li className="list-inline-item" key={i}>
                      <button
                        className={`border-0 px-3 ${
                          tabsNav == item ? "active" : ""
                        }`}
                        onClick={() => setTabsnav(item)}
                      >
                        {item}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        </div>
        <div className="home">
          <section
            className="exploreClasses mt-4 mx-auto"
            style={{ width: "fit-content", maxWidth: "100%" }}
          >
            <div className="basicRow">
              <h2
                className="secTitle mt-0 px-4 pb-4 text-left"
                style={{ fontSize: "30px" }}
              >
                Some common languages you might want to learn
              </h2>
              <div className="flexCenter mainFlex  justify-content-center">
                <ClassesList data={categoryData} width="276px" height="315px" />
              </div>
              <h2
                className="secTitle mt-0 px-4 pb-4 pt-4 text-left"
                style={{ fontSize: "30px" }}
              >
                More languages
              </h2>
              <div className="flexCenter justify-content-start col-md-10 col-lg-9 mainFlex">
                {Array.apply(0, Array(20)).map(function (x, i) {
                  return <h5 className="langauge-heading col-lg-2 mb-3 pb-2 col-6 col-md-4">Lorem</h5>;
                })}
              </div>
            </div>
          </section>
        </div>
      </section>
    </div>
  );
};

export default Exploar;
