import React, { useState } from "react";
import { TextInput } from "../../../components/basic/RenderInputs";
import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import "./auth.css";
import { Link } from "react-router-dom";
import AxiosBase from "../../../config/AxiosBase";
import Swal from "sweetalert2";
import history from "../../../helpers/history";

export default function ForgotAuth() {
  const [loading, setloading] = useState(false);
  //   validation schemea
  const ValidationSchema = Yup.object().shape({
    email: Yup.string()
      .email("Please enter a valid email")
      .min(2, "Too Short! ")
      .max(50, "Too Long!")
      .required("Please enter valid email"),
  });

  //   submit form
  const handleSubmit = async (formData) => {
    setloading(true);
    try {
      const res = await AxiosBase.put("/auth/forgot-password", formData);
      Swal.fire({
        position: "center",
        icon: "success",
        text: res.data?.message,
        showConfirmButton: false,
        timer: 3000,
      });
      history.push("/auth/otp-verification", formData.email);
    } catch (error) {
      Swal.fire({
        position: "center",
        icon: "error",
        text: error?.response?.data?.message,
        showConfirmButton: false,
        timer: 3000,
      });
    }

    setloading(false);
  };

  //   main return
  return (
    <div  className="container-fluid authFlowContainer">
      <div  className="circle1"></div>
      <div  className="circle2"></div>
      <div  className="circle3"></div>
      <div
         className="row  "
        style={{ height: "100vh", alignItems: "center", overflow: "hidden" }}
      >
        <div  className=" d-none d-md-block col-md-6">
          <div  className="centerFlex">
            <img
              src="/assets/image/authLock.svg"
              alt="auth"
               className="authLock"
            ></img>
          </div>
        </div>
        <div  className="col-md-6 col-lg-5">
          <div  className="centerFlex">
            <div  className="contentWrapper w-100 mt-lg-5 pt-lg-5">
              <h1>
                Forgot
                <br /> your password?
              </h1>
              <p>Please provide your email for verification</p>
              <Formik
                initialValues={{
                  email: "",
                }}
                validationSchema={ValidationSchema}
                onSubmit={handleSubmit}
              >
                <Form>
                  <Field
                    name="email"
                    component={TextInput}
                    placeholder="Enter Email"
                    label="Email"
                    topclass="ml-2"
                  />

                  <button
                    disabled={loading}
                    type="submit"
                     className="primaryButton w-100"
                  >
                    {loading ? "Reseting..." : "Reset"}
                  </button>
                  <div  className="text-center loginText">
                    Back to{" "}
                    <Link to="/login"  className="textPrimary poppinsBd">
                      Login
                    </Link>
                  </div>
                </Form>
              </Formik>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
