import React, { useState } from "react";
import { TextInput } from "../../../components/basic/RenderInputs";
import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import "./auth.css";
import AxiosBase from "../../../config/AxiosBase";
import Swal from "sweetalert2";
import history from "../../../helpers/history";
import { useLocation } from "react-router";

export default function ResetPassoword() {
  // state
  const [loading, setloading] = useState(false);

  const pushState = useLocation().state;

  //   if there is not email
  //   useEffect(() => {
  //     if (!pushState) {
  //       history.push("/");
  //     }
  //     return () => {};
  //   }, []);

  //   validation schemea

  const ValidationSchema = Yup.object().shape({
    password: Yup.string()
      .required("Please enter a passowrd")
      .min(8, "Password must be upto 8 Charachters"),
  });

  //   submit form
  const handleSubmit = async (formData) => {
    setloading(true);
    try {
      const res = await AxiosBase.put("/auth/reset-password", {
        email: pushState,
        ...formData,
      });
      Swal.fire({
        position: "center",
        icon: "success",
        text: res.data?.message,
        showConfirmButton: false,
        timer: 3000,
      });
      history.push("/login");
    } catch (error) {
      Swal.fire({
        position: "center",
        icon: "error",
        text: error?.response?.data?.message,
        showConfirmButton: false,
        timer: 3000,
      });
    }

    setloading(false);
  };

  //   main return
  return (
    <div  className="container-fluid authFlowContainer">
      <div  className="circle1"></div>
      <div  className="circle2"></div>
      <div  className="circle3"></div>
      <div
         className="row  "
        style={{ height: "100vh", alignItems: "center", overflow: "hidden" }}
      >
        <div  className=" d-none d-md-block col-md-6">
          <div  className="centerFlex">
            <img
              src="/assets/image/authLock.svg"
              alt="auth"
               className="authLock"
            ></img>
          </div>
        </div>
        <div  className="col-md-6">
          <div  className="centerFlex">
            <div  className="contentWrapper">
              <h1>
                Reset
                <br /> password
              </h1>
              <p>Verification successful. Please reset your password.</p>
              <Formik
                initialValues={{
                  password: "",
                }}
                validationSchema={ValidationSchema}
                onSubmit={handleSubmit}
              >
                <Form>
                  <Field
                    name="password"
                    type="password"
                    component={TextInput}
                    placeholder="Enter new password"
                    label="New password"
                    topclass="ml-2"
                  />

                  <button
                    disabled={loading}
                    type="submit"
                     className="primaryButton w-100"
                  >
                    {loading ? "loading..." : "Update password"}
                  </button>
                </Form>
              </Formik>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
