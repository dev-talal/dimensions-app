import React, { useEffect, useState } from "react";
import "./auth.css";
import AxiosBase from "../../../config/AxiosBase";
import Swal from "sweetalert2";
import history from "../../../helpers/history";
import { useLocation } from "react-router";
import { Link } from "react-router-dom";
import { verifyEmail } from "../../../api";

export default function EmailVerification() {
  const [loading, setloading] = useState(false);
  const handler = async () => {
    setloading(true);
    try {
      const res = await verifyEmail(window.location.pathname.split("/")[3]);
    } catch (error) {
      Swal.fire({
        position: "center",
        icon: "error",
        text: error?.response?.data?.message,
        showConfirmButton: false,
        timer: 3000,
      });
    }

    setloading(false);
  };
  useEffect(async () => {
    console.log("ok", window.location.pathname.split("/")[3]);
    await handler();
  }, []);
  return (
    <div className="container-fluid authFlowContainer">
      <div className="circle1"></div>
      <div className="circle2"></div>
      <div className="circle3"></div>
      <div
        className="row  "
        style={{ height: "100vh", alignItems: "center", overflow: "hidden" }}
      >
        <div className=" d-none d-md-block col-md-6">
          <div className="centerFlex">
            <img
              src="/assets/image/email-verify.webp"
              alt="email verify"
              className="authLock"
            ></img>
          </div>
        </div>
        <div className="col-md-6">
          <div className="centerFlex">
            <div className="contentWrapper">
              <h1 className="mb-1">Email Verified</h1>
              <p className="pb-3">
                Verification successful. Please login to your account.
              </p>
              <Link
                to="/login"
                className="primaryButton w-100 d-block text-center mt-4"
              >
                Login
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
