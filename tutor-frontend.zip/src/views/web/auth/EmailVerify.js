import React, { useState } from "react";
import "./auth.css";
import AxiosBase from "../../../config/AxiosBase";
import Swal from "sweetalert2";
import history from "../../../helpers/history";
import { useLocation } from "react-router";
import { Field, Formik } from "formik";
import { TextInput } from "../../../components/basic/RenderInputs";
import { Form } from "react-bootstrap";
import { ValidationSchema } from "../workshop/Validation";
import { resendVerification } from "../../../api";

export default function EmailVerify() {
  const [loading, setloading] = useState(false);
    const handleSubmit = async (formData) => {
        setloading(true);
        try {
          const res = await resendVerification(formData)
          Swal.fire({
            position: "center",
            icon: "success",
            text: res.data?.message,
            showConfirmButton: false,
            timer: 3000,
          });
          history.push("/login");
        } catch (error) {
          Swal.fire({
            position: "center",
            icon: "error",
            text: error?.response?.data?.message,
            showConfirmButton: false,
            timer: 3000,
          });
        }
        setloading(false);
     };
  return (
    <div  className="container-fluid authFlowContainer">
      <div  className="circle1"></div>
      <div  className="circle2"></div>
      <div  className="circle3"></div>
      <div
         className="row  "
        style={{ height: "100vh", alignItems: "center", overflow: "hidden" }}
      >
        <div  className=" d-none d-md-block col-md-6">
          <div  className="centerFlex">
            <img
              src="/assets/image/check-mail-people.png"
              alt="email verify"
               className="authLock"
            ></img>
          </div>
        </div>
        <div  className="col-md-6">
          <div  className="centerFlex">
            <div  className="contentWrapper">
                <h1 className="mb-1">
                    Verify Email
                </h1>
                <p className="pb-3">Enter your email address so, <br /> we will send a verification link on your email</p>
                  <Formik
                    onSubmit={handleSubmit}
                    initialValues={{ email: '' }}
                    validate={values => {
                      const errors = {};
                      if (!values.email) {
                        errors.email = 'Required';
                      } else if (
                        !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
                      ) {
                        errors.email = 'Invalid email address';
                      }
                      return errors;
                    }}
                  >
                  {({
                    handleSubmit
                  }) => (
                  <Form onSubmit={handleSubmit}>
                    <Field
                      name="email"
                      type="email"
                      component={TextInput}
                      placeholder="Enter email address"
                      label="Email address"
                      topclass="ml-2"
                    />
                    <button disabled={loading}
                      className="primaryButton w-100 d-block text-center mt-4"
                    >
                      Submit
                    </button>         
                  </Form>
                  )}
                </Formik>
                <button disabled={loading} onClick={()=>history.push('/login')}
                  className="primaryButton bg-info w-100 d-block text-center mt-3"
                >
                  Back to login
                </button> 
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
