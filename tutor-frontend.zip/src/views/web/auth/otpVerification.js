import React, { useState, useEffect } from "react";
import { TextInput } from "../../../components/basic/RenderInputs";
import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import "./auth.css";
import { Link } from "react-router-dom";
import AxiosBase from "../../../config/AxiosBase";
import Swal from "sweetalert2";
import history from "../../../helpers/history";
import { useLocation } from "react-router";

export default function OtpVerification() {
  // state
  const [loading, setloading] = useState(false);

  const pushState = useLocation().state;

  //   if there is not email
  useEffect(() => {
    if (!pushState) {
      history.push("/");
    }
    return () => {};
  }, [pushState]);

  //   validation schemea

  const ValidationSchema = Yup.object().shape({
    code: Yup.string().required("Please enter valid number"),
  });

  //   submit form
  const handleSubmit = async (formData) => {
    setloading(true);
    try {
      const res = await AxiosBase.put("/auth/otp-verify", {
        otp: formData.code,
        email: pushState,
      });
      Swal.fire({
        position: "center",
        icon: "success",
        text: res.data?.message,
        showConfirmButton: false,
        timer: 3000,
      });
      history.push("/auth/reset-password", pushState);
    } catch (error) {
      Swal.fire({
        position: "center",
        icon: "error",
        text: error?.response?.data?.message,
        showConfirmButton: false,
        timer: 3000,
      });
    }

    setloading(false);
  };

  //   on email resend

  const resendEmail = async () => {
    try {
      await AxiosBase.put("/auth/forgot-password", {
        email: pushState,
      });
      Swal.fire({
        position: "center",
        icon: "success",
        text: "OTP resent successfully",
        showConfirmButton: false,
        timer: 3000,
      });
    } catch (error) {
      Swal.fire({
        position: "center",
        icon: "error",
        text: error?.response?.data?.message,
        showConfirmButton: false,
        timer: 3000,
      });
    }
  };

  //   main return
  return (
    <div  className="container-fluid authFlowContainer">
      <div  className="circle1"></div>
      <div  className="circle2"></div>
      <div  className="circle3"></div>
      <div
         className="row  "
        style={{ height: "100vh", alignItems: "center", overflow: "hidden" }}
      >
        <div  className=" d-none d-md-block col-md-6">
          <div  className="centerFlex">
            <img
              src="/assets/image/authLock.svg"
              alt="auth"
               className="authLock"
            ></img>
          </div>
        </div>
        <div  className="col-md-6">
          <div  className="centerFlex">
            <div  className="contentWrapper">
              <h1>
                OTP
                <br /> verification
              </h1>
              <p>Please provide OTP verification code sent to your email</p>
              <Formik
                initialValues={{
                  code: "",
                }}
                validationSchema={ValidationSchema}
                onSubmit={handleSubmit}
              >
                <Form>
                  <div onClick={resendEmail}  className="resendDiv">
                    <img
                      src="/assets/image/resend.svg"
                      alt="resend"
                       className="mr-2"
                    ></img>
                    <span>Resend email</span>
                  </div>
                  <Field
                    name="code"
                    type="number"
                    component={TextInput}
                    placeholder="Enter code"
                    label="OTP code"
                    topclass="ml-2"
                  />

                  <button
                    disabled={loading}
                    type="submit"
                     className="primaryButton w-100"
                  >
                    {loading ? "Reseting..." : "Reset"}
                  </button>
                  <div  className="text-center loginText">
                    Back to{" "}
                    <Link to="/login"  className="textPrimary poppinsBd">
                      Login
                    </Link>
                  </div>
                </Form>
              </Formik>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
