import React from "react";
import { Col, Row } from "react-bootstrap";
import { Formik, Form, Field } from "formik";
import { TextInput } from "../../../components/basic/RenderInputs";
const Contact = () => {
  return (
    <div className="basicRow pt-3 pb-0 pr-0 overflow-hidden">
      <Row>
        <Col
          xs={12}
          lg={6}
          style={{
            backgroundImage: "url('/assets/png/phone-office-thin.png')",
            backgroundRepeat: "no-repeat",
            backgroundPosition: " right 25px bottom 60px",
          }}
        >
          <div className="contact-details px-3">
            <h5>
              Contact
              <br />
              information
            </h5>
            <span className="d-block mt-2">
              Please fill the information and our team will be in touch with you
              soon.
            </span>
            <ul className="p-0 mb-0 list-unstyled mt-4 pt-2">
              <li className="mb-4 pb-2">
                <a
                  href="tel:+0123 52689 256"
                  className="d-flex align-items-center"
                >
                  <img
                    src="/assets/image/phone-solid.svg"
                    className="mr-3"
                    height="17px"
                  />
                  <span>+0123 52689 256</span>
                </a>
              </li>
              <li className="mb-4 pb-2">
                <a
                  href="mailto:abccompany@email.com"
                  className="d-flex align-items-center"
                >
                  <img
                    src="/assets/image/envelope-solid.svg"
                    className="mr-3"
                    height="17px"
                  />
                  <span>abccompany@email.com</span>
                </a>
              </li>
              <li>
                <a href="#" className="d-flex align-items-center">
                  <img
                    src="/assets/image/location-dot-solid.svg"
                    className="mr-3"
                    height="17px"
                  />
                  <span>P-457, 102 road, mian town, UY.</span>
                </a>
              </li>
            </ul>
            <div className="footer border-0 d-flex pt-5 mt-5  mx-0 mb-0 p-0 bg-transparent">
              <div class="socialDiv" style={{ backgroundColor: "#EFC282" }}>
                <img src="/assets/image/fbIcon.svg" alt="facebook" />
                <br />
              </div>
              <div class="socialDiv" style={{ backgroundColor: "#EFC282" }}>
                <img src="/assets/image/instaIcon.svg" alt="instagram" />
              </div>
            </div>
          </div>
        </Col>
        <Col xs={12} lg={6}>
          <div className="p-4 bg-white">
            <div className="contact-details">
              <h5>Contact us</h5>
            </div>
            <Formik>
              <Row className="mt-4">
                <Col lg={6} className="mb-2">
                  <Field
                    name="first_name"
                    component={TextInput}
                    placeholder="Enter First name"
                    label="First name"
                    type="text"
                  />
                </Col>
                <Col lg={6} className="mb-2">
                  <Field
                    name="last_name"
                    component={TextInput}
                    placeholder="Enter Last name"
                    label="Last name"
                    type="text"
                  />
                </Col>
                <Col lg={6} className="mb-2">
                  <Field
                    name="email_address"
                    component={TextInput}
                    placeholder="Enter Email address"
                    label="Email address"
                    type="email"
                  />
                </Col>
                <Col lg={6} className="mb-2">
                  <Field
                    name="phone_number"
                    component={TextInput}
                    placeholder="Enter Phone number"
                    label="Phone number"
                    type="number"
                  />
                </Col>
                <Col lg={12} className="mb-2">
                  <div class="customInputDiv">
                    <label class="label form-label">Message</label>
                    <textarea
                      rows="5"
                      className="textInput"
                      placeholder="Message"
                      style={{ height: 150 }}
                    ></textarea>
                  </div>
                </Col>
                <Col xs={12} className="text-right mt-4 mb-5">
                  <button class="primaryButton mt-0" style={{padding: "11px 36px"}}>Submit</button>
                </Col>
              </Row>
            </Formik>
          </div>
        </Col>
      </Row>
      <style>
        {
          "\
        body{\
          background: rgb(122 187 181 / 10%);\
        }\
      "
        }
      </style>
    </div>
  );
};

export default Contact;
