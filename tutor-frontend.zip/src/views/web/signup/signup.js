import React from "react";
import history from "../../../helpers/history";
import "./signup.css";
function signup() {
  return (
    <div  className="signUpWarpper">
      <div  className="mainFlex">
        <h1>Are you a ...?</h1>
        <h2>Please select an option for registration</h2>

        <div  className="itemFLex">
          <div
            onClick={() => history.push("/sign-up/tutor")}
             className="itemCard mr-0 mr-md-5"
          >
            <div  className="centerFlex ">
              <img src="/assets/image/tutor.svg" alt="tutor"></img>
            </div>
            <h3>Tutor </h3>
          </div>
          <div
            onClick={() => history.push("/sign-up/parent")}
             className="itemCard"
          >
            <div  className="centerFlex">
              <img src="/assets/image/parent.svg" alt="tutor"></img>
            </div>
            <h3>Student / Parent </h3>
          </div>
        </div>
      </div>
    </div>
  );
}

export default signup;
