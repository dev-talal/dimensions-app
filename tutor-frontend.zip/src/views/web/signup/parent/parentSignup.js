import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Formik, Form, Field } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { Col, Row } from "reactstrap";
import { useLocation } from "react-router";
import {
  ChechBoxInput,
  SelectInput,
  TextInput,
} from "../../../../components/basic/RenderInputs";
import history from "../../../../helpers/history";
import { SignUp } from "../../../../redux/actions/authActions";
import {
  SignUpValidationSchema,
  // IndividualSignUpValidationSchema,
} from "../../../../helpers/validations";
import { LoginSocialGoogle, LoginSocialFacebook } from "reactjs-social-login";
import { getBirthdayDetails, socialAuthentication } from "../../../../api";
import Swal from "sweetalert2";
import { LOGIN_SUCCESS,REGISTER_USER_REQUEST,REGISTER_USER_FAIL } from "../../../../redux/constants/userConstant";
export default function ParentSignup() {
  // states
  const [role, setRole] = useState("individual");
  const [mainRole, setMainRole] = useState("");
  const { loading } = useSelector((state) => state.auth);
  const [indCheck, setindCheck] = useState(false);
  const [indCheckMessage, setindCheckMessage] = useState(false);
  // query params active on role='role'
  const query = new URLSearchParams(useLocation().search);
  const queryRole = query.get("role");

  // path active mainRole logic
  const path = useLocation().pathname;
  useEffect(() => {
    console.log(role, path);
    if (path === "/sign-up/parent") {
      setMainRole("parent");
      queryRole && setRole(queryRole);
    }
    if (path === "/sign-up/tutor") {
      setMainRole("tutor");
      setRole("tutor");
    }
    return () => {
      setMainRole("");
    };
  }, [path, queryRole]);

  // dispatch
  const dispatch = useDispatch();

  //   submit form
  const handleSubmit = async ({ firstName, lastName, ...formData }) => {
    // console.log(formData);
    if (role === "individual" && !indCheck) {
      setindCheckMessage(true);
      return;
    } else {
      setindCheckMessage(false);
    }
    const user_type = mainRole === "tutor" ? mainRole : role;
    const postData = {
      ...formData,
      first_name: firstName,
      last_name: lastName,
      user_type,
    };
    dispatch(SignUp(postData));
  };
  // const responseGoogle = (response) => {
  //   console.log(response);
  // };
  // const responseFacebook = (response) => {
  //   console.log(response);
  // };

  const socialResponseData = async ({
    id,
    first_name,
    last_name,
    email,
    picture,
    gender,
    register_type,
  }) => {
    dispatch({ type: REGISTER_USER_REQUEST });
    const payload = {
      id:id,
      first_name:first_name,
      last_name:last_name,
      email:email,
      picture:picture,
      gender:gender,
      register_type:register_type,
      type:"sign_up",
      user_type:role
    }
    try{
      const res = await socialAuthentication(payload);
      localStorage.setItem("authToken", res.data.token);
      dispatch({
        type: LOGIN_SUCCESS,
        payload: res.data,
        token: res.data.token,
      });
      Swal.fire({
        text:'User registerd successfully',
        icon:'success'
      })
      history.push("/dashboard");
    }
    catch(error){
      const {response} = error;
      if(response?.data?.message){
        Swal.fire({
          text:response.data?.message,
          icon:'error'
        })
      }else{
        Swal.fire({
          text:'Something went wrong',
          icon:'error'
        })
      }
      dispatch({ type: REGISTER_USER_FAIL });
    }
  };
  // main return
  return (
    <div className="signUpScreen">
      <div className="bgSec d-none d-md-inline">
        <div className="centerFlex">
          <img
            src="/assets/image/stamp.svg"
            className="stampIcon"
            alt="stamp"
          ></img>
        </div>
        <h1>Welcome! You are a few clicks away.</h1>
        <div className="toggleSec">
          <Link
            to="/sign-up/tutor"
            className={mainRole === "tutor" && "active"}
            onClick={() => setMainRole("tutor")}
          >
            Tutor
          </Link>
          <Link
            to="/sign-up/parent"
            className={mainRole === "parent" && "active"}
          >
            Student / Parent
          </Link>
        </div>
        <Link to="/">
          <h2>
            <img
              src="/assets/png/logo.png"
              width="35px"
              className="mr-3 white-filter"
            />{" "}
            Eddaris
          </h2>
        </Link>
      </div>
      <div className="contentSec">
        <div className="wrapper">
          <div className="flexBetweenCenter headOne px-3">
            <h1>Sign up</h1>
            <div className="flexCenter social">
              {/* <a href={`${process.env.REACT_APP_BASE_URL}/auth/google?user_type=${mainRole}`} target="_blank" className="mr-3">
                <img src="/assets/image/googleIcon.svg" alt="google" />
              </a> */}
              {/* <SocialLogin
                provider="google"
                appId={process.env.REACT_APP_GOOGLE_CLIENT_ID}
                callback={responseGoogle}
              >
                <button className="mr-3">
                  <img src="/assets/image/googleIcon.svg" alt="google" />
                </button>
              </SocialLogin>

              <SocialLogin
                provider="facebook"
                appId={process.env.REACT_APP_FACEBOOK_ID}
                scope={["email", "user_gender"]}
                fieldsProfile={
                  "id,first_name,last_name,middle_name,name,name_format,picture,short_name,email,gender"
                }
                callback={responseFacebook}
                // onLoginFailure={responseGoogle}
              >
                <button>
                  <img src="/assets/image/facebookIcon.svg" alt="facebook" />
                </button>
              </SocialLogin> */}

              <LoginSocialGoogle
                client_id={process.env.REACT_APP_GOOGLE_CLIENT_ID}
                scope="profile email https://www.googleapis.com/auth/user.birthday.read https://www.googleapis.com/auth/user.gender.read"
                onResolve={async ({ provider, data }) => {
                  let gender = await getBirthdayDetails({
                    id: data.sub,
                    access_token: data.access_token,
                  });
                  socialResponseData({
                    id: data.sub,
                    first_name: data.given_name,
                    last_name: data.family_name,
                    email: data.email,
                    picture: data.picture,
                    gender,
                    register_type: "google",
                  });
                }}
                onReject={(err) => {
                  console.log(err);
                }}
              >
                <button className="mr-3">
                  <img src="/assets/image/googleIcon.svg" alt="google" />
                </button>
              </LoginSocialGoogle>

              <LoginSocialFacebook
                appId={process.env.REACT_APP_FACEBOOK_ID}
                fieldsProfile={
                  "id,first_name,last_name,middle_name,name,name_format,picture,short_name,email,gender"
                }
                // onLoginStart={onLoginStart}
                // onLogoutSuccess={onLogoutSuccess}
                // redirect_uri={REDIRECT_URI}
                onResolve={({ provider, data }) => {
                  socialResponseData({
                    id: data.id,
                    first_name: data.first_name,
                    last_name: data.last_name,
                    email: data.email,
                    picture: data.picture.data.url,
                    gender: data.gender,
                    register_type: "facebook",
                  });
                }}
                onReject={(err) => {
                  console.log(err);
                }}
              >
                <button>
                  <img src="/assets/image/facebookIcon.svg" alt="facebook" />
                </button>
              </LoginSocialFacebook>
            </div>
          </div>
          {mainRole === "tutor" || (
            <div className="flexBetweenCenter headTwo px-3">
              <h5>Sign up as</h5>
              <div className="toggleButton">
                <span
                  className={role === "individual" && "active"}
                  onClick={() => setRole("individual")}
                >
                  Individual
                </span>
                <span
                  className={role === "parent" && "active"}
                  onClick={() => setRole("parent")}
                >
                  Parent
                </span>
              </div>
            </div>
          )}
          <Formik
            initialValues={{
              firstName: "",
              lastName: "",
              email: "",
              password: "",
              gender: "",
              termsAndCondition: false,
            }}
            // validationSchema={SignUpValidationSchema}
            validationSchema={
              // role === "individual"
              //   ? IndividualSignUpValidationSchema
              //   : SignUpValidationSchema
              SignUpValidationSchema
            }
            onSubmit={handleSubmit}
          >
            <Form className={mainRole === "tutor" && "mt-5 pt-3"}>
              <div className="container-fluid">
                <Row>
                  <Col md="6">
                    <Field
                      name="firstName"
                      component={TextInput}
                      placeholder="Enter first name"
                      label="First Name"
                    />
                  </Col>

                  <Col md="6">
                    <Field
                      name="lastName"
                      component={TextInput}
                      placeholder="Enter last name"
                      label="Last Name"
                    />
                  </Col>
                </Row>
                <Row>
                  <Col md="12">
                    <Field
                      name="email"
                      component={TextInput}
                      placeholder="Enter Email"
                      label="Email"
                      topclass="ml-2"
                    />
                  </Col>
                  <Col md="12">
                    <Field
                      name="password"
                      component={TextInput}
                      placeholder="Enter Passowrd"
                      label="Password"
                      type="password"
                    />
                  </Col>
                </Row>
                <Row>
                  <Col md="12">
                    <Field
                      id="gender"
                      name="gender"
                      label="Gender"
                      component={SelectInput}
                      options={[
                        { text: "Male", value: "male" },
                        { text: "Female", value: "female" },
                      ]}
                      placeholder="Select Gender"
                      type="select"
                    />
                  </Col>
                </Row>
                <Row>
                  <Col md="12">
                    <Field
                      id="termsAndCondition"
                      name="termsAndCondition"
                      component={ChechBoxInput}
                      label={`I’ve read and agree with <a href="/terms-and-Service" className='link'>Terms of Service</a> and <a href="/privacy-policy" className="link"> Privacy Policy </a>.`}
                      type="password"
                      topclass="ml-2"
                    />
                  </Col>
                </Row>
                {role === "individual" && (
                  <Row>
                    <Col md="12 mt-2">
                      <Field
                        id="individualCheck"
                        name="individualCheck"
                        component={ChechBoxInput}
                        label={`Yes I am 18 years old or more.`}
                        type="checkbox"
                        topclass="ml-2"
                        checked={indCheck}
                        onChange={(e) => setindCheck(e.target.checked)}
                      />
                      {indCheckMessage && (
                        <div className="errorText">
                          Please agree your are 18 year old or more
                        </div>
                      )}
                    </Col>
                  </Row>
                )}

                <div className="flexBetweenCenter buttonSec">
                  <button disabled={loading} type="submit" className="signup">
                    {loading ? " Loading..." : " Sign up"}
                  </button>
                  <button
                    onClick={() => history.push("/login")}
                    type="button"
                    className="login"
                  >
                    Login
                  </button>
                </div>
              </div>
            </Form>
          </Formik>
        </div>
      </div>
    </div>
  );
}
