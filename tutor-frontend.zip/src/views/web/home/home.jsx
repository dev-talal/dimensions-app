import React,{useLayoutEffect,useEffect} from "react";
import { useLocation } from "react-router-dom";
import BannerSec from "../../../components/web/home/BannerSec";
import ExploreClasses from "../../../components/web/home/ExploreClasses";
import GreateTutor from "../../../components/web/home/GreateTutor";
import LearningSec from "../../../components/web/home/LearningSec";
import MyWorkshop from "../../../components/web/home/MyWorkshop";
import "./home.css";
export default function Home() {
  const location = useLocation();
  const scrollSection = () => {
    const params = new URL(window.location.href);
    if(params.searchParams.get("section")) {
      let taget_ele = document.getElementById('section_how_works');
      window.scrollTo({
        top: taget_ele.offsetTop,
        behavior: 'smooth',
      });
    }
  }
  useLayoutEffect(() => {
    scrollSection();
  },[location]);

  return (
    <main  className="home">
      <BannerSec />
      <ExploreClasses />
      <MyWorkshop />
      <LearningSec />
      <GreateTutor />
    </main>
  );
}
