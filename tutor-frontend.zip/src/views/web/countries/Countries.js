import React from "react";
import { Row , Col} from "react-bootstrap";
const Countries = () => {
  const countriesArray = [
      {title:"United States",url:"united-states-of-america"},
      {title:"Brazil",url:"brazil"},
      {title:"Canada",url:"canada"},
      {title:"Colombia",url:"colombia"},
      {title:"Argentina",url:"argentina"},
      {title:"Mexico",url:"mexico"}
  ]
  const CounteryList = ({heading}) => {
      return(
        <div className="mt-0 bannerSec pe-lg-5 pb-4">
            <div className="header-countries">
                <h5  className="mb-0 pb-2">{heading}</h5>
            </div>
            <Row>
            {countriesArray.map(function (x, i) {
                    return (
                        <Col lg={4} sm={6} xl={3}  className="mt-4 pt-2" key={i}>
                            <div  className="d-flex align-items-center">
                                <div  className="mr-3">
                                    <img width="35px"  className="rounded-circle" height="35px" src={`/assets/png/${x.url}.png`} alt={x.title} />
                                </div>
                                <span>{x.title}</span>
                            </div>
                        </Col>
                    );
                })}
            </Row>
        </div>
      )
  }
  return (
    <div>
      <div style={{ background: "#F1F8F8" }}>
        <div  className="site-conditions d-flex align-items-center pb-4 mt-0 bannerSec">
          <div  className="pr-lg-5">
            <h5  className="pb-3">Countries</h5>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. In donec
              ante convallis molestie in. Mauris, turpis gravida vestibulum
              tellus lacus habitasse enim donec elementum.
            </p>
            <div  className="text-center mt-5 pt-4">
              <img
                src="/assets/image/arrowDownBlack.svg"
                width="26px"
                alt="arrowDownBlack"
              />
              <span  className="d-block mt-3">Scroll below</span>
            </div>
          </div>
          <div>
            <img src="/assets/image/globe.svg"  className="rounded-animation" alt="globe" />
          </div>
        </div>
      </div>
      <CounteryList heading="America" />
      <CounteryList heading="Africa" />
      <CounteryList heading="Asia & Oceania" />
      <CounteryList heading="Europe" />
    </div>
  );
};

export default Countries;
