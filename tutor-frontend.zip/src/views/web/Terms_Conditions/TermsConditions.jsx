import React from 'react'

const TermsConditions = ({heading}) => {
  return (
    <div>
        <div style={{background:"#F1F8F8"}}>
            <div  className="site-conditions  mt-0 bannerSec">
                <h5  className='pb-5'>{heading}</h5>
            </div>
        </div>
        <div className="mt-0 bannerSec">
            <p  className='site-conditions-text'>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis donec eget tellus lectus lectus. Metus, tristique vestibulum aliquet morbi sollicitudin massa proin id vulputate. Ultricies lacus ullamcorper semper ut varius. Lacus, dignissim quis a turpis aliquam rhoncus. Cras lectus cursus consequat a auctor congue. Scelerisque aenean dui lectus mi quis convallis augue. Leo lacus mauris sit sed massa nulla. Blandit tortor in scelerisque facilisis a hac volutpat, scelerisque. Egestas morbi pellentesque blandit nibh. Aliquet justo sed sed ipsum ipsum. Dui pretium morbi vitae, donec eget iaculis. Faucibus quis scelerisque vel netus nunc. Massa diam arcu feugiat diam non.
                Sed id sed bibendum orci tempus a dictum id ornare. Aenean sagittis, sapien, viverra iaculis nisl, mattis imperdiet. Purus adipiscing vitae feugiat dui tristique mi. Volutpat tempor lorem a sagittis diam et fusce mauris ut. Nunc est facilisis neque eget arcu.
                Amet massa viverra et ornare natoque. Pellentesque a sed pellentesque urna, elit cras congue. Leo purus enim, suspendisse sit pulvinar augue.
                In amet ut volutpat sit. Tristique amet volutpat, praesent praesent.
                Enim sapien eu urna dui vestibulum, lobortis. Tortor, hac pulvinar faucibus lacus quis mauris, nisl mollis etiam. Ultrices nunc massa facilisis urna malesuada dictumst est. Facilisis sagittis placerat non in vestibulum quis est hac. Nascetur turpis egestas enim ipsum morbi amet.
                Sagittis aliquam ut massa consectetur dolor non egestas.
                Lectus neque tellus consectetur malesuada mi scelerisque. Eget tempus sed pharetra pellentesque dignissim vulputate nam nibh quis.
                In at amet, eget ac eu. Id eu proin diam interdum ut pharetra varius sed. Eu venenatis, vel amet, velit et lorem purus turpis. Neque pellentesque est placerat congue etiam.
                Eget proin vitae diam nec pulvinar urna, donec pulvinar. Nunc feugiat pellentesque tempor feugiat nisl consequat amet nunc. Integer nisl quis hendrerit aliquam, diam lacus amet scelerisque mattis. Lectus quis praesent volutpat pulvinar at viverra orci vitae nec. Mus neque fringilla diam pulvinar ut est, sagittis, justo sed. Bibendum posuere ipsum tellus amet, et, pretium imperdiet.
                Proin accumsan ut ultrices bibendum fermentum tincidunt commodo, mattis. Id ullamcorper a neque nullam libero. Placerat gravida suspendisse tempor massa. Enim diam nibh ultrices augue. Tempus egestas diam lacus sed aliquam sed venenatis. Sit purus gravida porttitor gravida orci felis habitant arcu. Vitae netus nisl laoreet mattis. Nibh suspendisse in cras tellus nulla dui. Suscipit felis neque a felis pellentesque. A commodo est integer elementum in gravida vitae. Lectus dui, platea id ornare. Rhoncus tellus pellentesque commodo justo, lacinia in at mi. Turpis potenti porta malesuada elit. Malesuada cras arcu, varius luctus accumsan, mauris.
            </p>
        </div>
    </div>
  )
}

export default TermsConditions