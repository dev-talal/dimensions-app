import React from "react";
import { Accordion } from "react-bootstrap";

const Faqs = () => {
  return (
    <div>
      <div style={{ background: "#F1F8F8" }}>
        <div className="site-conditions  mt-0 bannerSec">
          <h5 className="pb-3">FAQs</h5>
        </div>
      </div>
      <div className="mt-0 bannerSec">
        <Accordion className="main-accordion">
          {["General account","Payment method","Tutor","Student / Parent"].map(function (x, i) {
            return (
              <Accordion.Item
                className="main-accordion-item mb-5"
                eventKey={`general-${i+1}`}
              >
                <Accordion.Header className="mb-2 main-accordion-button">
                  {x}
                </Accordion.Header>
                <Accordion.Body>
                  <Accordion className="inner-accordion">
                    <Accordion.Item
                      className="inner-accordion-item"
                      eventKey={`inner-${i+1}`}
                    >
                      <Accordion.Header className="mb-2">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        In donec ante convallis molestie in. Mauris, turpis
                        gravida vestibulum tellus lacus habitasse enim donec
                        elementum.
                      </Accordion.Header>
                      <Accordion.Body className="pr-4 pt-1">
                        <p className="mb-0 pl-4 pr-5">
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit. In donec ante convallis molestie in. Mauris,
                          turpis gravida vestibulum tellus lacus habitasse enim
                          donec elementum. Lorem ipsum dolor sit amet,
                          consectetur adipiscing elit. In donec ante convallis
                          molestie in. Mauris, turpis gravida vestibulum tellus
                          lacus habitasse enim donec elementum.
                        </p>
                      </Accordion.Body>
                    </Accordion.Item>
                  </Accordion>
                </Accordion.Body>
              </Accordion.Item>
            );
          })}
        </Accordion>
      </div>
    </div>
  );
};
export default Faqs;
