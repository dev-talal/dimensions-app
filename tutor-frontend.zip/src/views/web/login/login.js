import React from "react";
import { Formik, Form, Field } from "formik";
import { useDispatch, useSelector } from "react-redux";
import { Col, Row } from "reactstrap";
import { TextInput } from "../../../components/basic/RenderInputs";
import * as Yup from "yup";
import history from "../../../helpers/history";
import { LogIn } from "../../../redux/actions/authActions";
import "./login.css";
import { Link } from "react-router-dom";
import { LoginSocialGoogle, LoginSocialFacebook } from "reactjs-social-login";
import { socialAuthentication } from "../../../api";
import { LOGIN_FAIL, LOGIN_REQUEST, LOGIN_SUCCESS } from "../../../redux/constants/userConstant";
import Swal from "sweetalert2";

export default function Login() {
  const { loading } = useSelector((state) => state.auth);
  // dispatch
  const dispatch = useDispatch();

  //   submit form
  const handleSubmit = async (formData) => {
    dispatch(LogIn(formData, "/auth/login"));
  };

  //   validation schemea
  const ValidationSchema = Yup.object().shape({
    email: Yup.string()
      .email("Please enter a valid email")
      .min(2, "Too Short! ")
      .max(50, "Too Long!")
      .required("Please enter valid email"),
    password: Yup.string()
      .required("Please enter a passowrd")
      .min(8, "Password must be upto 8 Charachters"),
  });
  const socialResponseData = async ({
    email,
    register_type,
  }) => {
    dispatch({ type: LOGIN_REQUEST });
    const payload = {
      email:email,
      register_type:register_type,
      type:"log_in",
    }
    try{
      const res = await socialAuthentication(payload);
      localStorage.setItem("authToken", res.data.token);
      dispatch({
        type: LOGIN_SUCCESS,
        payload: res.data,
        token: res.data.token,
      });
      Swal.fire({
        text:'User Logged in Successfully',
        icon:'success'
      })
      history.push("/dashboard");
    }
    catch(error){
      const {response} = error;
      if(response?.data?.message){
        Swal.fire({
          text:response.data?.message,
          icon:'error'
        })
      }else{
        Swal.fire({
          text:'Something went wrong',
          icon:'error'
        })
      }
      dispatch({ type: LOGIN_FAIL });
    }
  };
  // main return
  return (
    <div className="signUpScreen loginScreen">
      <div className="bgSec d-none d-md-inline">
        <div className="centerFlex">
          <img
            src="/assets/image/logout.svg"
            className="stampIcon"
            alt="stamp"
          ></img>
        </div>
        <h1>Welcome back! Let’s get started where you left.</h1>
        <Link to="/">
          <h2><img src="/assets/png/logo.png" width="35px" className="mr-3 white-filter" /> Eddaris</h2>
        </Link>
      </div>
      <div className="contentSec">
        <div className="wrapper">
          <div className="container-fluid">
            <h1>Login</h1>

            <div className="headThree">
              <div className="divider"></div>
              <span>Login with</span>
            </div>
            <div className="flexCenter social">
              <LoginSocialGoogle 
                client_id={process.env.REACT_APP_GOOGLE_CLIENT_ID}
                scope="profile email https://www.googleapis.com/auth/user.birthday.read https://www.googleapis.com/auth/user.gender.read" 
                onResolve={({ provider, data }) => {
                  socialResponseData({
                    email: data.email,
                    register_type: "google"
                  });
                }}
                onReject={(err) => {
                  console.log(err);
                }}
              >
                <button className="mr-3">
                  <img src="/assets/image/googleIcon.svg" alt="google" />
                  <span className="d-none d-md-inline">Google</span>
                </button>
              </LoginSocialGoogle>
              <LoginSocialFacebook
                appId={process.env.REACT_APP_FACEBOOK_ID}
                fieldsProfile={
                  "email"
                }
                onResolve={({ provider, data }) => {
                  socialResponseData({
                    email: data.email,
                    register_type: "facebook"
                  });
                }}
                onReject={(err) => {
                  console.log(err);
                }}
              >
              <button>
                <img src="/assets/image/facebookIcon.svg" alt="facebook" />
                <span className="d-none d-md-inline"> Facebook</span>
              </button>
              </LoginSocialFacebook>
            </div>

            <Formik
              initialValues={{
                email: "",
                password: "",
              }}
              validationSchema={ValidationSchema}
              onSubmit={handleSubmit}
            >
              <Form>
                <Row>
                  <Col md="12">
                    <Field
                      name="email"
                      component={TextInput}
                      placeholder="Enter Email Address"
                      label="Email Address"
                      topclass="ml-2"
                    />
                  </Col>
                  <Col md="12">
                    <Field
                      name="password"
                      component={TextInput}
                      placeholder="Enter Passowrd"
                      label="Password"
                      type="password"
                    />
                    <div className="d-flex align-items-center justify-content-between forgotPass">
                      <Link to="/auth/verify-email">Verify email address</Link>
                      <Link to="/auth/forgot-password">Forgot password?</Link>
                    </div>
                  </Col>
                </Row>
                <div className="flexBetweenCenter buttonSec">
                  <button disabled={loading} type="submit" className="signup">
                    {loading==true ? "Loading..." : "Login"}
                  </button>
                  <button
                    onClick={() => history.push("/sign-up")}
                    type="button"
                    className="login"
                  >
                    Sign up
                  </button>
                </div>
              </Form>
            </Formik>
          </div>
        </div>
      </div>
    </div>
  );
}
