import React,{useEffect,useState} from "react";
import { Dropdown } from "react-bootstrap";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import { getAllWorkshop } from "../../../api";
import { getImageUrl } from "../../../helpers";
const All =  () => {
  const [allWorkshop,srtWorkShop] = useState([]);
  const history = useHistory();
  useEffect(async()=>{
    try{
      const {data} = await getAllWorkshop();
      srtWorkShop(data);
    }
    catch(err){
   
    }
  },[])
  return (
    <section  className="searchPage mb-5">
      <div  className="banner py-4">
        <div  className="basicRow d-flex align-items-center">
          <div  className="searchSec">
            <h1  className="mb-0">Workshops</h1>
          </div>
          <div  className="searchSec btn-sec-bnr d-flex align-items-center ml-auto">
            {/* onClick={()=>history.push('/workshop/me')} */}
            <button type="button"  className="mr-3" >
              My workshop
            </button>
            <button type="button" onClick={()=>history.push('/workshop/add')}>Add a workshop</button>
          </div>
        </div>
      </div>
      <div  className="px-3">
        <div  className="d-flex dropdown-filt align-items-center basicRow pb-0 justify-content-between">
          <div>
            <h5>Total {allWorkshop.length} upcoming workshops</h5>
          </div>
          <Dropdown>
            <Dropdown.Toggle>
              Sort by popularity
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
              <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
              <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
      </div>
      {allWorkshop.map(function (item, i) {
        return (
          <div className="tutorCard mt-5" key={i}>
            <div className="flexCenter headFlex">
              <Link to={`/workshop-detail/${item._id}`}>
                <img
                  src={getImageUrl(item.gallery[0])}
                  alt="Rect"
                   className="profile"
                />
              </Link>
              <div  className="flexBetweenCenter align-items-start content">
                <div  className="details" style={{ flex: "1" }}>
                  <div  className="flexCenter">
                    <Link to={`/workshop-detail/${item._id}`}>
                      <h1 style={{ maxWidth: "500px" }}>
                        {item.title}
                      </h1>
                    </Link>
                  </div>
                  <div
                     className="flexBetweenCenter mt-2 pt-4"
                    style={{ maxWidth: "540px" }}
                  >
                    <div>
                      <p>Date</p>
                      <h2>{DateSettings(item.updatedAt)}</h2>
                    </div>
                    <div  className="ml-2">
                      <p>Language(s)</p>
                      <h2>{item.language_of_workshop}</h2>
                    </div>
                    <div  className="ml-2">
                      <p>Location</p>
                      <h2>{item.online_workshop?"online":""}</h2>
                    </div>
                  </div>
                </div>
                <div  className="priceSec">
                  <h1>${item.price_per_seat}/seat</h1>
                  <div  className="flexBetweenCenter ml-auto">
                    <button  className="primaryButton green px-5">
                      Reserve
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div  className="flexCenter headFlex">
              <div  className="headTwo mt-2">
                <p>77 lessons</p>
              </div>
            </div>
          </div>
        );
      })}
    </section>
  );
};
export const DateSettings = (data) => {
  const date = new Date(data);
  return `${date.getDay()}/${date.getMonth()}/${date.getFullYear()}`
}
export default All;
