import Swal from "sweetalert2";
import * as Yup from "yup";
import AxiosBase from "../../../config/AxiosBase";
const ValidationSchema = Yup.object().shape({
  contact_email: Yup.string()
    .email("Please enter a valid email")
    .min(2, "Too Short! ")
    .max(50, "Too Long!")
    .required("Please enter valid email"),
  phone_number: Yup.number()
    .required("Please enter a phone number")
    .min(8, "Phone number must be upto 8 Charachters"),
  title: Yup.string()
    .required("Please enter a title")
    .min(4, "Title must be upto 4 Charachters"),
  date: Yup.date().required("Please select a date"),
  total_seats_available: Yup.number().required("Please enter available seats"),
  price_per_seat: Yup.number().required("Please enter seat price"),
  language_of_workshop: Yup.string().required(
    "Please Select workshop language"
  ),
  termsAndCondition: Yup.boolean(),
  organizer_name: Yup.string()
    .required("Please enter organizer’s name")
    .min(3, "Organizer’s name must be upto 3 Charachters"),
  contact_name: Yup.string()
    .required("Please enter your name")
    .min(3, "Name must be upto 3 Charachters"),
});
const initialValues = {
  contact_email: "",
  phone_number: "",
  title: "",
  date: "",
  total_seats_available: "",
  price_per_seat: "",
  language_of_workshop: "",
  online_workshop: false,
  organizer_name: "",
  contact_name: "",
  files: [],
};
const rebuildData = (values, gallery) => {
  const formData = {};
  Object.keys(values).forEach((key) => {
    if (
      key == "contact_name" ||
      key == "contact_email" ||
      key == "phone_number"
    ) {
      formData["contact_information"] = {
        ...formData["contact_information"],
        [key]: values[key],
      };
    } else if (key == "files" && gallery.length > 0) {
      formData["files"] = [];
      gallery
        .filter((x) => x.file !== "")
        .map((item, key) => {
          formData["files"][key] = item.file;
        });
    } else {
      formData[key] = values[key];
    }
  });
  return formData;
};

function buildFormData(formData, data, parentKey) {
  if (
    data &&
    typeof data === "object" &&
    !(data instanceof Date) &&
    !(data instanceof File)
  ) {
    Object.keys(data).forEach((key) => {
      buildFormData(
        formData,
        data[key],
        parentKey ? `${parentKey}[${key}]` : key
      );
    });
  } else {
    const value = data == null ? "" : data;
    formData.append(parentKey, value);
  }
}

function jsonToFormData(data) {
  const formData = new FormData();

  buildFormData(formData, data);

  return formData;
}

const handleSubmit = async (formData, gallery) => {
  const form_data = await rebuildData(formData, gallery);
  try {
    const res = await AxiosBase.post(
      "/workshop/create",
      jsonToFormData(form_data)
    );
    Swal.fire({
      position: "center",
      icon: "success",
      text: "Workshop Added Successfully",
      showConfirmButton: false,
      timer: 3000,
    });
  } catch (error) {
    Swal.fire({
      position: "center",
      icon: "error",
      text: error?.response?.data?.message,
      showConfirmButton: false,
      timer: 3000,
    });
  }
};
export { ValidationSchema, initialValues, handleSubmit };
