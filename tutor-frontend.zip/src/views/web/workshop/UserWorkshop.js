import React, { useState, useEffect } from "react";
import { Col, Dropdown } from "react-bootstrap";
import { Link, useParams } from "react-router-dom";
import { default as UUID } from "node-uuid";
import { Label } from "reactstrap";
import { useQuery } from "react-query";
import { getSingleWorkshop } from "../../../api";
import Loading from "../../../components/common/loading";
import { DateSettings } from "./All";
import { getImageUrl } from "../../../helpers";
const UserWorkshop = () => {
  const [tabsNav, setTabsnav] = useState("view");
  const [paramId, setId] = useState(null);
  const { id } = useParams();
  const files_data = [
    { id: UUID.v4(), file: "" },
    { id: UUID.v4(), file: "" },
    { id: UUID.v4(), file: "" },
    { id: UUID.v4(), file: "" },
    { id: UUID.v4(), file: "" },
    { id: UUID.v4(), file: "" },
    { id: UUID.v4(), file: "" },
    { id: UUID.v4(), file: "" },
    { id: UUID.v4(), file: "" },
    { id: UUID.v4(), file: "" },
  ];
  const { data, isLoading } = useQuery(["id", id], getSingleWorkshop, {
    onSuccess: (data) => {
      
    },
    onError: () => {
      
    }
  });
  useEffect(async () => {
    setId(id);
  }, [paramId]);
  return (
    <section className="searchPage mb-0">
      <div className="banner pt-4">
        <div className="basicRow pb-0 d-flex align-items-center">
          <div className="searchSec">
            <h1 className={`${!paramId ? "mb-0" : "mb-4"}`}>Workshops</h1>
            {!paramId ? (
              <ul className="w-100 mb-0 mt-4 navigation-list list-unstyled list-inline">
                <li className="list-inline-item">
                  <button
                    className={`border-0 px-3 ${
                      tabsNav == "view" ? "active" : ""
                    }`}
                    onClick={() => setTabsnav("view")}
                  >
                    View my workshop
                  </button>
                </li>
                <li className="list-inline-item">
                  <button
                    className={`border-0 px-3 ${
                      tabsNav == "registered" ? "active" : ""
                    }`}
                    onClick={() => setTabsnav("registered")}
                  >
                    Registered users
                  </button>
                </li>
              </ul>
            ) : (
              ""
            )}
          </div>
        </div>
      </div>
      {isLoading?<Loading height="80vh" />:null}
      {!isLoading && data?.data?
        <div className="basicRow">
          {tabsNav == "view" ? (
            <div>
              <div className="d-flex beg_line px-4 py-3 align-items-center">
                <h6 className="mb-0">Begin online workshop</h6>
                <button
                  className="primaryButton mt-0 ml-auto"
                  style={{ padding: "11px 36px" }}
                >
                  Start workshop
                </button>
              </div>
              <div className="tutorCard mt-5">
                <div className="flexCenter align-items-start headFlex">
                  <div>
                    <img
                      src={
                        data?.data?.gallery?.length>0
                        ? getImageUrl(data?.data?.gallery[0])
                        : "/assets/image/defaultProfile.svg"
                      }
                      alt="Rect"
                      className="profile"
                    />
                    <div className="flexCenter headFlex">
                      <div className="headTwo mt-2">
                        <p>77 lessons</p>
                      </div>
                    </div>
                  </div>
                  <div className="flexBetweenCenter align-items-start content">
                    <div className="details" style={{ flex: "1" }}>
                      <div className="flexCenter">
                        <h1 style={{ maxWidth: "500px" }}>{data.data.title}</h1>
                      </div>
                      <div
                        className="flexBetweenCenter mt-2 pt-4"
                        style={{ maxWidth: "450px" }}
                      >
                        <Col lg={6} className="pl-0">
                          <p>Date</p>
                          <h2>{DateSettings(data.data.updatedAt)}</h2>
                        </Col>
                        <Col lg={6} className="p-0">
                          <p>Location</p>
                          <h2>{data.data.online_workshop ? "online" : ""}</h2>
                        </Col>
                      </div>
                      <div
                        className="flexBetweenCenter mt-2 pt-4"
                        style={{ maxWidth: "450px" }}
                      >
                        <Col lg={6} className="pl-0">
                          <p>Language(s)</p>
                          <h2>{data.data.language_of_workshop}</h2>
                        </Col>
                        <Col lg={6} className="p-0">
                          <p>Organized by</p>
                          <h2>{data.data.organizer_name}</h2>
                        </Col>
                      </div>
                      <div className="mt-2 pt-4" style={{ maxWidth: "550px" }}>
                        <p>Description</p>
                        <h2 className="mt-1" style={{ fontSize: "14px" }}>
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit. Arcu purus nullam orci senectus porttitor
                          consectetur. Sit sociis turpis proin interdum ac ipsum
                          eu. Mattis suspendisse dictum lectus mattis ut nunc
                          non. Egestas faucibus in semper duis consequat et
                          tincidunt.
                        </h2>
                        <p className="mb-3 mt-3">Gallery</p>
                        <div className={`d-flex ${paramId?"justify-content-start":"justify-content-between"} flex-wrap`}>
                          {!paramId
                            ? files_data.map((item, key) => {
                                return (
                                  <div key={key}>
                                    <label
                                      className="border-file d-flex align-items-center 
                                    justify-content-center"
                                    >
                                      <input className="d-none" type="file" />
                                      <img
                                        src="/assets/image/plus.svg"
                                        width="12px"
                                        alt="plus"
                                      />
                                    </label>
                                  </div>
                                );
                              })
                            : null}
                          {paramId?data.data.gallery.map((item, key) => {
                            return (
                              <label className="border-file mr-3 overflow-hidden border-0">
                                <img
                                  src={getImageUrl(item)}
                                  alt={data.data.title}
                                  className="h-100 w-100"
                                  style={{objectFit:"cover"}}
                                />
                              </label>
                              );
                            })
                          : null}
                        </div>
                        <div
                          className="flexBetweenCenter mt-2 pt-4"
                          style={{ maxWidth: "450px" }}
                        >
                          <h5 className="w-100 mb-3">Contact information</h5>
                          <Col lg={6} className="pl-0 mb-3">
                            <p>Name</p>
                            <h2>
                              {data.data.contact_information.contact_name}
                            </h2>
                          </Col>
                          <Col lg={6} className="p-0 mb-3">
                            <p>Email address</p>
                            <h2>
                              {data.data.contact_information.contact_email}
                            </h2>
                          </Col>
                          <Col lg={6} className="p-0">
                            <p>Phone number</p>
                            <h2>
                              {data.data.contact_information.phone_number}
                            </h2>
                          </Col>
                        </div>
                      </div>
                    </div>
                    <div className="priceSec">
                      <h1>${data.data.price_per_seat}/seat</h1>
                      <div className="flexBetweenCenter ml-auto">
                        <button className="primaryButton green px-5">
                          <img
                            src="/assets/image/editKidIcon.svg"
                            className="mr-2 white-filter"
                          />{" "}
                          Edit
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="dropdown-filt pb-3">
                <h5 style={{ fontSize: "14px" }}>Total 5 upcoming workshops</h5>
              </div>
              {Array.apply(0, Array(5)).map(function (x, i) {
                return (
                  <div
                    className="d-flex list__data__work flex-wrap align-items-center justify-content-between"
                    key={i}
                  >
                    <h6>{i + 1}.&nbsp;abcusername@email.com</h6>
                    <i>payment processed</i>
                  </div>
                );
              })}
            </>
          )}
        </div>
      :<h4 class="my-4 text-danger text-center">NO Record Found</h4>}
    </section>
  );
};
export default UserWorkshop;
