import React,{useState,useEffect} from "react";
import { Formik, Form, Field  } from "formik";
import { Col, Label, Row } from "reactstrap";
import {ValidationSchema,initialValues , handleSubmit} from './Validation'
import { Link } from "react-router-dom";
import { SelectInput, TextInput , ChechBoxInput } from "../../../components/basic/RenderInputs";
import "../login/login.css";
import {default as UUID} from "node-uuid";
export default function Add() {
  const files_data = [
    {id:UUID.v4(),file:"",url:""},
    {id:UUID.v4(),file:"",url:""},
    {id:UUID.v4(),file:"",url:""},
    {id:UUID.v4(),file:"",url:""},
    {id:UUID.v4(),file:"",url:""},
    {id:UUID.v4(),file:"",url:""},
    {id:UUID.v4(),file:"",url:""},
    {id:UUID.v4(),file:"",url:""},
    {id:UUID.v4(),file:"",url:""},
    {id:UUID.v4(),file:"",url:""}
  ]
  const [gallery, setGallery] = useState(files_data);
  const setDataUrl = (e,id) =>
  {
    const fr = new FileReader()
    const file = e.target['files'][0];
    fr.readAsArrayBuffer(file)
    fr.onload = function() {
      const blob = new Blob([fr.result])
      const url = URL.createObjectURL(blob, {type: "image/png"});
      setGallery((prev) =>
        prev.reduce((acc, curr) => {
          if (curr.id == id) {
            return [
              ...acc,
              {
                ...curr,
                url:url,
                file:file
              },
            ];
          }
          return [...acc, curr];
        }, [])
      );
    }
  }
  const languages = [
    {text:"English",value:"english"},
    {text:"Arabic",value:"arabic"}
  ]
  // main return
  return (
    <div  className="signUpScreen loginScreen">
      <div  className="bgSec d-none d-md-inline">
        <div  className="centerFlex">
          <img
            src="/assets/image/workshop.svg"
             className="stampIcon"
            alt="workshop"
          ></img>
        </div>
        <h1>Workshops are a greate way to lorem ipsum</h1>

        <h2>tutorservice</h2>
      </div>
      <div  className="contentSec">
        <div  className="wrapper">
          <div  className="container-fluid">
            <h1>Add workshop</h1>
            <Formik
              initialValues={initialValues}
              validationSchema={ValidationSchema}
              onSubmit={(e)=>handleSubmit(e,gallery)}
            >
              <Form>
                <Row>
                  <Col md="12">
                    <Field
                      name="title"
                      component={TextInput}
                      placeholder="Enter title"
                      label="Title"
                      topclass="ml-2"
                    />
                    <Field
                      name="date"
                      component={TextInput}
                      placeholder="Enter Date"
                      label="Date"
                      type="date"
                    />
                    <Field
                      name="total_seats_available"
                      component={TextInput}
                      placeholder="Enter total seats available"
                      label="Total seats available"
                      type="number"
                    />
                    <Field
                      name="price_per_seat"
                      component={TextInput}
                      placeholder="Enter price per seat"
                      label="Price per seat"
                      type="number"
                    />
                    <Label  className="label">Language of workshop</Label>
                    <Field
                      component={SelectInput}
                      name="language_of_workshop"
                      placeholder="Language of workshop"
                      options={languages}
                      type="select"
                    />
                    <Field
                      id="online_workshop"
                      name="online_workshop"
                      component={ChechBoxInput}
                      label={`Workshop will be online.`}
                      type="password"
                      topclass="ml-2"
                    />
                    <div  className="mt-4">
                      <Field
                        name="organizer_name"
                        component={TextInput}
                        placeholder="Enter organizer’s name"
                        label="Organizer’s name"
                        type="text"
                      />
                    </div>
                    <div className="mt-3">
                        <Label  className="label">Gallery</Label>
                        <div  className="d-flex justify-content-between flex-wrap">
                          {gallery.map((item,key) => {
                            return(
                              <div key={key}>
                                <label  className={`border-file overflow-hidden ${item.url==""?"":"border-0"} d-flex align-items-center 
                                  justify-content-center`} type="button">
                                  {item.url==""?
                                    <>
                                      <img src="/assets/image/plus.svg" width="12px" alt="plus" />
                                    </>
                                  :<img src={item.url} width="100%" height="100%" style={{objectFit:"cover"}} />
                                  }  
                                  <input className="d-none" name={`files[${key}]`}  accept="image/*" disabled={item.url!==""?true:false} type="file" onChange={(e)=>setDataUrl(e,item.id)} />
                                </label>
                              </div>
                            )
                          })}
                        </div>
                    </div>
                  </Col>
                </Row>
                <div>
                  <h5 className="mt-2">Contact information</h5>
                  <p  className="mt-2 mb-4">
                    The information will be used by the user if they have any query 
                    regarding the workshop or our management for verification purposes.
                  </p>
                  <Field
                    name="contact_name"
                    component={TextInput}
                    placeholder="Enter Name"
                    label="Name"
                    topclass="ml-2"
                    type="text"
                  />
                  <Field
                    name="contact_email"
                    component={TextInput}
                    placeholder="Email address"
                    label="Email"
                    topclass="ml-2"
                    type="text"
                  />
                  <Field
                    name="phone_number"
                    component={TextInput}
                    placeholder="Phone number"
                    label="Phone number"
                    topclass="ml-2"
                    type="text"
                  />
                </div>
                <div  className="flexBetweenCenter buttonSec">
                  <button type="submit"  className="signup w-100">
                    Create
                  </button>
                </div>
              </Form>
            </Formik>
          </div>
        </div>
      </div>
    </div>
  );
}
