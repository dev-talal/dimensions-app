import React, { useEffect, useState } from "react";
import { useQuery } from "react-query";
import { useHistory, useLocation } from "react-router";
import StarRatings from "react-star-ratings";
import { getProfileById } from "../../../api";
import Loading from "../../../components/common/loading";
import Booking from "../../../components/web/booking/booking";
import About from "../../../components/web/profile/About";
import Gallery from "../../../components/web/profile/Gallery";
import Pricing from "../../../components/web/profile/Pricing";
import Reviews from "../../../components/web/profile/Reviews";
import Schedule from "../../../components/web/profile/Schedule";
import { ETeach_Type } from "../../../enums/tutor";
import { getImageUrl } from "../../../helpers";
import history from "../../../helpers/history";
import "./profile.css";
import styled from 'styled-components';
export default function Profile(props) {
  // state
  const [activeTab, setActiveTab] = useState("About");
  const [openModal, setOpenModal] = useState(false);
  const [selectedPackage, setSelectedPackage] = useState({});
  const [slotId, setSlotId] = useState(null);
  const [slotTime, setSlotTime] = useState(null);
  const navTabs = [
    { name: "About", Component: About },
    { name: "Gallery", Component: Gallery },
    { name: "Reviews", Component: Reviews },
    { name: "Pricing", Component: Pricing },
    { name: "Schedule", Component: Schedule },
  ];

  // params
  const id = props.match.params.id;

  // fetching single profile
  const { data, isLoading } = useQuery(["profile", id], getProfileById, {
    onSuccess: (data) => {
      if (Object.keys(selectedPackage).length < 1) {
        setSelectedPackage((prev) => {
          return { ...prev, time: data?.data?.schedule?.class_time[0].time };
        });
      }
    },
  });
  const profile = data?.data;
  const pricingArr =
    profile?.schedule?.class_time.length > 0
      ? profile?.schedule?.class_time
      : null;

  const onPriceSelect = (name, price, bookingNumbers, time) => {
    setSelectedPackage({
      name,
      price,
      no_of_booking: bookingNumbers,
      time: time ? time : data?.data?.schedule?.class_time[0].time,
    });
    setActiveTab("Schedule");
  };
  useEffect(()=>{
    window.scrollTo(0,0);
  },[])
  // main return
  return (
    <main  className="basicRow profileDetails">
      {isLoading && <Loading height="60vh" />}
      {isLoading || (
        <div  className="container-fluid">
          <div  className="row head">
            <div  className="col-md-3">
              <div  className="backBtn pointer" onClick={() => history.goBack()}>
                <img
                  src="/assets/image/backArrow.svg"
                  alt="arrow"
                   className="mr-2"
                />
                <span>Back</span>
              </div>
            </div>
            <div  className="col-md-9 flexBetweenCenter pl-md-4 pl-xl-5">
              <button  className="actionBtn">
                <img
                  src="/assets/image/shareIcon.svg"
                  alt="arrow"
                  className="mr-2"
                />
                <span>Share</span>
              </button>
              <button  className="actionBtn">
                <img
                  src="/assets/image/favIcon.svg"
                  alt="arrow"
                   className="mr-2"
                />
                <span>Favourite</span>
              </button>
            </div>
          </div>
          <section  className="row">
            <div  className="col-md-3 details">
              <div style={{maxWidth:"299px"}}>
                <div  className="centerFlex w-100 position-relative">
                  <UserStatus>
                    <div className="status-dot active"></div>&nbsp;Online
                  </UserStatus>
                  <img
                    src={
                      profile?.user_id?.profile_picture
                        ? getImageUrl(profile?.user_id?.profile_picture)
                        : "/assets/image/defaultProfile.svg"
                    }
                    alt="arrow"
                    className="profile"
                    style={{maxWidth: "initial"}}
                  />
                </div>
                <h5 className="text-left">{profile?.intro}</h5>
                <div className="d-flex justify-content-between">
                  <div>
                    <h5 className="mb-0 text-left mt-0" style={{fontSize:"14px",fontWeight:"700",fontFamily:"poppinsBd"}}>Response rate</h5>
                    <p className="mb-0 mt-1" style={{fontSize:"13px",color:"#C8C8C8"}}>(excluding weekends)</p>
                  </div>
                  <h3 className="mb-0" style={{fontSize:"14px",fontWeight:"700",fontFamily:"poppinsBd"}}>2hrs</h3>
                </div>
                {/* <div  className="flexBetweenCenter">
                  <h4>Response rate</h4>
                  <h4>2 hrs</h4>
                </div>
                <p>(excluding weekends)</p> */}
                {profile?.teach_language.length > 0 && (
                  <div  className="title">Lesson language(s) </div>
                )}
                <div  className="flexCenter">
                  {profile?.teach_language?.map((item, index) => {
                    return (
                      <div key={index}  className="tag">
                        {item}
                      </div>
                    );
                  })}
                </div>
                {profile?.schedule?.book_class?.length > 0 && (
                  <div  className="title">Service venue </div>
                )}
                <div  className="flexCenter">
                  {profile?.schedule?.book_class?.map((item, index) => {
                    return (
                      <div key={index}  className="tag">
                        {item === ETeach_Type.TUTOR_HOME
                          ? "At tutor’s home"
                          : item === ETeach_Type.STUDENT_HOME
                          ? "At your home"
                          : item}
                      </div>
                    );
                  })}
                </div>
                {profile?.main_field && <div  className="title">Field </div>}
                {profile?.main_field && (
                  <div  className="tag">{profile?.main_field}</div>
                )}
                {profile?.you_teach.length > 0 && (
                  <div  className="title">Teaches </div>
                )}
                <div  className="flexCenter">
                  {profile?.you_teach?.map((item, index) => {
                    return (
                      <div key={index}  className="tag">
                        {item}
                      </div>
                    );
                  })}
                </div>
                {profile?.level_you_teach.length > 0 && (
                  <div  className="title">Levels </div>
                )}
                <div  className="flexCenter">
                  {profile?.level_you_teach?.map((item, index) => {
                    return (
                      <div key={index}  className="tag">
                        {item}
                      </div>
                    );
                  })}
                </div>
                {profile?.student_age_you_teach.length > 0 && (
                  <div  className="title">Students age teachable </div>
                )}
                <div  className="flexCenter">
                  {profile?.student_age_you_teach?.map((item, index) => {
                    return (
                      <div key={index}  className="tag">
                        {item.from_age} - {item.to_age}
                      </div>
                    );
                  })}
                </div>
                {profile?.class_type.length > 0 && (
                  <div  className="title">Class type </div>
                )}
                <div  className="flexCenter">
                  {profile?.class_type?.map((item, index) => {
                    return (
                      <div key={index}  className="tag">
                        {item === "class" ? "1 to 1" : "Group lesson"}
                      </div>
                    );
                  })}{" "}
                </div>
              </div>
            </div>
            <div  className="col-md-9 pl-md-4 pl-xl-5">
              <div  className="flexBetweenCenter profileHead">
                <div  className="">
                  <h1  className="title" style={{fontSize:"28px"}}>
                    {profile?.user_id?.first_name} {profile?.user_id?.last_name}
                  </h1>
                  <p>Riyadh, Saudi Arabia.</p>
                  <div  className="flexCenter">
                    <StarRatings
                      rating={profile.rating}
                      starRatedColor="#EFC282"
                      numberOfStars={5}
                      starDimension="32px"
                      starSpacing="1px"
                      name="rating"
                    />
                    <span
                       className="textGrey ml-2"
                      style={{ fontSize: "18px" }}
                    >
                      {profile.reviews.length}
                    </span>
                  </div>
                </div>
                <div>
                  <h1  className="title">
                    {pricingArr ? (
                      <h1 style={{fontSize:"28px"}}>
                        ${pricingArr[0].price}/{pricingArr[0].time} min
                      </h1>
                    ) : (
                      <h1>NA</h1>
                    )}
                  </h1>
                  <div className="w-fit-content mt-2">
                    <button  className="primaryButton green w-100 mt-2" onClick={()=>setActiveTab("Schedule")}>
                      Schedule lesson
                    </button>
                    <br />
                    <button  className="primaryButton outline mt-3">
                      Send a message
                    </button>
                  </div>
                </div>
              </div>

              <section  className="tabSection">
                <nav>
                  {navTabs.map((item, index) => {
                    return (
                      <div
                        key={index}
                         className={
                          activeTab === item.name ? "tab active" : "tab"
                        }
                        onClick={() => setActiveTab(item.name)}
                      >
                        {item.name}
                      </div>
                    );
                  })}
                </nav>
                {navTabs.map(({ name, Component }) => {
                  return activeTab === name ? (
                    <Component
                      data={profile}
                      onPriceSelect={onPriceSelect}
                      selectedPackage={selectedPackage}
                      setActiveTab={setActiveTab}
                      setOpenModal={setOpenModal}
                      setSlotId={setSlotId}
                      setSlotTime={setSlotTime}
                    />
                  ) : null;
                })}
              </section>
            </div>
          </section>
        </div>
      )}
      {openModal && (
        <Booking
          handleModal={setOpenModal}
          data={profile}
          selectedPackage={selectedPackage}
          slotId={slotId}
          slotTime={slotTime}
        />
      )}
    </main>
  );
}
const UserStatus = styled.div`
 position:absolute;
 top: 6px;
 right: 6px;
 background: #FFFFFF;
  box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.15);
  border-radius: 7px;
  padding:3px 10px;
  font-size:11px;
  color: #0A0D31;
  display:flex;
  align-items:center;
  .status-dot{
    border-radius:50%;
    width:10px;
    height:10px;
    &.active{
      background-color: #00FF6A;
    }
  }
`