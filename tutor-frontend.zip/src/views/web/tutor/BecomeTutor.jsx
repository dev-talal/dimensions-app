import React from "react";
import { Col, Row } from "react-bootstrap";

const BecomeTutor = () => {
  return (
    <>
      <div className="basicRow pb-0">
        <div className="px-4 px-lg-5">
          <Row className="align-items-center">
            <Col lg={6} className="mb-4">
              <img
                src="/assets/png/group-layer.png"
                className="img-fluid"
                alt="group layer"
              />
            </Col>
            <Col lg={6} className="mb-4">
              <div
                className="contact-details px-3"
                style={{ maxWidth: "100%", color: "#C8C8C8" }}
              >
                <h5>
                  Become a
                  <br />
                  tutor
                </h5>
                <span className="d-block mt-2">
                 Are you an expert in any field? Are you passionate about something? You’ve come to the right place. With Eddaris you can share your knowledge with students and earn money by doing so.
                </span>
                <button className="banner__btn w-100 mt-4" type="button">
                  Let’s get started
                </button>
              </div>
            </Col>
          </Row>
        </div>
      </div>
      <div className="position-relative circle-layer-before py-5">
        <div className="basicRow my-0 py-0">
          <Row className="px-4 px-lg-5 align-items-center">
            <Col lg={6} className="mb-5">
              <h5 className="trusted-dt-text mb-0">
                Trusted by 10,000+
                <br />
                tutors worldwide
              </h5>
            </Col>
            <Col lg={6} className="mb-5">
              <Row>
                <Col lg={6}>
                  <div className="text-center trusted-dt">
                    <img
                      src="/assets/image/money-from-bracket-light1.svg"
                      height="100px"
                    />
                    <span className="d-block mt-3">
                      Cash in on your expertise
                    </span>
                  </div>
                </Col>
                <Col lg={6}>
                  <div className="text-center trusted-dt">
                    <img
                      src="/assets/image/calendar-range-light1.svg"
                      height="100px"
                    />
                    <span className="d-block mt-3">Set your own schedule</span>
                  </div>
                </Col>
              </Row>
            </Col>
          </Row>
        </div>
      </div>
      <div
        className="circle-layer-before"
        style={{
          backgroundSize: " 200px",
          backgroundPosition: " left bottom 350px",
        }}
      >
        <div
          className="circle-layer-before right"
          style={{
            backgroundSize: " 200px",
            backgroundPosition: " right center",
          }}
        >
          <div className="basicRow my-0 py-0 mb-5">
            <Row className="px-4 px-lg-5 align-items-center">
              <Col lg={6} className="mb-5 pr-lg-5">
                <img src="/assets/png/object.png" className="img-fluid" />
              </Col>
              <Col lg={6} className="mb-5">
                <div
                  className="contact-details pr-lg-5"
                  style={{ maxWidth: "100%", color: "#C8C8C8" }}
                >
                  <h5 className="pr-lg-5 trusted-dt-text">How it works</h5>
                  <span className="d-block mt-2 pr-lg-5">
                    You can easily find students who are interested in the topic you teach. Our platform connects students and tutors. Students can schedule sessions in advance either physically or virtually.
                  </span>
                </div>
              </Col>
              <Col xs={12} className="mt-4">
                <Col lg={6} className="px-0">
                  <div
                    className="contact-details pr-lg-5"
                    style={{ maxWidth: "100%", color: "#C8C8C8" }}
                  >
                    <h5 className="pr-lg-5 trusted-dt-text">1.Registration</h5>
                    <span className="d-block mt-2 pr-lg-5">
                      Sign up as a tutor and fill in your profile details. Choose one of our subscription models.  
                    </span>
                  </div>
                </Col>
              </Col>
              <Col xs={12} className="mt-4">
                <Col lg={6} className="px-0 ml-auto">
                  <div
                    className="contact-details pr-lg-5"
                    style={{ maxWidth: "100%", color: "#C8C8C8" }}
                  >
                    <h5 className="pr-lg-5 trusted-dt-text">
                      2.Get approved
                    </h5>
                    <span className="d-block mt-2 pr-lg-5">
                      If all requirements are met, our team will contact you shortly after verifying your profile.
                    </span>
                  </div>
                </Col>
              </Col>
              <Col xs={12} className="mt-4">
                <Col lg={6} className="px-0">
                  <div
                    className="contact-details pr-lg-5"
                    style={{ maxWidth: "100%", color: "#C8C8C8" }}
                  >
                    <h5 className="pr-lg-5 trusted-dt-text">
                      3. Set your schedule 
                    </h5>
                    <span className="d-block mt-2 pr-lg-5">
                      With a click of a button, you have full control over your schedule, prices, and teaching methodology. 
                    </span>
                  </div>
                </Col>
              </Col>
              <Col xs={12} className="mt-4">
                <Col lg={6} className="px-0 ml-auto">
                  <div
                    className="contact-details pr-lg-5"
                    style={{ maxWidth: "100%", color: "#C8C8C8" }}
                  >
                    <h5 className="pr-lg-5 trusted-dt-text">
                      4. Start tutoring
                    </h5>
                    <span className="d-block mt-2 pr-lg-5">
                      Students will contact you once your profile has been published. We are here to assist you if you have any inquiries.
                    </span>
                  </div>
                </Col>
              </Col>
            </Row>
            <Row className="px-4 pt-4 px-lg-5 align-items-center">
              <Col lg={7} className="mt-5">
                <div
                  className="contact-details pr-lg-5"
                  style={{ maxWidth: "100%", color: "#C8C8C8" }}
                >
                  <h5 className="pr-lg-5 trusted-dt-text">Our Online Classroom</h5>
                  <span className="d-block mt-2 pr-lg-5">
                    Our online classroom removes geographical barriers by allowing video conferencing, online chat, uploading documents, and screen sharing. It allows tutors flexibility as well as saving commuting time and cost. 
                  </span>
                </div>
              </Col>
              <Col lg={5} className="mt-5 pr-lg-5">
                <div className="pr-lg-5">
                  <img src="/assets/png/classroom.png" className="img-fluid" />
                </div>
              </Col>
              <Col xs={6} className="mx-auto mt-5 mb-4">
                <button className="banner__btn w-100 mt-4" type="button">
                  Let’s get started
                </button>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    </>
  );
};

export default BecomeTutor;
