import React, { useRef, useState } from "react";
import { useSelector } from "react-redux";
import Swal from "sweetalert2";
import AboutSec from "../../../components/setting/AboutSec";
import ChangePassword from "../../../components/setting/ChangePassword";
import MyKids from "../../../components/setting/MyKids";
import PaymentMethod from "../../../components/setting/PaymentMethod";
import PersonalInformation from "../../../components/setting/PersonalInformation";
import SettingAccordion from "../../../components/setting/settingAccordion";
import BackgroundCheck from "../../../components/setting/tutor/backgroundCheck";
import BankInfromation from "../../../components/setting/tutor/bankInformation";
import FeaturedListing from "../../../components/setting/tutor/featuredProfile";
import Gallery from "../../../components/setting/tutor/Gallery";
import Highlights from "../../../components/setting/tutor/Highlights";
import Pricing from "../../../components/web/profileSetup/Pricing";
import Subscriptions from "../../../components/setting/tutor/subscriptions";
import TutorAboutSec from "../../../components/setting/tutor/TutorAboutSec";
import AxiosBase from "../../../config/AxiosBase";
import { EUserType } from "../../../enums/user.enum";
import { getImageUrl } from "../../../helpers";
import { initFormState } from "../../web/profileSetup/constant";
import "./setting.css";

export default function Setting() {
  // state
  const [fileError, setFileError] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [loading, setloading] = useState(false);
  const { user } = useSelector((state) => state.auth);
  const userType = user?.user_type;
  const isTutor = userType === EUserType.TUTOR;
  const isIndividual = userType === EUserType.INDIVIDUAL;
  const profile = user?.profile;
  console.log({ profile });

  // profileInputRef
  const profileInputRef = useRef(null);
  // trigger file input
  const triggerInput = () => {
    profileInputRef.current.click();
  };
  // on Profile Change
  const onProfileChange = (e) => {
    if (e.target.files.length > 0) {
      setFileError((prev) => (prev ? null : prev));
      setFilePreview(URL.createObjectURL(e.target.files[0]));
      uploadProfile(e.target.files[0]);
    } else return;
  };

  // upload profile
  const uploadProfile = async (file) => {
    const formData = new FormData();
    formData.append("image", file, "profile pitcure");
    await AxiosBase.put("/auth/update-profile-pic", formData);
    Swal.fire({
      position: "center",
      icon: "success",
      title: "Profile Update !",
      showConfirmButton: false,
      timer: 2000,
    });
  };

  // update profile
  const updateProfile = async (data) => {
    setloading(true);
    try {
      await AxiosBase.put(
        userType === "tutor"
          ? "/tutor/update-profile"
          : "/parent/update-profile",
        data
      );
      Swal.fire({
        position: "center",
        icon: "success",
        title: "Profile Update !",
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (error) {
      Swal.fire({
        position: "center",
        icon: "error",
        title: "Profile Update !",
        text: error?.response?.data?.message,
        showConfirmButton: false,
        timer: 2000,
      });
    }
    setloading(false);
  };

  // update profile
  const updatePassword = async (data) => {
    setloading(true);
    try {
      await AxiosBase.put("/auth/update-password-from-profile", data);
      Swal.fire({
        position: "center",
        icon: "success",
        title: "Profile Update !",
        showConfirmButton: false,
        timer: 2000,
      });
    } catch (error) {
      Swal.fire({
        position: "center",
        icon: "error",
        title: "Profile Update !",
        text: error?.response?.data?.message,
        showConfirmButton: false,
        timer: 2000,
      });
    }
    setloading(false);
  };

  // main return
  return (
    <div  className="profileSetting mx-auto" style={{maxWidth:"1010px"}}>
      <h1  className="title">My profile</h1>
      <div  className="flexCenter profileHeader">
        <img
          src={
            filePreview
              ? filePreview
              : user?.profile_pic
              ? getImageUrl(user?.profile_pic)
              : "/assets/image/defaultKidProfile.svg"
          }
          alt="profile"
        ></img>

        <div>
          <button onClick={triggerInput}  className="primaryButton green mt-0">
            Upload profile picture
          </button>
          {fileError && <div  className="errorText">{fileError} </div>}
        </div>
        <input
          ref={profileInputRef}
          onChange={onProfileChange}
          type="file"
           className="d-none"
        />
      </div>
      {isTutor ? (
        <TutorAboutSec
          data={profile}
          user={user}
          loading={loading}
          updateProfile={updateProfile}
        />
      ) : (
        <AboutSec
          data={profile}
          user={user}
          loading={loading}
          updateProfile={updateProfile}
          isIndividual={isIndividual}
        />
      )}
        {isTutor &&
        <SettingAccordion label="Pricing">
          <Pricing prev={true} formState={initFormState} />
        </SettingAccordion>
      }
      {isTutor || isIndividual || (
        <MyKids
          data={profile}
          user={user}
          loading={loading}
          updateProfile={updateProfile}
        />
      )}
      {isTutor && (
        <Highlights
          data={profile}
          loading={loading}
          updateProfile={updateProfile}
        />
      )}
      {isTutor && (
        <Gallery
          data={profile}
          loading={loading}
          updateProfile={updateProfile}
        />
      )}
      <PersonalInformation
        data={profile}
        user={user}
        loading={loading}
        isTutor={isTutor}
        updateProfile={updateProfile}
      />
      {isTutor && <BackgroundCheck />}
      {isTutor && (
        <BankInfromation
          data={profile}
          loading={loading}
          updateProfile={updateProfile}
        />
      )}
      <ChangePassword loading={loading} updateProfile={updatePassword} />
      {isTutor && <Subscriptions />}
      {isTutor && <FeaturedListing />}
      <PaymentMethod />
    </div>
  );
}
