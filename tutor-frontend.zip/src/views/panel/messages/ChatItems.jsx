import React, { useEffect, useRef, useState } from "react";
import { Mailbox } from "react-bootstrap-icons";
import { Form, Spinner } from "react-bootstrap";
import { useSelector } from "react-redux";
import styled from "styled-components";
import { updateChatRoomApi } from "../../../api";
import MessageDiv from "./MessageDiv";

const ChatItems = ({ active, back, client, username }) => {
  const { user } = useSelector((state) => state.auth);

  const [fileMessage, setFileMessage] = useState(null);
  const [messageText, setMessageText] = useState("");
  const [messages, setMessages] = useState([]);
  const [typing, setTyping] = useState(false);
  const [loader, setLoader] = useState(false);
  const event = new Event("unMount");

  const channelRef = useRef(null);

  const roomId = active?._id;
  const userId = user?._id;

  const messageEndRef = useRef();

  // create channle  if not or join
  const joinChannel = async (chatClient) => {
    return new Promise((resolve, reject) => {
      chatClient
        .getSubscribedChannels()
        .then(() => {
          chatClient
            .getChannelByUniqueName(roomId)
            .then(async (channel) => {
              channelRef.current = channel;

              channel
                .join()
                .then(async () => {
                  const previousMessages = await channel.getMessages();

                  setMessages(previousMessages?.items);
                  setLoader(false);
                  scrollToBottom();

                  window.addEventListener("beforeunload", () =>
                    channel.leave()
                  );
                  window.addEventListener(
                    "unMount",
                    () => {
                      try {
                        channel.leave();
                      } catch (error) {
                        console.log(error);
                      }
                    },
                    false
                  );
                })
                .catch((error) => {
                  console.log(error);
                  console.log("Could not join channel.");
                });
              resolve(channel);
            })
            .catch(() => createNewChannel(chatClient));
        })
        .catch(() => console.log("Could not get channel list."));
    });
  };

  // join channel
  const createNewChannel = async (chatClient) => {
    return new Promise((resolve, reject) => {
      chatClient
        .createChannel({ uniqueName: roomId, friendlyName: roomId })
        .then(() => joinChannel(chatClient))
        .then(configureChannelEvents)
        .catch(() => console.log("Could not create new channel"));
    });
  };

  const handleMessageAdded = (message) => {
    setMessages((prev) => [...prev, message]);
    scrollToBottom();
  };

  const configureChannelEvents = (channel) => {
    channel.on("messageAdded", (message) => {
      handleMessageAdded(message);
    });

    // Listen for members typing
    channel.on("typingStarted", function () {
      setTyping(true);
      scrollToBottom();
    });

    // Listen for members typing
    channel.on("typingEnded", function () {
      setTyping(false);
    });
  };

  // initiallize
  useEffect(() => {
    if (client) {
      setLoader(true);
      joinChannel(client)
        .then(configureChannelEvents)
        .catch((error) => {
          console.log(error.message);
        });

      return () => {
        channelRef.current?.leave();
        window.dispatchEvent(event);
        setMessages([]);
      };
    }
  }, [active, client]);

  // scroll to bottom
  const scrollToBottom = () => {
    const doc = document.getElementById("messageEndRef");
    doc.scrollTop = doc.scrollHeight;
  };

  // send a message to convo
  const onMessageSend = async (e) => {
    e.preventDefault();
    if (!messageText && !fileMessage) return;
    const formData = new FormData();
    if (fileMessage !== null) {
      formData.append("file", fileMessage);
    }
    try {
      if (channelRef.current) {
        channelRef.current.sendMessage(
          fileMessage !== null ? formData : messageText
        );
        await updateChatRoomApi({
          id: roomId,
          data: { new: [userId] }
        });
      }
      setMessageText("");
      setFileMessage(null);
      scrollToBottom();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      {loader && (
        <div className="text-center my-4">
          <Spinner animation="border" variant="info" role="status">
            <span className="visually-hidden"></span>
          </Spinner>
        </div>
      )}
      <div className="inner-message-sec">
        {messages ? (
          <>
            {messages?.map((item, key) => {
              return (
                <div className="mb-3">
                  <MessageDiv message={item} userId={userId} key={key} />
                </div>
              );
            })}
            {typing && (
              <div
                className="message-text"
                style={{ width: "fit-content", paddingLeft: "20px" }}>
                {username} Typing ...
              </div>
            )}
          </>
        ) : (
          <h5
            className="text-danger text-center"
            style={{
              fontSize: "17px",
              fontWeight: 600
            }}>
            <div className="mb-3">
              <Mailbox size={50} />
            </div>
            No chat found
          </h5>
        )}
        <div id="messageEndRef" ref={messageEndRef}></div>
      </div>
      <MessageFooter className="chat-sec-footer">
        <div className="position-relative area-field-box">
          {fileMessage === null ? (
            <textarea
              onChange={(e) => {
                setMessageText(e.target.value);
                channelRef.current.typing();
              }}
              value={messageText}
              className="border-0 w-100"
              placeholder="Type message here..."
              onKeyUp={(e) => e.key === "Enter" && onMessageSend(e)}></textarea>
          ) : (
            <div>
              <span> {fileMessage?.name}</span>
            </div>
          )}

          <div className="align-items-center msg-actions-group d-flex">
            <label className="mb-0 file-label mr-3">
              <Form
                as="input"
                type="file"
                className="d-none"
                onChange={(e) => setFileMessage(e.target.files[0])}
                onKeyUp={(e) => e.key === "Enter" && onMessageSend(e)}
              />
              Attach a File
            </label>
            <button type="button" className="border-0" onClick={onMessageSend}>
              Send
            </button>
          </div>
        </div>
      </MessageFooter>
    </>
  );
};

const MessageTile = styled.div`
  max-width: 422px;
  border: 1px solid #e7e7e9;
  padding: 15px;
  border-radius: 8px;
  font-family: PoppinsMd;
  font-size: 13px;
  background-color: ${({ dir }) => (dir == "rtl" ? "#f8f8f8" : "#fff")};
`;
const ChatItem = styled.div`
  margin-bottom: 18px;
  span {
    font-family: PoppinsMd;
    font-size: 11px;
    line-height: 15px;
    color: #878787;
  }
`;

export const MessageFooter = styled.div`
  padding: 20px 15px;
  &.chat-sec-footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    left: 0;
  }
  .area-field-box {
    padding: 11px;
    border: 1px solid #e7e7e9;
    border-radius: 8px;
  }
  textarea {
    resize: none;
    color: #878787;
    font-size: 12px;
    font-family: PoppinsMd;
    border: 0;
  }
  .file-label {
    padding: 5px 10px;
    border: 1px solid #e7e7e9;
    border-radius: 6px;
    font-size: 12px;
    font-family: PoppinsSb;
  }
  .msg-actions-group {
    justify-content: end;
  }
  button {
    padding: 5px 10px;
    background-color: #7abbb5;
    color: #fff;
    border-radius: 6px;
    font-size: 12px;
    font-family: PoppinsSb;
  }
`;

export default ChatItems;
