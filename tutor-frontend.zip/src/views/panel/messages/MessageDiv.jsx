import React from "react";
import moment from "moment";

const MessageDiv = ({ userId, message }) => {
  const { author, body, type, timestamp } = message?.state;
  const messageOwn = author === userId;

  const renderMessageOnType = () => {
    switch (type) {
      case "text":
        return <MessageText />;
      case "media":
        return <MessageMedia />;

      default:
        return <MessageText />;
    }
  };

  const MessageText = () => {
    return (
      <>
        <div className={messageOwn ? "message-div my-message" : "message-div"}>
          <div className="message-text">{body}</div>
        </div>
        <div className={messageOwn ? "timestamp my-timestamp" : "timestamp"}>
          {moment(timestamp).format("MMMM Do YYYY, h:mm:ss a")}
        </div>
      </>
    );
  };

  const MessageMedia = () => {
    const { media } = message.state;

    const getMediaContent = async () => {
      const mediaLink = await media.getContentTemporaryUrl();
      window.open(mediaLink);
    };

    return (
      <>
        <div className={messageOwn ? "message-div my-message" : "message-div "}>
          <div
            onClick={getMediaContent}
            style={{ textAlign: "center" }}
            className="message-text pointer">
            click to open file :{" "}
            <span style={{ fontFamily: "poppinsSb" }}>
              {media.state.filename}
            </span>
          </div>
        </div>
        <div className="timestamp ml-auto">
          {moment(timestamp).format("MMMM Do YYYY, h:mm:ss a")}
        </div>
      </>
    );
  };
  return renderMessageOnType();
};

export default React.memo(MessageDiv);
