import React, { useState, useEffect, useRef } from "react";
import { Row } from "react-bootstrap";
import Col from "react-bootstrap/Col";
import { useSelector } from "react-redux";
import styled from "styled-components";
import {
  getChatToken,
  getConversations,
  updateChatRoomApi
} from "../../../api";
import ChatItems from "./ChatItems";
import ChatUsers from "./ChatUsers";
const TwilioChat = require("twilio-chat");

export default function Messages() {
  const bottomRef = useRef();
  const { user } = useSelector((state) => state.auth);

  const [userData, setUserData] = useState([]);
  const [username, setUsername] = useState("");
  const [active, setActive] = useState(null);
  const [users, setUsers] = useState([]);
  const [loader, setLoader] = useState(false);
  const userId = user?._id;
  const client = useRef(null);

  const createChatClient = async () => {
    const { data } = await getChatToken();
    // setUsername(data.identity);
    client.current = await TwilioChat.Client.create(data.token);
  };

  useEffect(() => {
    setLoader(true);
    // getting chat rooms
    const getChatRooms = async () => {
      try {
        const { data } = await getConversations();
        await createChatClient();
        setUsers(data);
        setLoader(false);
        // data.length > 0 && setActive(data[0]);
      } catch (error) {
        console.log("ERROR", error);
      }
    };

    // calling functions
    getChatRooms();
    return () => {};
  }, []);

  useEffect(() => {
    if (active) {
      if (!active.new?.includes(userId)) {
        const updatededChatRoom = userData.filter((el) => {
          if (el._id === active._id) {
            el.new = [...el?.new, userId];
          }
          return el;
        });
        setUserData(updatededChatRoom);
        const updateChatRoom = async () => {
          try {
            await updateChatRoomApi({
              id: active?._id,
              data: { new: [...active.new, userId] }
            });
          } catch (error) {
            console.log(error);
          }
        };
        updateChatRoom();
      }
      {
        user?.user_type === "tutor"
          ? setUsername(
              `${active?.user_id?.first_name} ${active?.user_id?.last_name}`
            )
          : setUsername(
              `${active?.tutor_id?.first_name} ${active?.tutor_id?.last_name}`
            );
      }
    }
    // bottomRef.current.scroll({
    //   top: bottomRef.current.scrollHeight,
    //   behavior: "smooth",
    // });
    return () => {};
  }, [active]);
  return (
    <div>
      <MessageContainer className="mx-auto">
        <Row className="w-100 mx-0">
          <Col md={3} className="px-0">
            <MessageHeader>Inbox</MessageHeader>
            <ChatUsers
              active={active}
              clickedUser={(v) => {
                setActive(v);
              }}
              users={users}
              user={user}
              loader={loader}
            />
          </Col>
          <Col md={9} className="px-0 border-left-custom">
            <div className="d-flex flex-column justify-content-between">
              <MessageHeader>{username}</MessageHeader>
              <MessageBody id="messageEndRef" style={{height:"calc(600px - 180px)"}}>
                {active !== null && (
                  <ChatItems
                    active={active}
                    back={() => setActive(null)}
                    client={client.current}
                    username={username}
                  />
                )}
              </MessageBody>
            </div>
          </Col>
        </Row>
      </MessageContainer>
    </div>
  );
}
const MessageContainer = styled.div`
  border: 1px solid #c8c8c8;
  border-radius: 20px;
  display: flex;
  overflow: hidden;
  height: 600px;
  max-width: 1010px;
  .border-left-custom {
    border-left: 1px solid #c8c8c8;
  }
`;
export const MessageHeader = styled.div`
  padding: 15px;
  font-family: ${({ weight }) => (weight == 500 ? "PoppinsMd" : "PoppinsSb")};
  font-style: normal;
  font-size: 16px;
  line-height: 24px;
  border-bottom: 1px solid #c8c8c8;
  color: #0a0d31;
  &.active {
    background: rgb(122 187 181 / 10%);
  }
`;
const MessageBody = styled.div`
  padding: 30px 15px;
  overflow-y: auto;
  height: calc(600px - 200px);
`;
export const MessageFooter = styled.div`
  &.chat-sec-footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    left: 0;
  }
  padding: 20px 15px;

  .area-field-box {
    padding: 11px;
    border: 1px solid #e7e7e9;
    border-radius: 8px;
  }
  textarea {
    resize: none;
    color: #878787;
    font-size: 12px;
    font-family: PoppinsMd;
    border: 0;
  }
  .file-label {
    padding: 5px 10px;
    border: 1px solid #e7e7e9;
    border-radius: 6px;
    font-size: 12px;
    font-family: PoppinsSb;
  }
  .msg-actions-group {
    justify-content: end;
  }
  button {
    padding: 5px 10px;
    background-color: #7abbb5;
    color: #fff;
    border-radius: 6px;
    font-size: 12px;
    font-family: PoppinsSb;
  }
`;
