import React from "react";
import styled from "styled-components";
import { MessageHeader } from "./messages";
import { Spinner } from "react-bootstrap";

const ChatUsers = ({ users, active, clickedUser, user, loader }) => {
  return (
    <MessageUsers>
      {loader && (
        <div className="text-center my-4">
          <Spinner animation="border" variant="info" role="status">
            <span className="visually-hidden"></span>
          </Spinner>
        </div>
      )}
      {users?.length > 0
        ? users?.map((list, key) => {
            return (
              <MessageHeader
                key={key}
                className={active?._id === list?._id ? "active" : ""}
                onClick={() => clickedUser(list)}
                type="button"
                weight={500}>
                {user?.user_type === "tutor"
                  ? `${list?.user_id?.first_name} ${list?.user_id?.last_name}`
                  : `${list?.tutor_id?.first_name} ${list?.tutor_id?.last_name}`}
              </MessageHeader>
            );
          })
        : !loader && (
            <div className="text-center my-4">
              <h5>
                <b>No Chat Found</b>
              </h5>
            </div>
          )}
    </MessageUsers>
  );
};

const MessageUsers = styled.div`
  display: block;
`;

export default ChatUsers;
