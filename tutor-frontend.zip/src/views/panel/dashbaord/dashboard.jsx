import React, { useState, useEffect } from "react";
import DashboardPage from "./dashboardPage";
import Messages from "../messages/messages";
import Classes from "../classes/classes";
import Setting from "../setting/setting";
import { Link, Redirect, Route, withRouter } from "react-router-dom";
// import TeacherSingleClass from "../TeacherClassesPage/components/TeacherSingleClass";
// import DetailSingleClass from "../TeacherClassesPage/components/DetailSingleClass";
import { connect } from "react-redux";
import Purchase from "../purchase/purchase";
import Notifications from "../notifcations/notifications";
import Scehdule from "../../../components/web/profileSetup/Scehdule";
import MyEarnings from "../Earnings/MyEarnings";
import { useSelector } from "react-redux";

function TeacherDashboardHeader(props) {
  const { location } = props;
  const path = location.pathname;
  const { user } = useSelector((state) => state.auth);
  useEffect(() => {
    if (path.indexOf("/dashboard") > -1) handleActive(0);
    if (path.indexOf("/dashboard/classes") > -1) handleActive(1);
    if (path.indexOf("/dashboard/messages") > -1) handleActive(2);
    if (path.indexOf("/dashboard/purchase") > -1) handleActive(3);
    if (path.indexOf("/notification") > -1) handleActive(4);
    if (path.indexOf("/profile-and-setting") > -1) handleActive(5);
    if (path.indexOf("/earnings") > -1) handleActive(6);
    return () => {};
  }, [path]);
  const [active, setActive] = useState(0);
  const [activeDropDown, setActiveDropDown] = useState(false);
  const [activePage, setActivePage] = useState("Dashboard");
  
  // handle Active
  const handleActive = (value) => {
    let activePage;

    switch (value) {
      case 0:
        activePage = "Dashboard";
        break;
      case 1:
        activePage = "Classes";
        break;
      case 2:
        activePage = "Messages";
        break;
      case 3:
        activePage = "Purchases";
        break;
      case 4:
        activePage = "Notifications";
        break;
      case 5:
        activePage = "Profile and Settings";
        break;
      case 6:
        activePage = "Earnings";
      break;
      default:
        break;
    }
    setActive(value);
    setActivePage(activePage);
  };
  // handle Active Dropdown
  const handleDropDown = () => {
    setActiveDropDown(!activeDropDown);
  };
  const closeDropDown = () => {
    setActiveDropDown(false);
  };

  // render main

  const { loading, userStatus } = props;
  return (
    <div  className="headerPadding overflow-hidden">
      {/* {loading || (userStatus !== "Teacher" && <Redirect push to="/" />)} */}
      <div  className=" basicRow py-0 teacher-dh-hr">
        {/* desktop Header */}
        <div  className="teacherDashboardHeader d-none d-md-block">
          <div style={{maxWidth:"1010px"}} className="mx-auto d-flex justify-content-between">
          <Link to="/dashboard">
            <div
              onClick={() => handleActive(0)}
               className={active === 0 ? "item itemActive" : "item "}
            >
              Dashboard
            </div>
          </Link>
          <Link to="/dashboard/classes/my">
            <div
              onClick={() => handleActive(1)}
               className={active === 1 ? "item itemActive" : "item "}
            >
              Classes
            </div>
          </Link>
          <Link to="/dashboard/messages">
            <div
              onClick={() => handleActive(2)}
               className={active === 2 ? "item itemActive" : "item "}
            >
              Messages
            </div>
          </Link>
          {user?.user_type=="tutor"?
          <Link to="/dashboard/earnings">
            <div
              onClick={() => {
                handleActive(6);
                closeDropDown();
              }}
              className={active === 6 ? "item itemActive" : "item "}
            >
              Earnings
            </div>
          </Link>
          :
          <Link to="/dashboard/purchase">
            <div
              onClick={() => handleActive(3)}
               className={active === 3 ? "item itemActive" : "item "}
            >
              Purchases
            </div>
          </Link>
          }
          <Link to="/dashboard/notification">
            <div
              onClick={() => handleActive(4)}
               className={active === 4 ? "item itemActive" : "item "}
            >
              Notifications
            </div>
          </Link>
          <Link to="/dashboard/profile-and-setting">
            <div
              onClick={() => handleActive(5)}
               className={active === 5 ? "item itemActive" : "item "}
            >
              Profile and Settings
            </div>
          </Link>
          </div>
        </div>
      </div>  
      <div  className=" basicRow pt-0">
        {/* Mobile Header */}
        <div  className="d-inline d-md-none">
          <div onClick={handleDropDown}  className="teacherDashboardHeaderM">
            <span>{activePage}</span>
            <img
              src={
                activeDropDown
                  ? "/assets/image/arrowUpBlack.svg"
                  : "/assets/image/arrowDownBlack.svg"
              }
              alt="arrowDown"
            ></img>
          </div>
          {activeDropDown && (
            <div  className="DashboardDropDownDiv">
              <Link to="/dashboard">
                <div
                  onClick={() => {
                    handleActive(0);
                    closeDropDown();
                  }}
                   className="item"
                >
                  Dashboard
                </div>
              </Link>

              <Link to="/dashboard/classes">
                <div
                  onClick={() => {
                    handleActive(1);
                    closeDropDown();
                  }}
                   className="item"
                >
                  Classes
                </div>
              </Link>
              <Link to="/dashboard/messages">
                <div
                  onClick={() => {
                    handleActive(2);
                    closeDropDown();
                  }}
                   className="item"
                >
                  Messages
                </div>
              </Link>
              <Link to="/dashboard/earnings">
                <div
                  onClick={() => {
                    handleActive(6);
                    closeDropDown();
                  }}
                   className="item"
                >
                  Earnings
                </div>
              </Link>
              <Link to="/dashboard/purchase">
                <div
                  onClick={() => {
                    handleActive(3);
                    closeDropDown();
                  }}
                   className="item"
                >
                  Purchase
                </div>
              </Link>
              <Link to="/dashboard/notification">
                <div
                  onClick={() => {
                    handleActive(4);
                    closeDropDown();
                  }}
                   className="item"
                >
                  Notifications
                </div>
              </Link>
              <Link to="/dashboard/profile-and-setting">
                <div
                  onClick={() => {
                    handleActive(5);
                    closeDropDown();
                  }}
                   className="item"
                >
                  Profile and Settings
                </div>
              </Link>
            </div>
          )}
        </div>
        <div className="mx-auto" style={{ marginTop: "50px",maxWidth:"1010px" }}>
          <Route
            path="/dashboard"
            exact={true}
            component={DashboardPage}
          ></Route>
          {/* <Route
            path="/teacher-dashboard/classes/detail/:id"
            component={DetailSingleClass}
          ></Route>
          <Route
            path="/teacher-dashboard/classes/single/:id"
            component={TeacherSingleClass}
          ></Route> */}
          <Route path="/dashboard/earnings" component={MyEarnings}></Route>
          <Route path="/dashboard/classes" component={Classes}></Route>
          <Route path="/dashboard/messages" component={Messages}></Route>
          <Route path="/dashboard/purchase" component={Purchase}></Route>
          <Route
            path="/dashboard/notification"
            component={Notifications}
          ></Route>
          <Route
            path="/dashboard/profile-and-setting"
            component={Setting}
          ></Route>
        </div>
        {/* <div  className="footerPadding"></div> */}
      </div>
    </div>
  );
}

const MapStateToProps = (state) => {
  return {
    isAuthenticated: state.auth.isAuthenticated,
    loading: state.auth.loading,
    userStatus: state.auth.user?.user?.userStatus,
  };
};
export default connect(MapStateToProps)(withRouter(TeacherDashboardHeader));
