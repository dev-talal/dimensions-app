import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import Calender from "../../../components/calender/calender";
import Loading from "../../../components/common/loading";
import "./dashboard.css";
import { getImageUrl } from "../../../helpers";
import { getDashboardCount } from "../../../api";

export default function DashboardPage() {
  // getting auth data
  const { user = {} } = useSelector((state) => state.auth);
  const [selected, setselected] = useState(new Date());
  const [countsData, setCountsData] = useState({});
  const loading = false;
  // data
  const [classData, setClassData] = useState([]);
  // data
  useEffect(async()=>{
    window.scrollTo({ top: 0, behavior: 'smooth' });
    try{
      const {data} = await getDashboardCount();
      setCountsData(data)
    }
    catch{

    }
  },[])
  const user_register_type = user?.register_type=="google" || user?.register_type=="facebook"?'social':'simple';
  // dispatching action to get classes
  //   useEffect(() => {
  //     dispatch();
  //     //   getUpcommingClasses("/teacherUpComingClasses", selected.toUTCString())
  //     return () => {};
  //   }, [selected]);

  //   // setting data
  //   useEffect(() => {
  //     setClassData(data);
  //     return () => {};
  //   }, [data]);

  // get upcomming classes

  //   const getCountsData = () => {
  //     const token = localStorage.jwtToken;

  //     const response = AxiosBase.get(`/teacherDashboardCounts/${user?._id}`, {
  //       headers: { "x-access-token": token },
  //     });
  //     return response;
  //   };
  //   const userId = user?._id;
  //   // getting dashboard data
  //   const {
  //     isLoading,
  //     error,
  //     data: countsDataApi,
  //   } = useQuery( 'dashboardCounts', getCountsData, {
  //     enabled: !!userId,
  //   });

  //   useEffect(() => {
  //     countsDataApi?.data && setCountsData(countsDataApi.data);
  //     return () => {};
  //   }, [countsDataApi]);

  // main return
  return (
    <div  className="dashboardWrapper">
      <div  className="flexCenter mb-4">
        <img
           className="dashboardProfileImg"
          src={
            user?.profile_pic
              ? user?.profile_pic !== ""
                ? getImageUrl(user?.profile_pic,user_register_type)
                : "/assets/image/defaultKidProfile.svg"
              : "/assets/image/defaultKidProfile.svg"
          }
          alt={`${user?.first_name} ${user?.last_name}`}
        ></img>
        <h1
           className="dashboardProfileText mb-0 ml-4"
          style={{ textTransform: "capitalize" }}
        >
          Hi, {user?.first_name ? user?.first_name : ""}{" "}
          {user?.last_name ? user?.last_name : ""}!
        </h1>
      </div>
      <div  className="dashboardItemsDiv">
        <div  className="dashboardItem">
          <div  className="text">Upcoming Classes</div>
          <h1  className="dashboardProfileText mb-0">
            {countsData?.upcomming || "0"}
          </h1>
        </div>
        <div  className="dashboardItem">
          <div  className="text">Completed Classes</div>
          <h1  className="dashboardProfileText mb-0">
            {countsData?.totalAvailableClasses || "0"}
          </h1>
        </div>
        <div  className="dashboardItem">
          <div  className="text">Total Hours</div>
          <h1  className="dashboardProfileText mb-0">
            {countsData?.completed || "0"}
          </h1>
        </div>
        <div  className="dashboardItem">
          <div  className="text">Total Students</div>
          <h1  className="dashboardProfileText mb-0">
            {countsData?.totalLearners || "0"}
          </h1>
        </div>
      </div>
      <div className="iqama-box-alt" style={{background:"rgb(122 187 181 / 16%)"}}>
        <div className="d-flex align-items-center justify-content-between flex-wrap">
          <div>
            <h5 className="mb-3 me-3 text-danger" style={{fontSize:"17px",fontFamily:"poppinsBd"}}>Please add your Iqama to show your profile to the students/parents.</h5>
            <button className="primaryButton green mt-0" type="button">
              Upload Iqama
            </button>
          </div>
          <img src="/assets/image/iqama.png" className="align-self-center" width="100px" alt="Iqama" />
        </div>
      </div>
      <div  className="upcomingClassesDiv">
        <div  className="title">Upcoming classes</div>
        <Calender callback={(day) => setselected(day)} />
        {loading && <Loading  />}
        <div >
          {loading ||
            (classData &&
              classData.map((item) => {
                return (
                  <>
                    {/* <div
                      onClick={() => {
                        history.push(
                          `/teacher-dashboard/classes/single/${item.classId}`
                        );
                      }}
                       className="class pointer"
                    >
                      <div  className="imgSec d-none d-sm-inline">
                        <img
                          src={item.classImage}
                          alt="class"
                           className="classImg"
                        ></img>
                      </div>
                      <div  className="timeSec">
                        <div  className="timeText">
                         {getLocalTime(item.section.startTime)} 
                        </div>
                        <img
                          src={item.classImage}
                          alt="class"
                           className="classImg d-inline d-sm-none"
                        ></img>
                      </div>
                      <div  className="detailSec">
                        <div  className="title mb-2">{`${item.classTitle} - ${item.subject}`}</div>
                        <p  className="text">
                          {`${item.classTypeDetails.classDuration} - 
                        ${item.section.enrolled_Users.length} öğrenci kaydoldu -
                       ${item.classTypeDetails.weeklyMeetingNumbers} haftalık toplantı `}
                        </p>
                      </div>
                    </div> */}
                  </>
                );
              }))}
          {loading ||
            (classData?.length === 0 && (
              <div  className="centerFlex">
                <span  className="basicText">Yaklaşan Ders yok</span>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
