import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { Route, Link, BrowserRouter as Router } from "react-router-dom";
import styled from "styled-components";
import My from "../../../components/web/classes/My";
import MyClass from "../../../components/web/classes/MyClass";
import Scehdule from "../../../components/web/profileSetup/Scehdule";
import { initFormState } from "../../web/profileSetup/constant";
const Classes = (props) => {
  const [formState, setFormState] = useState(initFormState);
  const [activeTab, setActiveTab] = useState(1);
  const { location } = props;
  const path = location.pathname;
  const { user } = useSelector((state) => state.auth);
  let userStatus = user?.user_type;
  useEffect(() => {
    if (path.indexOf("/dashboard/classes/my") > -1) setActiveTab(1);
    if (path.indexOf("/dashboard/classes/schedule") > -1) setActiveTab(2);
    return () => {};
  }, [path]);
  return (
    <div>
      {userStatus !== "individual" ? (
        <TabsHeader>
          <Link
            to="/dashboard/classes/my"
            className={`text-decoration-none  w-50 d-block`}
            onClick={() => setActiveTab(1)}
          >
            <TabItem
              className={`text-center ${activeTab == 1 ? "active" : ""}`}
            >
              {user.user_type=="tutor"?"My Classes":"Classroom"}
            </TabItem>
          </Link>
          <Link
            to="/dashboard/classes/schedule"
            className="text-decoration-none w-50 d-block"
            onClick={() => setActiveTab(2)}
          >
            <TabItem
              className={`text-center ${activeTab == 2 ? "active" : ""}`}
            >
              Availability
            </TabItem>
          </Link>
        </TabsHeader>
      ) : null}
      <div>
        <Route path="/dashboard/classes/my" exact={true} component={My}></Route>
        <Route
          path="/dashboard/classes/my/:id"
          exact={true}
          component={MyClass}
        ></Route>
        <Route path="/dashboard/classes/schedule">
          <div className="tutorProfileSetup mt-5">
            <style>
              {
                "\
              .tutorProfileSetup{\
                background-color:transparent;\
              }\
            "
              }
            </style>
            <Scehdule formState={formState} setFormState={setFormState} />
          </div>
        </Route>
      </div>
    </div>
  );
};
export default Classes;
const TabsHeader = styled.div`
  display: flex;
  border: 1px solid #c8c8c8;
  border-radius: 6px;
`;
const TabItem = styled.div`
  padding: 7px 15px;
  cursor: pointer;
  font: 15px poppinsMd;
  &:not(.active) {
    color: #878787;
  }
  &.active {
    background-color: #7abbb5;
    color: #fff;
  }
`;
