import React,{ useEffect,useState } from "react";
import { Col, Spinner } from "react-bootstrap";
import styled from 'styled-components';
import {Link} from 'react-router-dom'
import { getAllNotifications } from "../../../api";
import moment from 'moment'
function Notifications() {
  const [data,setData] = useState([]);
  const [todayData,setTodayData] = useState([]);
  const [dataShow,setDataShow] = useState(4);
  const [loader,setLoader] = useState(true);
  const todayNotifications = (date) => {
    return moment().format("YYYY-MM-DD") == moment(date).format("YYYY-MM-DD")
  }
  useEffect(async() => {
    setLoader(true);
    try{
      const res = await getAllNotifications();
      setData(res.data.filter((x)=>todayNotifications(x.createdAt)==false));
      console.log(res.data.filter((x)=>todayNotifications(x.createdAt)==true));
      setTodayData(res.data.filter((x)=>todayNotifications(x.createdAt)==true))
    }
    catch(error){
     
    }
    setLoader(false);
  },[])
  return (
    <Col lg={10} className="mx-auto">
      {loader?
        <div className="text-center mt-2">
          <Spinner animation="border" variant="info" role="status">
            <span className="visually-hidden"></span>
          </Spinner>
        </div>
      :
      <Heading className="mb-4">
        Notifications
      </Heading>
      }
      {todayData.length>0?
      <ListBox className="mb-4">
        <ListHeader>
          Today
        </ListHeader>
        {todayData.length>0 && todayData.map((item,key)=>{
        return(
        <ListHeader className="d-flex justify-content-between" weight={600}>
          <span>{item.body}</span>
          {/* <Link to="#" className="text-orange">
            Open classroom 
          </Link> */}
        </ListHeader>
          )
        })}
      </ListBox>
      :null}
      {data.length>0?
      <ListBox>
        <ListHeader>
          Earlier
        </ListHeader>
        {data.filter((i,key)=>key<dataShow).map((item,key)=>{
          return(
            <ListHeader className="d-flex justify-content-between" weight={400}>
              <span>{item.body}</span>
      
              {/* <Link to="#" className="text-orange" disabled={true}>
            
              </Link> */}
            </ListHeader>
          )
        })}
        <ListHeader className="text-center" weight={400}>
          <Link to="#" onClick={()=>setDataShow(dataShow+5)} className="text-blue">
            Load More
          </Link>
        </ListHeader>
      </ListBox>
      :null}
    </Col>
  )
}
const Heading = styled.div`
  font: 16px poppinsMd;
  line-height: 30px;
  color: #0A0D31;
`;
const ListBox = styled.div`
  border:1px solid #c8c8c8;
  border-bottom: 0;
  border-radius: 6px;
  overflow:hidden;

`;
export const ListHeader = styled.div`
  padding:15px;
  font: 14px ${({weight})=>weight!==400?"poppinsMd":"poppins"};
  line-height: 24px;
  color: #0A0D31;
  border-bottom:1px solid #c8c8c8;
`;
export default Notifications;
