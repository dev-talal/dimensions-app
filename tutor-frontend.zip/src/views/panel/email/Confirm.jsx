import React from 'react'
import { EnvelopeCheck } from 'react-bootstrap-icons'
import styled from 'styled-components'
import { HeadingText, P } from '../../../components/web/classes/MyClass'
export const Confirm = () => {
  return (
    <div className="px-5 text-center py-5">
        <StyledEmailBox>
            <EnvelopeCheck size={100} color="#28a745" />
            <HeadingText className="mt-3" size={22} style={{fontFamily:"poppinsBd"}}>
                Email Verified
            </HeadingText>
            <P className="mb-0" size={14}>
                Your email has been verified successfully
            </P>
            <button className="mt-4 primaryButton">
                Continue to Login
            </button>
        </StyledEmailBox>
    </div>
  )
}
const StyledEmailBox = styled.div`
    max-width:600px;
    margin-left:auto;
    margin-right:auto;
    background:#fff;
    border-radius:20px;
    overflow:hidden;
    box-shadow:0px 0px 12px 0px #d3d3d3;
    padding:30px 20px;
`;