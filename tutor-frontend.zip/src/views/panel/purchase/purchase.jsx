import React,{useState} from "react";
import { useEffect } from "react";
import { Form } from "react-bootstrap";
import { ChevronLeft, ChevronRight } from "react-bootstrap-icons";
import styled from 'styled-components'
import { getAllPurchases } from "../../../api";
import { GetDateAndTime } from "../../../components/web/classes/CommentBox";
import { HeadingText, P } from "../../../components/web/classes/MyClass";
import Spinner from "react-bootstrap/Spinner";
export default function Purchase() {
  const [allPurchases,getPurchases] = useState([]);
  const [loader,setLoader] = useState(false);
  useEffect(async()=>{
    setLoader(true)
    try{
      const {data} = await getAllPurchases();
      console.log(data)
      getPurchases(data)
    }
    catch{

    }
    setLoader(false)
  },[])
  return (
    <div className="px-3 pb-4">
      <HeadingText size={16} weight="poppinsMd">
        My purchases
      </HeadingText>
      <hr />
      {loader ? (
        <div className="text-center my-5">
          <Spinner animation="border" variant="info" role="status">
            <span className="visually-hidden"></span>
          </Spinner>
        </div>
      ) : (
      <>
      {allPurchases.map((item,i)=>{
        return(
          <div key={i}>
            <HeadingText size={15}>
              Learn how to read and write while having fun - kindergarten
            </HeadingText>
            <P size={13}>
              {/* Mon ThuDec 10 - Jan 27 at 18:00 Istanbul time */}
              <GetDateAndTime time={item.class_id?.createdAt} />
            </P>
            <div className="mt-3">
              <HeadingText size={15}>
                ${item.price}
              </HeadingText>
              <P size={13}><GetDateAndTime time={item.date} /></P>
            </div>
            <hr />
          </div>
        )
      })}
      {allPurchases.length>0?
      <Pagination className="mt-5">
        <ul className="list-unstyled justify-content-center d-flex">
          <li className="mr-2">
            <button type="button" className="border-0 bg-transparent">
              <ChevronLeft size={18} />
            </button>
          </li>
          <li className="mr-2">
            <Form as="input" value="1" />
          </li>
          <li>
            <button type="button" className="border-0 bg-transparent">
              <ChevronRight size={18} />
            </button>
          </li>
        </ul>
      </Pagination>
      :null}
      </>
      )}
    </div>
  );
}
const Pagination = styled.div`
  input{
    width:40px;
    height:27px;
    border:1px solid #C8C8C8;
    text-align:center;
  }
`