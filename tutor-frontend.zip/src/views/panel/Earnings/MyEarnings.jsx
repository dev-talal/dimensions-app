import React,{useState,useEffect} from "react";
import { HeadingText, P } from "../../../components/web/classes/MyClass";
import styled from "styled-components";
import { getAllPurchases } from "../../../api";
const MyEarnings = () => {
  const [allPurchases,getPurchases] = useState([]);
  const [loader,setLoader] = useState(false);
  useEffect(async()=>{
    setLoader(true)
    try{
      const {data} = await getAllPurchases();
      getPurchases(data)
    }
    catch{

    }
    setLoader(false)
  },[])
  return (
    <React.Fragment>
      <HeadingText className="mb-2">My earnings</HeadingText>
      <P size={13} style={{color:"#0A0D31"}}>
        Dolor sit amet consectetur adipiscing elit. Semper viverra nam libero
        justo. Dolor sit amet consectetur adipiscing elit. Semper viverra nam
        libero justo.
      </P>
      <HeadingText className="mt-4 pt-2" size={15}>Earnings summary</HeadingText>
      <div  className="dashboardItemsDiv mt-3">
        <div  className="dashboardItem">
          <div  className="text">Total Students</div>
          <h1  className="dashboardProfileText mb-0">
            {"50"}
          </h1>
        </div>
        <div  className="dashboardItem">
          <div  className="text">Total Hours</div>
          <h1  className="dashboardProfileText mb-0">
            {"71"}
          </h1>
        </div>
        <div  className="dashboardItem">
          <div  className="text">Total Earning</div>
          <h1  className="dashboardProfileText mb-0">
            ${Number(2510).toLocaleString()}
          </h1>
        </div>
      </div>  
      <HeadingText className="mt-4 pt-2" size={16}>Subscription summary</HeadingText>
      <div  className="dashboardItem mt-3" style={{width:"fit-content",minHeight:"1px",height:"auto"}}>
        <div className="text d-flex justify-content-between">
          Weekly subscription
          <span type="button" style={{color:"#7ABBB5"}}>Change subscription</span>
        </div>
        <h1  className="dashboardProfileText mb-0">
          $17.9/month <small style={{color:"#C8C8C8",fontSize:"10px"}}>Renews on 26/06/2021.</small>
        </h1>
      </div>
      <HeadingText className="mt-4 pt-2" size={16}> Recent transactions</HeadingText>
      <P className="mb-3" size={13} style={{color:"#0A0D31"}}>
        Here you can find your recent 5 transactions.
      </P>
      <div className="pr-lg-5 mt-4">
        <Table className="w-100 ">
          {[...Array(5)].map((i,key)=>{
            return(
              <tr key={key}>
                <td>Balance withdraw</td>
                <td>$300</td>
                <td className="text-center">11/30/2020</td>
                <td className="text-right">Bank transfer</td>
              </tr>
            )
          })}
        </Table>
      </div>
      <HeadingText className="mt-4 pt-2" size={16}>Monthly summary</HeadingText>
      <div className="pr-lg-5 mt-3 mb-4">
        <Table className="w-100">
          <tr>
            <th>Month</th>
            <th className="text-center">Earnings</th>
            <th className="text-right">Learners</th>
          </tr>
          {[...Array(3)].map((i,key)=>{
            return(
              <tr key={key}>
                <td>November</td>
                <td className="text-center">$50</td>
                <td className="text-right">20</td>
              </tr>
            )
          })}
        </Table>
      </div>
    </React.Fragment>
  );
};
const Table  = styled.table`
  tr{
    border-bottom: 1px solid #E7E7E9;
  }
  th{
    padding-bottom: 17px;
    color:#0A0D31;
    font-size:15px;
  }
  td{
    padding-top: 17px;
    padding-bottom: 17px;
    color: #C8C8C8;
    font-size:15px;
  }

`
export default MyEarnings;