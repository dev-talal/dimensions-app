import React from "react";
import ResultPage from "./components/web/booking/ResultPage";
import LoginRedirectRoute from "./routes/LoginRedirectRoute";
import PrivateRoute from "./routes/PrivateRoute";
import ProfileSetupRoute from "./routes/ProfileSetupRoute";
import PublicRoutes from "./routes/PublicRoutes";
import WithoutNav from "./routes/WithoutNav";
import Dashboard from "./views/panel/dashbaord/dashboard";
import { Confirm } from "./views/panel/email/Confirm";
import EmailVerification from "./views/web/auth/EmailVerifcation";
import EmailVerify from "./views/web/auth/EmailVerify";
import forgotAuth from "./views/web/auth/forgotAuth";
import OtpVerification from "./views/web/auth/otpVerification";
import resetPassoword from "./views/web/auth/resetPassword";
import Exploar from "./views/web/categories/Exploar";
import Contact from "./views/web/contact/Contact";
import Countries from "./views/web/countries/Countries";
import Home from "./views/web/home/home";
import Login from "./views/web/login/login";
import Profile from "./views/web/profile/profile";
import addKids from "./views/web/profileSetup/addKids";
import tutorProfileSetup from "./views/web/profileSetup/tutorProfileSetup";
import searchPage from "./views/web/search/searchPage";
import parentSignup from "./views/web/signup/parent/parentSignup";
import signup from "./views/web/signup/signup";
import Faqs from "./views/web/Terms_Conditions/Faqs";
import OurStory from "./views/web/Terms_Conditions/OurStory";
import TermsConditions from "./views/web/Terms_Conditions/TermsConditions";
import BecomeTutor from "./views/web/tutor/BecomeTutor";
import Add from "./views/web/workshop/Add";
import All from "./views/web/workshop/All";
import UserWorkshop from "./views/web/workshop/UserWorkshop";
export default function routes() {
  return (
    <>
      {/* Auth Routes */}
      <LoginRedirectRoute path="/sign-up" exact component={signup} />
      <LoginRedirectRoute path="/sign-up/parent" component={parentSignup} />
      <LoginRedirectRoute path="/sign-up/tutor" component={parentSignup} />
      <LoginRedirectRoute path="/login" component={Login} />
      <LoginRedirectRoute path="/auth/forgot-password" component={forgotAuth} />
      <LoginRedirectRoute path="/auth/verified" component={EmailVerification} />
      <LoginRedirectRoute path="/auth/verify-email" component={EmailVerify} />
      <LoginRedirectRoute
        path="/auth/otp-verification"
        component={OtpVerification}
      />
      <LoginRedirectRoute
        path="/auth/reset-password"
        component={resetPassoword}
      />
      {/* Profile Steup Routes */}
      <ProfileSetupRoute path="/profile-setup/add-kids" component={addKids} />
      <ProfileSetupRoute
        path="/profile-setup/tutor"
        component={tutorProfileSetup}
      />

      {/* Public Routes */}
      <PublicRoutes exact={true} path="/" component={Home} />
      <PublicRoutes heading="Terms of services" exact={true} path="/terms-of-services" component={TermsConditions} />
      <PublicRoutes heading="Privacy policy" exact={true} path="/privacy-policy" component={TermsConditions} />
      <PublicRoutes exact={true} path="/countries" component={Countries} />
      <PublicRoutes exact={true} path="/categories" component={Exploar} />
      <PublicRoutes exact={true} path="/our-story" component={OurStory} />
      <PublicRoutes  path="/workshop-detail/:id" component={UserWorkshop} />
      <PublicRoutes exact={true} path="/workshop/all" component={All} />
      <PublicRoutes  exact={true} path="/workshop/me" component={UserWorkshop} />
      <PublicRoutes path="/search" component={searchPage} />
      <PublicRoutes path="/email/confirm" component={Confirm} />
      <PublicRoutes path="/profile/:id" component={Profile} />
      <PublicRoutes path="/faqs" component={Faqs} />
      <PublicRoutes path="/contact" component={Contact} />
      <PublicRoutes path="/become-tutor" component={BecomeTutor} />
      <WithoutNav path="/workshop/add" component={Add} />
      <PublicRoutes path="/payment/result" exact={true} component={ResultPage} />
      {/* dashboard Routes */}
      <PrivateRoute path="/dashboard" component={Dashboard} />
    </>
  );
}
